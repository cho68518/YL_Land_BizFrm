﻿
namespace YL_TELECOM.BizFrm
{
    partial class frmTM05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTM05));
            Easy.Framework.WinForm.Control.ChildHierarchy childHierarchy1 = new Easy.Framework.WinForm.Control.ChildHierarchy();
            Easy.Framework.WinForm.Control.Hierarchy hierarchy1 = new Easy.Framework.WinForm.Control.Hierarchy();
            Easy.Framework.WinForm.Control.ChildHierarchy childHierarchy2 = new Easy.Framework.WinForm.Control.ChildHierarchy();
            Easy.Framework.WinForm.Control.Hierarchy hierarchy2 = new Easy.Framework.WinForm.Control.Hierarchy();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo1 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo2 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo3 = new Easy.Framework.WinForm.Control.ServiceInfo();
            this.efwGroupControl5 = new Easy.Framework.WinForm.Control.efwGroupControl();
            this.layoutControl3 = new DevExpress.XtraLayout.LayoutControl();
            this.efwLabel4 = new Easy.Framework.WinForm.Control.efwLabel();
            this.efwLabel1 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txt_content = new Easy.Framework.WinForm.Control.efwMemoEdit();
            this.efwSimpleButton7 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton6 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.dt_visit_date = new Easy.Framework.WinForm.Control.efwDateEdit();
            this.cmb_advice_type = new Easy.Framework.WinForm.Control.efwLookUpEdit();
            this.txt_tel_no = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_hp_no = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_e_mail = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_person = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_agency_name = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_work_man = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.dt_plan_date = new Easy.Framework.WinForm.Control.efwDateEdit();
            this.txt_visit_area = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_visit_distant = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.cmb_move_type = new Easy.Framework.WinForm.Control.efwLookUpEdit();
            this.txt_car_mileage = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_oil_price = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_packing_price = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_gate_price = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_sales_price = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_remark = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.ly_advice_type = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.item1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.ly_advice_type1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.item4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.item7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.item8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.item9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterControl1 = new DevExpress.XtraEditors.SplitterControl();
            this.efwGroupControl1 = new Easy.Framework.WinForm.Control.efwGroupControl();
            this.efwGridControl1 = new Easy.Framework.WinForm.Control.efwGridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemMemoExEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.efwPanelControl1 = new Easy.Framework.WinForm.Control.efwPanelControl();
            this.efwTextEdit1 = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwTextEdit2 = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.btnOpen = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.txtCoidNo = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_idx = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_search = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel3 = new Easy.Framework.WinForm.Control.efwLabel();
            this.efwLabel2 = new Easy.Framework.WinForm.Control.efwLabel();
            this.dt_s_date = new Easy.Framework.WinForm.Control.efwDateEdit();
            this.dt_e_date = new Easy.Framework.WinForm.Control.efwDateEdit();
            this.rb_date_type = new Easy.Framework.WinForm.Control.efwRadioGroup();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl5)).BeginInit();
            this.efwGroupControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl3)).BeginInit();
            this.layoutControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_content.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_visit_date.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_visit_date.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_advice_type.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_tel_no.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_hp_no.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_e_mail.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_person.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_agency_name.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_work_man.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_plan_date.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_plan_date.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_visit_area.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_visit_distant.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_move_type.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_car_mileage.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_oil_price.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_packing_price.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_gate_price.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_sales_price.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_remark.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ly_advice_type)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ly_advice_type1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl1)).BeginInit();
            this.efwGroupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwPanelControl1)).BeginInit();
            this.efwPanelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.efwTextEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwTextEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCoidNo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_idx.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_search.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_s_date.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_s_date.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_e_date.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_e_date.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rb_date_type.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // efwGroupControl5
            // 
            this.efwGroupControl5.CaptionImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwGroupControl5.CaptionImageOptions.Image")));
            this.efwGroupControl5.Controls.Add(this.layoutControl3);
            this.efwGroupControl5.Dock = System.Windows.Forms.DockStyle.Left;
            this.efwGroupControl5.IsMultiLang = false;
            this.efwGroupControl5.Location = new System.Drawing.Point(3, 35);
            this.efwGroupControl5.Name = "efwGroupControl5";
            this.efwGroupControl5.Padding = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.efwGroupControl5.Size = new System.Drawing.Size(907, 772);
            this.efwGroupControl5.TabIndex = 47;
            this.efwGroupControl5.Text = "영업 일지 등록";
            // 
            // layoutControl3
            // 
            this.layoutControl3.Controls.Add(this.efwLabel4);
            this.layoutControl3.Controls.Add(this.efwLabel1);
            this.layoutControl3.Controls.Add(this.txt_content);
            this.layoutControl3.Controls.Add(this.efwSimpleButton7);
            this.layoutControl3.Controls.Add(this.efwSimpleButton6);
            this.layoutControl3.Controls.Add(this.dt_visit_date);
            this.layoutControl3.Controls.Add(this.cmb_advice_type);
            this.layoutControl3.Controls.Add(this.txt_tel_no);
            this.layoutControl3.Controls.Add(this.txt_hp_no);
            this.layoutControl3.Controls.Add(this.txt_e_mail);
            this.layoutControl3.Controls.Add(this.txt_person);
            this.layoutControl3.Controls.Add(this.txt_agency_name);
            this.layoutControl3.Controls.Add(this.txt_work_man);
            this.layoutControl3.Controls.Add(this.dt_plan_date);
            this.layoutControl3.Controls.Add(this.txt_visit_area);
            this.layoutControl3.Controls.Add(this.txt_visit_distant);
            this.layoutControl3.Controls.Add(this.cmb_move_type);
            this.layoutControl3.Controls.Add(this.txt_car_mileage);
            this.layoutControl3.Controls.Add(this.txt_oil_price);
            this.layoutControl3.Controls.Add(this.txt_packing_price);
            this.layoutControl3.Controls.Add(this.txt_gate_price);
            this.layoutControl3.Controls.Add(this.txt_sales_price);
            this.layoutControl3.Controls.Add(this.txt_remark);
            this.layoutControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl3.Location = new System.Drawing.Point(9, 23);
            this.layoutControl3.Name = "layoutControl3";
            this.layoutControl3.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(3075, 525, 650, 400);
            this.layoutControl3.Root = this.layoutControlGroup3;
            this.layoutControl3.Size = new System.Drawing.Size(889, 747);
            this.layoutControl3.TabIndex = 0;
            this.layoutControl3.Text = "layoutControl3";
            // 
            // efwLabel4
            // 
            this.efwLabel4.Appearance.ForeColor = System.Drawing.Color.Red;
            this.efwLabel4.Appearance.Options.UseForeColor = true;
            this.efwLabel4.EraserGroup = null;
            this.efwLabel4.IsMultiLang = false;
            this.efwLabel4.Location = new System.Drawing.Point(407, 175);
            this.efwLabel4.Name = "efwLabel4";
            this.efwLabel4.Size = new System.Drawing.Size(318, 14);
            this.efwLabel4.StyleController = this.layoutControl3;
            this.efwLabel4.TabIndex = 81;
            this.efwLabel4.Text = "※ 하루에 여러곳을 방문하였을 경우 나누어서 일지를 작성해 주세요!";
            // 
            // efwLabel1
            // 
            this.efwLabel1.Appearance.Font = new System.Drawing.Font("맑은 고딕", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.efwLabel1.Appearance.Options.UseFont = true;
            this.efwLabel1.EraserGroup = null;
            this.efwLabel1.IsMultiLang = false;
            this.efwLabel1.Location = new System.Drawing.Point(368, 7);
            this.efwLabel1.Name = "efwLabel1";
            this.efwLabel1.Size = new System.Drawing.Size(153, 41);
            this.efwLabel1.StyleController = this.layoutControl3;
            this.efwLabel1.TabIndex = 80;
            this.efwLabel1.Text = "영 업 일 지";
            // 
            // txt_content
            // 
            this.txt_content.ByteLength = 200;
            this.txt_content.EraserGroup = "CLR1";
            this.txt_content.Location = new System.Drawing.Point(132, 576);
            this.txt_content.Name = "txt_content";
            this.txt_content.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_content.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_content.Properties.NullText = "(상담내용) 상세하게 작성해주세요!";
            this.txt_content.Size = new System.Drawing.Size(750, 167);
            this.txt_content.StyleController = this.layoutControl3;
            this.txt_content.TabIndex = 11;
            this.txt_content.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_content_KeyDown);
            // 
            // efwSimpleButton7
            // 
            this.efwSimpleButton7.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwSimpleButton7.ImageOptions.Image")));
            this.efwSimpleButton7.IsMultiLang = false;
            this.efwSimpleButton7.Location = new System.Drawing.Point(786, 100);
            this.efwSimpleButton7.Name = "efwSimpleButton7";
            this.efwSimpleButton7.Size = new System.Drawing.Size(96, 30);
            this.efwSimpleButton7.StyleController = this.layoutControl3;
            this.efwSimpleButton7.TabIndex = 79;
            this.efwSimpleButton7.Text = "삭제";
            this.efwSimpleButton7.Click += new System.EventHandler(this.efwSimpleButton7_Click);
            // 
            // efwSimpleButton6
            // 
            this.efwSimpleButton6.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwSimpleButton6.ImageOptions.Image")));
            this.efwSimpleButton6.IsMultiLang = false;
            this.efwSimpleButton6.Location = new System.Drawing.Point(686, 100);
            this.efwSimpleButton6.Name = "efwSimpleButton6";
            this.efwSimpleButton6.Size = new System.Drawing.Size(96, 30);
            this.efwSimpleButton6.StyleController = this.layoutControl3;
            this.efwSimpleButton6.TabIndex = 13;
            this.efwSimpleButton6.Text = "저장";
            this.efwSimpleButton6.Click += new System.EventHandler(this.efwSimpleButton6_Click);
            // 
            // dt_visit_date
            // 
            this.dt_visit_date.EditValue = new System.DateTime(2019, 6, 7, 0, 0, 0, 0);
            this.dt_visit_date.IsRequire = true;
            this.dt_visit_date.Location = new System.Drawing.Point(132, 105);
            this.dt_visit_date.Name = "dt_visit_date";
            this.dt_visit_date.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(242)))), ((int)(((byte)(226)))));
            this.dt_visit_date.Properties.Appearance.Options.UseBackColor = true;
            this.dt_visit_date.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.dt_visit_date.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.dt_visit_date.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_visit_date.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_visit_date.Size = new System.Drawing.Size(101, 20);
            this.dt_visit_date.StyleController = this.layoutControl3;
            this.dt_visit_date.TabIndex = 0;
            // 
            // cmb_advice_type
            // 
            childHierarchy1.CodeCtrl = null;
            childHierarchy1.DbName = null;
            childHierarchy1.SpName = null;
            this.cmb_advice_type.ChildHierarchyInfo = childHierarchy1;
            hierarchy1.DbName = null;
            hierarchy1.SpName = null;
            this.cmb_advice_type.HierarchyInfo = hierarchy1;
            this.cmb_advice_type.IsMultiLang = false;
            this.cmb_advice_type.Location = new System.Drawing.Point(132, 479);
            this.cmb_advice_type.Name = "cmb_advice_type";
            this.cmb_advice_type.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(242)))), ((int)(((byte)(226)))));
            this.cmb_advice_type.Properties.Appearance.Options.UseBackColor = true;
            this.cmb_advice_type.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmb_advice_type.Properties.NullText = "";
            this.cmb_advice_type.Size = new System.Drawing.Size(271, 20);
            this.cmb_advice_type.StyleController = this.layoutControl3;
            this.cmb_advice_type.TabIndex = 5;
            this.cmb_advice_type.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmb_advice_type_KeyDown);
            // 
            // txt_tel_no
            // 
            this.txt_tel_no.EditValue2 = null;
            this.txt_tel_no.EraserGroup = "CLR1";
            this.txt_tel_no.Location = new System.Drawing.Point(132, 513);
            this.txt_tel_no.Name = "txt_tel_no";
            this.txt_tel_no.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_tel_no.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_tel_no.RequireMessage = null;
            this.txt_tel_no.Size = new System.Drawing.Size(750, 20);
            this.txt_tel_no.StyleController = this.layoutControl3;
            this.txt_tel_no.TabIndex = 7;
            this.txt_tel_no.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_tel_no_KeyDown);
            // 
            // txt_hp_no
            // 
            this.txt_hp_no.EditValue2 = null;
            this.txt_hp_no.EraserGroup = "CLR1";
            this.txt_hp_no.Location = new System.Drawing.Point(132, 241);
            this.txt_hp_no.Name = "txt_hp_no";
            this.txt_hp_no.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_hp_no.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_hp_no.RequireMessage = null;
            this.txt_hp_no.Size = new System.Drawing.Size(271, 20);
            this.txt_hp_no.StyleController = this.layoutControl3;
            this.txt_hp_no.TabIndex = 4;
            this.txt_hp_no.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_hp_no_KeyDown);
            // 
            // txt_e_mail
            // 
            this.txt_e_mail.EditValue2 = null;
            this.txt_e_mail.EraserGroup = "CLR1";
            this.txt_e_mail.Location = new System.Drawing.Point(132, 309);
            this.txt_e_mail.Name = "txt_e_mail";
            this.txt_e_mail.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_e_mail.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_e_mail.RequireMessage = null;
            this.txt_e_mail.Size = new System.Drawing.Size(271, 20);
            this.txt_e_mail.StyleController = this.layoutControl3;
            this.txt_e_mail.TabIndex = 8;
            this.txt_e_mail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_e_mail_KeyDown);
            // 
            // txt_person
            // 
            this.txt_person.EditValue2 = null;
            this.txt_person.EraserGroup = "CLR1";
            this.txt_person.Location = new System.Drawing.Point(132, 207);
            this.txt_person.Name = "txt_person";
            this.txt_person.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_person.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_person.RequireMessage = null;
            this.txt_person.Size = new System.Drawing.Size(271, 20);
            this.txt_person.StyleController = this.layoutControl3;
            this.txt_person.TabIndex = 3;
            this.txt_person.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_person_KeyDown);
            // 
            // txt_agency_name
            // 
            this.txt_agency_name.EditValue2 = null;
            this.txt_agency_name.EraserGroup = "CLR1";
            this.txt_agency_name.Location = new System.Drawing.Point(132, 173);
            this.txt_agency_name.Name = "txt_agency_name";
            this.txt_agency_name.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_agency_name.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_agency_name.RequireMessage = null;
            this.txt_agency_name.Size = new System.Drawing.Size(271, 20);
            this.txt_agency_name.StyleController = this.layoutControl3;
            this.txt_agency_name.TabIndex = 2;
            this.txt_agency_name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_agency_name_KeyDown);
            // 
            // txt_work_man
            // 
            this.txt_work_man.EditValue2 = null;
            this.txt_work_man.Enabled = false;
            this.txt_work_man.EraserGroup = "CLR1";
            this.txt_work_man.Location = new System.Drawing.Point(132, 139);
            this.txt_work_man.Name = "txt_work_man";
            this.txt_work_man.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_work_man.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_work_man.RequireMessage = null;
            this.txt_work_man.Size = new System.Drawing.Size(271, 20);
            this.txt_work_man.StyleController = this.layoutControl3;
            this.txt_work_man.TabIndex = 1;
            this.txt_work_man.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_work_man_KeyDown);
            // 
            // dt_plan_date
            // 
            this.dt_plan_date.EditValue = new System.DateTime(2019, 6, 7, 0, 0, 0, 0);
            this.dt_plan_date.IsRequire = true;
            this.dt_plan_date.Location = new System.Drawing.Point(132, 275);
            this.dt_plan_date.Name = "dt_plan_date";
            this.dt_plan_date.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(242)))), ((int)(((byte)(226)))));
            this.dt_plan_date.Properties.Appearance.Options.UseBackColor = true;
            this.dt_plan_date.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.dt_plan_date.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.dt_plan_date.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_plan_date.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_plan_date.Size = new System.Drawing.Size(101, 20);
            this.dt_plan_date.StyleController = this.layoutControl3;
            this.dt_plan_date.TabIndex = 6;
            this.dt_plan_date.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dt_plan_date_KeyDown);
            // 
            // txt_visit_area
            // 
            this.txt_visit_area.EditValue2 = null;
            this.txt_visit_area.EraserGroup = "CLR1";
            this.txt_visit_area.Location = new System.Drawing.Point(132, 343);
            this.txt_visit_area.Name = "txt_visit_area";
            this.txt_visit_area.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_visit_area.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_visit_area.RequireMessage = null;
            this.txt_visit_area.Size = new System.Drawing.Size(271, 20);
            this.txt_visit_area.StyleController = this.layoutControl3;
            this.txt_visit_area.TabIndex = 9;
            this.txt_visit_area.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_visit_area_KeyDown);
            // 
            // txt_visit_distant
            // 
            this.txt_visit_distant.EditValue = "0";
            this.txt_visit_distant.EditValue2 = null;
            this.txt_visit_distant.EraserGroup = "CLR1";
            this.txt_visit_distant.Location = new System.Drawing.Point(132, 377);
            this.txt_visit_distant.Name = "txt_visit_distant";
            this.txt_visit_distant.Properties.Appearance.Options.UseTextOptions = true;
            this.txt_visit_distant.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txt_visit_distant.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_visit_distant.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_visit_distant.Properties.DisplayFormat.FormatString = "###,###,##0";
            this.txt_visit_distant.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_visit_distant.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_visit_distant.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txt_visit_distant.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txt_visit_distant.RequireMessage = null;
            this.txt_visit_distant.Size = new System.Drawing.Size(271, 20);
            this.txt_visit_distant.StyleController = this.layoutControl3;
            this.txt_visit_distant.TabIndex = 10;
            this.txt_visit_distant.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_visit_distant_KeyDown);
            // 
            // cmb_move_type
            // 
            childHierarchy2.CodeCtrl = null;
            childHierarchy2.DbName = null;
            childHierarchy2.SpName = null;
            this.cmb_move_type.ChildHierarchyInfo = childHierarchy2;
            hierarchy2.DbName = null;
            hierarchy2.SpName = null;
            this.cmb_move_type.HierarchyInfo = hierarchy2;
            this.cmb_move_type.IsMultiLang = false;
            this.cmb_move_type.Location = new System.Drawing.Point(532, 343);
            this.cmb_move_type.Name = "cmb_move_type";
            this.cmb_move_type.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(242)))), ((int)(((byte)(226)))));
            this.cmb_move_type.Properties.Appearance.Options.UseBackColor = true;
            this.cmb_move_type.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmb_move_type.Properties.NullText = "";
            this.cmb_move_type.Size = new System.Drawing.Size(271, 20);
            this.cmb_move_type.StyleController = this.layoutControl3;
            this.cmb_move_type.TabIndex = 5;
            this.cmb_move_type.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmb_move_type_KeyDown);
            // 
            // txt_car_mileage
            // 
            this.txt_car_mileage.EditValue = "0";
            this.txt_car_mileage.EditValue2 = null;
            this.txt_car_mileage.EraserGroup = "CLR1";
            this.txt_car_mileage.Location = new System.Drawing.Point(532, 377);
            this.txt_car_mileage.Name = "txt_car_mileage";
            this.txt_car_mileage.Properties.Appearance.Options.UseTextOptions = true;
            this.txt_car_mileage.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txt_car_mileage.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_car_mileage.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_car_mileage.Properties.DisplayFormat.FormatString = "###,###,##0";
            this.txt_car_mileage.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_car_mileage.Properties.EditFormat.FormatString = "###,###,##0";
            this.txt_car_mileage.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_car_mileage.Properties.Mask.EditMask = "###,###,##0";
            this.txt_car_mileage.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txt_car_mileage.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txt_car_mileage.RequireMessage = null;
            this.txt_car_mileage.Size = new System.Drawing.Size(271, 20);
            this.txt_car_mileage.StyleController = this.layoutControl3;
            this.txt_car_mileage.TabIndex = 9;
            this.txt_car_mileage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_car_mileage_KeyDown);
            // 
            // txt_oil_price
            // 
            this.txt_oil_price.EditValue = "0";
            this.txt_oil_price.EditValue2 = null;
            this.txt_oil_price.EraserGroup = "CLR1";
            this.txt_oil_price.Location = new System.Drawing.Point(132, 411);
            this.txt_oil_price.Name = "txt_oil_price";
            this.txt_oil_price.Properties.Appearance.Options.UseTextOptions = true;
            this.txt_oil_price.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txt_oil_price.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_oil_price.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_oil_price.Properties.DisplayFormat.FormatString = "###,###,##0";
            this.txt_oil_price.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_oil_price.Properties.EditFormat.FormatString = "###,###,##0";
            this.txt_oil_price.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_oil_price.Properties.Mask.EditMask = "###,###,##0";
            this.txt_oil_price.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txt_oil_price.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txt_oil_price.RequireMessage = null;
            this.txt_oil_price.Size = new System.Drawing.Size(271, 20);
            this.txt_oil_price.StyleController = this.layoutControl3;
            this.txt_oil_price.TabIndex = 10;
            this.txt_oil_price.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_oil_price_KeyDown);
            // 
            // txt_packing_price
            // 
            this.txt_packing_price.EditValue = "0";
            this.txt_packing_price.EditValue2 = null;
            this.txt_packing_price.EraserGroup = "CLR1";
            this.txt_packing_price.Location = new System.Drawing.Point(532, 411);
            this.txt_packing_price.Name = "txt_packing_price";
            this.txt_packing_price.Properties.Appearance.Options.UseTextOptions = true;
            this.txt_packing_price.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txt_packing_price.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_packing_price.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_packing_price.Properties.DisplayFormat.FormatString = "###,###,##0";
            this.txt_packing_price.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_packing_price.Properties.EditFormat.FormatString = "###,###,##0";
            this.txt_packing_price.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_packing_price.Properties.Mask.EditMask = "###,###,##0";
            this.txt_packing_price.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txt_packing_price.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txt_packing_price.RequireMessage = null;
            this.txt_packing_price.Size = new System.Drawing.Size(271, 20);
            this.txt_packing_price.StyleController = this.layoutControl3;
            this.txt_packing_price.TabIndex = 10;
            this.txt_packing_price.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_packing_price_KeyDown);
            // 
            // txt_gate_price
            // 
            this.txt_gate_price.EditValue = "0";
            this.txt_gate_price.EditValue2 = null;
            this.txt_gate_price.EraserGroup = "CLR1";
            this.txt_gate_price.Location = new System.Drawing.Point(132, 445);
            this.txt_gate_price.Name = "txt_gate_price";
            this.txt_gate_price.Properties.Appearance.Options.UseTextOptions = true;
            this.txt_gate_price.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txt_gate_price.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_gate_price.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_gate_price.Properties.DisplayFormat.FormatString = "###,###,##0";
            this.txt_gate_price.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_gate_price.Properties.EditFormat.FormatString = "###,###,##0";
            this.txt_gate_price.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_gate_price.Properties.Mask.EditMask = "###,###,##0";
            this.txt_gate_price.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txt_gate_price.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txt_gate_price.RequireMessage = null;
            this.txt_gate_price.Size = new System.Drawing.Size(271, 20);
            this.txt_gate_price.StyleController = this.layoutControl3;
            this.txt_gate_price.TabIndex = 10;
            this.txt_gate_price.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_gate_price_KeyDown);
            // 
            // txt_sales_price
            // 
            this.txt_sales_price.EditValue = "0";
            this.txt_sales_price.EditValue2 = null;
            this.txt_sales_price.EraserGroup = "CLR1";
            this.txt_sales_price.Location = new System.Drawing.Point(532, 445);
            this.txt_sales_price.Name = "txt_sales_price";
            this.txt_sales_price.Properties.Appearance.Options.UseTextOptions = true;
            this.txt_sales_price.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txt_sales_price.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_sales_price.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_sales_price.Properties.DisplayFormat.FormatString = "###,###,##0";
            this.txt_sales_price.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_sales_price.Properties.EditFormat.FormatString = "###,###,##0";
            this.txt_sales_price.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txt_sales_price.Properties.Mask.EditMask = "###,###,##0";
            this.txt_sales_price.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txt_sales_price.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txt_sales_price.RequireMessage = null;
            this.txt_sales_price.Size = new System.Drawing.Size(271, 20);
            this.txt_sales_price.StyleController = this.layoutControl3;
            this.txt_sales_price.TabIndex = 10;
            this.txt_sales_price.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_sales_price_KeyDown);
            // 
            // txt_remark
            // 
            this.txt_remark.EditValue2 = null;
            this.txt_remark.EraserGroup = "CLR1";
            this.txt_remark.Location = new System.Drawing.Point(132, 547);
            this.txt_remark.Name = "txt_remark";
            this.txt_remark.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_remark.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_remark.RequireMessage = null;
            this.txt_remark.Size = new System.Drawing.Size(750, 20);
            this.txt_remark.StyleController = this.layoutControl3;
            this.txt_remark.TabIndex = 7;
            this.txt_remark.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_remark_KeyDown_1);
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup3.GroupBordersVisible = false;
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem8,
            this.layoutControlItem9,
            this.ly_advice_type,
            this.layoutControlItem11,
            this.emptySpaceItem2,
            this.layoutControlItem10,
            this.item1,
            this.layoutControlItem19,
            this.layoutControlItem3,
            this.layoutControlItem6,
            this.emptySpaceItem3,
            this.layoutControlItem13,
            this.emptySpaceItem1,
            this.layoutControlItem5,
            this.layoutControlItem7,
            this.layoutControlItem14,
            this.layoutControlItem2,
            this.ly_advice_type1,
            this.layoutControlItem15,
            this.item4,
            this.layoutControlItem12,
            this.item7,
            this.item8,
            this.item9,
            this.layoutControlItem4});
            this.layoutControlGroup3.Name = "Root";
            this.layoutControlGroup3.Padding = new DevExpress.XtraLayout.Utils.Padding(5, 5, 5, 2);
            this.layoutControlGroup3.Size = new System.Drawing.Size(889, 747);
            this.layoutControlGroup3.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem1.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem1.Control = this.dt_visit_date;
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 93);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(230, 34);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(230, 34);
            this.layoutControlItem1.Name = "item0";
            this.layoutControlItem1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem1.Size = new System.Drawing.Size(230, 34);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.Text = "1. 방문일자";
            this.layoutControlItem1.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem1.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem1.TextToControlDistance = 5;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem8.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem8.Control = this.txt_agency_name;
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 161);
            this.layoutControlItem8.MaxSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem8.MinSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem8.Name = "layoutControlItem3";
            this.layoutControlItem8.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem8.Size = new System.Drawing.Size(400, 34);
            this.layoutControlItem8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem8.Text = "3. 거래처명";
            this.layoutControlItem8.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem8.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem8.TextToControlDistance = 5;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem9.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem9.Control = this.txt_person;
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 195);
            this.layoutControlItem9.MaxSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem9.Name = "layoutControlItem4";
            this.layoutControlItem9.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem9.Size = new System.Drawing.Size(879, 34);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.Text = "4. 업체 담당자";
            this.layoutControlItem9.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem9.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem9.TextToControlDistance = 5;
            // 
            // ly_advice_type
            // 
            this.ly_advice_type.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.ly_advice_type.AppearanceItemCaption.Options.UseFont = true;
            this.ly_advice_type.Control = this.cmb_advice_type;
            this.ly_advice_type.Location = new System.Drawing.Point(0, 467);
            this.ly_advice_type.MaxSize = new System.Drawing.Size(400, 34);
            this.ly_advice_type.MinSize = new System.Drawing.Size(400, 34);
            this.ly_advice_type.Name = "ly_advice_type";
            this.ly_advice_type.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.ly_advice_type.Size = new System.Drawing.Size(879, 34);
            this.ly_advice_type.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.ly_advice_type.Text = "16. 상담구분";
            this.ly_advice_type.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.ly_advice_type.TextSize = new System.Drawing.Size(120, 20);
            this.ly_advice_type.TextToControlDistance = 5;
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem11.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem11.Control = this.txt_tel_no;
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 501);
            this.layoutControlItem11.MaxSize = new System.Drawing.Size(0, 34);
            this.layoutControlItem11.MinSize = new System.Drawing.Size(179, 34);
            this.layoutControlItem11.Name = "layoutControlItem7";
            this.layoutControlItem11.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem11.Size = new System.Drawing.Size(879, 34);
            this.layoutControlItem11.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem11.Text = "17. 전화번호";
            this.layoutControlItem11.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem11.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem11.TextToControlDistance = 5;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem2.Location = new System.Drawing.Point(230, 93);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(449, 34);
            this.emptySpaceItem2.Text = "emptySpaceItem1";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem10.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem10.Control = this.txt_hp_no;
            this.layoutControlItem10.CustomizationFormText = "5. 휴대폰번호";
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 229);
            this.layoutControlItem10.MaxSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem10.MinSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem10.Name = "layoutControlItem6";
            this.layoutControlItem10.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem10.Size = new System.Drawing.Size(879, 34);
            this.layoutControlItem10.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem10.Text = "5. 휴대폰번호";
            this.layoutControlItem10.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem10.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem10.TextToControlDistance = 5;
            // 
            // item1
            // 
            this.item1.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.item1.AppearanceItemCaption.Options.UseFont = true;
            this.item1.Control = this.dt_plan_date;
            this.item1.ControlAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.item1.CustomizationFormText = "방문일자";
            this.item1.Location = new System.Drawing.Point(0, 263);
            this.item1.MaxSize = new System.Drawing.Size(230, 34);
            this.item1.MinSize = new System.Drawing.Size(230, 34);
            this.item1.Name = "item2";
            this.item1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.item1.Size = new System.Drawing.Size(230, 34);
            this.item1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.item1.Text = "6. 방문 예정일자";
            this.item1.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.item1.TextSize = new System.Drawing.Size(120, 20);
            this.item1.TextToControlDistance = 5;
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem19.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem19.Control = this.txt_e_mail;
            this.layoutControlItem19.Location = new System.Drawing.Point(0, 297);
            this.layoutControlItem19.MaxSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem19.MinSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem19.Name = "layoutControlItem5";
            this.layoutControlItem19.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem19.Size = new System.Drawing.Size(879, 34);
            this.layoutControlItem19.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem19.Text = "7. 이메일";
            this.layoutControlItem19.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem19.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem19.TextToControlDistance = 5;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem3.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem3.Control = this.txt_visit_distant;
            this.layoutControlItem3.CustomizationFormText = "전화번호";
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 365);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem3.Name = "item3";
            this.layoutControlItem3.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem3.Size = new System.Drawing.Size(400, 34);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.Text = "10. 운행거리(Km)";
            this.layoutControlItem3.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem3.TextToControlDistance = 5;
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem6.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem6.Control = this.txt_work_man;
            this.layoutControlItem6.ControlAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 127);
            this.layoutControlItem6.MaxSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem6.MinSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem6.Name = "layoutControlItem1";
            this.layoutControlItem6.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem6.Size = new System.Drawing.Size(879, 34);
            this.layoutControlItem6.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem6.Text = "2. 담당자";
            this.layoutControlItem6.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem6.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem6.TextToControlDistance = 5;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.Location = new System.Drawing.Point(230, 263);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(649, 34);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.efwLabel1;
            this.layoutControlItem13.ControlAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.layoutControlItem13.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(879, 45);
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 45);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(879, 48);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.efwSimpleButton6;
            this.layoutControlItem5.ControlAlignment = System.Drawing.ContentAlignment.MiddleRight;
            this.layoutControlItem5.Location = new System.Drawing.Point(679, 93);
            this.layoutControlItem5.MaxSize = new System.Drawing.Size(100, 34);
            this.layoutControlItem5.MinSize = new System.Drawing.Size(100, 34);
            this.layoutControlItem5.Name = "item5";
            this.layoutControlItem5.Size = new System.Drawing.Size(100, 34);
            this.layoutControlItem5.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.efwSimpleButton7;
            this.layoutControlItem7.ControlAlignment = System.Drawing.ContentAlignment.MiddleRight;
            this.layoutControlItem7.Location = new System.Drawing.Point(779, 93);
            this.layoutControlItem7.MaxSize = new System.Drawing.Size(100, 34);
            this.layoutControlItem7.MinSize = new System.Drawing.Size(100, 34);
            this.layoutControlItem7.Name = "item6";
            this.layoutControlItem7.Size = new System.Drawing.Size(100, 34);
            this.layoutControlItem7.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.efwLabel4;
            this.layoutControlItem14.Location = new System.Drawing.Point(400, 161);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 9, 2);
            this.layoutControlItem14.Size = new System.Drawing.Size(479, 34);
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem2.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem2.Control = this.txt_visit_area;
            this.layoutControlItem2.CustomizationFormText = "전화번호";
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 331);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem2.Size = new System.Drawing.Size(400, 34);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.Text = "8. 운행구간(지역)";
            this.layoutControlItem2.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem2.TextToControlDistance = 5;
            // 
            // ly_advice_type1
            // 
            this.ly_advice_type1.Control = this.cmb_move_type;
            this.ly_advice_type1.CustomizationFormText = "10. 상담구분";
            this.ly_advice_type1.Location = new System.Drawing.Point(400, 331);
            this.ly_advice_type1.MaxSize = new System.Drawing.Size(400, 34);
            this.ly_advice_type1.MinSize = new System.Drawing.Size(400, 34);
            this.ly_advice_type1.Name = "ly_advice_type1";
            this.ly_advice_type1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.ly_advice_type1.Size = new System.Drawing.Size(479, 34);
            this.ly_advice_type1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.ly_advice_type1.Text = "9.  이동수단";
            this.ly_advice_type1.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.ly_advice_type1.TextSize = new System.Drawing.Size(120, 20);
            this.ly_advice_type1.TextToControlDistance = 5;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.txt_car_mileage;
            this.layoutControlItem15.CustomizationFormText = "전화번호";
            this.layoutControlItem15.Location = new System.Drawing.Point(400, 365);
            this.layoutControlItem15.MaxSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem15.MinSize = new System.Drawing.Size(400, 34);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem15.Size = new System.Drawing.Size(479, 34);
            this.layoutControlItem15.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem15.Text = "11. 차량연비";
            this.layoutControlItem15.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem15.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem15.TextToControlDistance = 5;
            // 
            // item4
            // 
            this.item4.Control = this.txt_oil_price;
            this.item4.CustomizationFormText = "전화번호";
            this.item4.Location = new System.Drawing.Point(0, 399);
            this.item4.MaxSize = new System.Drawing.Size(400, 34);
            this.item4.MinSize = new System.Drawing.Size(400, 34);
            this.item4.Name = "item4";
            this.item4.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.item4.Size = new System.Drawing.Size(400, 34);
            this.item4.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.item4.Text = "12. 유류평균가격";
            this.item4.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.item4.TextSize = new System.Drawing.Size(120, 20);
            this.item4.TextToControlDistance = 5;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F);
            this.layoutControlItem12.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem12.Control = this.txt_content;
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 569);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(879, 171);
            this.layoutControlItem12.Text = "19. 상담내역";
            this.layoutControlItem12.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem12.TextSize = new System.Drawing.Size(120, 14);
            this.layoutControlItem12.TextToControlDistance = 5;
            // 
            // item7
            // 
            this.item7.Control = this.txt_packing_price;
            this.item7.CustomizationFormText = "전화번호";
            this.item7.Location = new System.Drawing.Point(400, 399);
            this.item7.MaxSize = new System.Drawing.Size(400, 34);
            this.item7.MinSize = new System.Drawing.Size(400, 34);
            this.item7.Name = "item7";
            this.item7.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.item7.Size = new System.Drawing.Size(479, 34);
            this.item7.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.item7.Text = "13. 주차비";
            this.item7.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.item7.TextSize = new System.Drawing.Size(120, 20);
            this.item7.TextToControlDistance = 5;
            // 
            // item8
            // 
            this.item8.Control = this.txt_gate_price;
            this.item8.CustomizationFormText = "전화번호";
            this.item8.Location = new System.Drawing.Point(0, 433);
            this.item8.MaxSize = new System.Drawing.Size(400, 34);
            this.item8.MinSize = new System.Drawing.Size(400, 34);
            this.item8.Name = "item8";
            this.item8.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.item8.Size = new System.Drawing.Size(400, 34);
            this.item8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.item8.Text = "14. 톨게이트비";
            this.item8.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.item8.TextSize = new System.Drawing.Size(120, 20);
            this.item8.TextToControlDistance = 5;
            // 
            // item9
            // 
            this.item9.Control = this.txt_sales_price;
            this.item9.CustomizationFormText = "전화번호";
            this.item9.Location = new System.Drawing.Point(400, 433);
            this.item9.MaxSize = new System.Drawing.Size(400, 34);
            this.item9.MinSize = new System.Drawing.Size(400, 34);
            this.item9.Name = "item9";
            this.item9.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.item9.Size = new System.Drawing.Size(479, 34);
            this.item9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.item9.Text = "15. 접대비";
            this.item9.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.item9.TextSize = new System.Drawing.Size(120, 20);
            this.item9.TextToControlDistance = 5;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.txt_remark;
            this.layoutControlItem4.CustomizationFormText = "비고";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 535);
            this.layoutControlItem4.MaxSize = new System.Drawing.Size(0, 34);
            this.layoutControlItem4.MinSize = new System.Drawing.Size(179, 34);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 7, 2);
            this.layoutControlItem4.Size = new System.Drawing.Size(879, 34);
            this.layoutControlItem4.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem4.Text = "18. 비고";
            this.layoutControlItem4.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem4.TextSize = new System.Drawing.Size(120, 20);
            this.layoutControlItem4.TextToControlDistance = 5;
            // 
            // splitterControl1
            // 
            this.splitterControl1.Location = new System.Drawing.Point(910, 35);
            this.splitterControl1.Name = "splitterControl1";
            this.splitterControl1.Size = new System.Drawing.Size(5, 772);
            this.splitterControl1.TabIndex = 48;
            this.splitterControl1.TabStop = false;
            // 
            // efwGroupControl1
            // 
            this.efwGroupControl1.CaptionImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwGroupControl1.CaptionImageOptions.Image")));
            this.efwGroupControl1.Controls.Add(this.efwGridControl1);
            this.efwGroupControl1.Controls.Add(this.efwPanelControl1);
            this.efwGroupControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.efwGroupControl1.IsMultiLang = false;
            this.efwGroupControl1.Location = new System.Drawing.Point(915, 35);
            this.efwGroupControl1.Name = "efwGroupControl1";
            this.efwGroupControl1.Size = new System.Drawing.Size(683, 772);
            this.efwGroupControl1.TabIndex = 49;
            this.efwGroupControl1.Text = "영업일지 목록";
            // 
            // efwGridControl1
            // 
            this.efwGridControl1.BindSet = null;
            this.efwGridControl1.DBName = "";
            serviceInfo1.InstanceName = "";
            serviceInfo1.IsUserIDAdd = true;
            serviceInfo1.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo1.ParamsInfo")));
            serviceInfo1.ProcName = "";
            serviceInfo1.UserParams = null;
            this.efwGridControl1.DeleteServiceInfo = serviceInfo1;
            this.efwGridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            serviceInfo2.InstanceName = "";
            serviceInfo2.IsUserIDAdd = true;
            serviceInfo2.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo2.ParamsInfo")));
            serviceInfo2.ProcName = "";
            serviceInfo2.UserParams = null;
            this.efwGridControl1.InsertServiceInfo = serviceInfo2;
            this.efwGridControl1.IsAddExcelBtn = true;
            this.efwGridControl1.isAddPrintBtn = true;
            this.efwGridControl1.IsMultiLang = false;
            this.efwGridControl1.Location = new System.Drawing.Point(2, 105);
            this.efwGridControl1.MainView = this.gridView1;
            this.efwGridControl1.Name = "efwGridControl1";
            this.efwGridControl1.NowRowHandle = 0;
            this.efwGridControl1.PKColumns = ((System.Collections.ArrayList)(resources.GetObject("efwGridControl1.PKColumns")));
            this.efwGridControl1.PrevRowHandle = -2147483648;
            this.efwGridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEdit1,
            this.repositoryItemMemoExEdit1,
            this.repositoryItemMemoEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryItemCheckEdit3});
            this.efwGridControl1.Size = new System.Drawing.Size(679, 665);
            this.efwGridControl1.TabIndex = 44;
            this.efwGridControl1.TableName = "";
            this.efwGridControl1.TabStop = false;
            serviceInfo3.InstanceName = "";
            serviceInfo3.IsUserIDAdd = true;
            serviceInfo3.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo3.ParamsInfo")));
            serviceInfo3.ProcName = "";
            serviceInfo3.UserParams = null;
            this.efwGridControl1.UpdateServiceInfo = serviceInfo3;
            this.efwGridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn15,
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn18,
            this.gridColumn19,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn22});
            this.gridView1.GridControl = this.efwGridControl1;
            this.gridView1.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Count, "", null, "건수 : {0}")});
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowFooter = true;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "idx";
            this.gridColumn1.FieldName = "idx";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "방문일";
            this.gridColumn2.FieldName = "visit_date";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 0;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "영업담당자";
            this.gridColumn3.FieldName = "work_man";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 1;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "거래처명";
            this.gridColumn4.FieldName = "agency_name";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 2;
            this.gridColumn4.Width = 168;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "업체담당자";
            this.gridColumn5.FieldName = "person";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 3;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "상담구분";
            this.gridColumn6.FieldName = "advice_type_nm";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 4;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "방문예정일";
            this.gridColumn7.FieldName = "plan_date";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 5;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "전화번호";
            this.gridColumn8.FieldName = "tel_no";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 6;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "E-메일";
            this.gridColumn9.FieldName = "e_mail";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 7;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "방문지역";
            this.gridColumn10.FieldName = "visit_area";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 8;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "운행거리(Km)";
            this.gridColumn11.FieldName = "visit_distant";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.AllowEdit = false;
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 9;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "내용";
            this.gridColumn12.FieldName = "content";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 10;
            this.gridColumn12.Width = 261;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "비고";
            this.gridColumn13.FieldName = "remark";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 11;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "등록일";
            this.gridColumn14.FieldName = "reg_date";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "수정일";
            this.gridColumn15.FieldName = "modify_date";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "영업상담코드";
            this.gridColumn16.FieldName = "advice_type_cd";
            this.gridColumn16.Name = "gridColumn16";
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "이동수단";
            this.gridColumn17.FieldName = "move_type";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.OptionsColumn.AllowEdit = false;
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 12;
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "연비";
            this.gridColumn18.FieldName = "car_mileage";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsColumn.AllowEdit = false;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 13;
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "유류단가";
            this.gridColumn19.FieldName = "oil_price";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsColumn.AllowEdit = false;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 14;
            // 
            // gridColumn20
            // 
            this.gridColumn20.Caption = "주차비";
            this.gridColumn20.FieldName = "packing_price";
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.OptionsColumn.AllowEdit = false;
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 15;
            // 
            // gridColumn21
            // 
            this.gridColumn21.Caption = "톨게이트비";
            this.gridColumn21.FieldName = "gate_price";
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.OptionsColumn.AllowEdit = false;
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 16;
            // 
            // gridColumn22
            // 
            this.gridColumn22.Caption = "접대비";
            this.gridColumn22.FieldName = "sales_price";
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.OptionsColumn.AllowEdit = false;
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 17;
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            // 
            // repositoryItemMemoExEdit1
            // 
            this.repositoryItemMemoExEdit1.AutoHeight = false;
            this.repositoryItemMemoExEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit1.Name = "repositoryItemMemoExEdit1";
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            this.repositoryItemCheckEdit3.ValueChecked = "Y";
            this.repositoryItemCheckEdit3.ValueUnchecked = "N";
            // 
            // efwPanelControl1
            // 
            this.efwPanelControl1.Controls.Add(this.efwTextEdit1);
            this.efwPanelControl1.Controls.Add(this.efwTextEdit2);
            this.efwPanelControl1.Controls.Add(this.btnOpen);
            this.efwPanelControl1.Controls.Add(this.txtCoidNo);
            this.efwPanelControl1.Controls.Add(this.txt_idx);
            this.efwPanelControl1.Controls.Add(this.txt_search);
            this.efwPanelControl1.Controls.Add(this.efwLabel3);
            this.efwPanelControl1.Controls.Add(this.efwLabel2);
            this.efwPanelControl1.Controls.Add(this.dt_s_date);
            this.efwPanelControl1.Controls.Add(this.dt_e_date);
            this.efwPanelControl1.Controls.Add(this.rb_date_type);
            this.efwPanelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwPanelControl1.Location = new System.Drawing.Point(2, 23);
            this.efwPanelControl1.Name = "efwPanelControl1";
            this.efwPanelControl1.Size = new System.Drawing.Size(679, 82);
            this.efwPanelControl1.TabIndex = 43;
            // 
            // efwTextEdit1
            // 
            this.efwTextEdit1.EditValue2 = null;
            this.efwTextEdit1.EraserGroup = "CLR1";
            this.efwTextEdit1.Location = new System.Drawing.Point(569, 37);
            this.efwTextEdit1.Name = "efwTextEdit1";
            this.efwTextEdit1.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.efwTextEdit1.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.efwTextEdit1.RequireMessage = null;
            this.efwTextEdit1.Size = new System.Drawing.Size(90, 20);
            this.efwTextEdit1.TabIndex = 58;
            this.efwTextEdit1.Visible = false;
            // 
            // efwTextEdit2
            // 
            this.efwTextEdit2.EditValue2 = null;
            this.efwTextEdit2.EraserGroup = "CLR1";
            this.efwTextEdit2.Location = new System.Drawing.Point(569, 11);
            this.efwTextEdit2.Name = "efwTextEdit2";
            this.efwTextEdit2.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.efwTextEdit2.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.efwTextEdit2.RequireMessage = null;
            this.efwTextEdit2.Size = new System.Drawing.Size(66, 20);
            this.efwTextEdit2.TabIndex = 57;
            this.efwTextEdit2.Visible = false;
            // 
            // btnOpen
            // 
            this.btnOpen.ButtonType = Easy.Framework.Util.BtnType.Search;
            this.btnOpen.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnOpen.ImageOptions.Image")));
            this.btnOpen.IsMultiLang = false;
            this.btnOpen.Location = new System.Drawing.Point(431, 24);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(99, 33);
            this.btnOpen.StyleController = this.layoutControl3;
            this.btnOpen.TabIndex = 56;
            this.btnOpen.Text = "조회";
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // txtCoidNo
            // 
            this.txtCoidNo.EditValue2 = null;
            this.txtCoidNo.EraserGroup = "CLR1";
            this.txtCoidNo.Location = new System.Drawing.Point(719, 24);
            this.txtCoidNo.Name = "txtCoidNo";
            this.txtCoidNo.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtCoidNo.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtCoidNo.RequireMessage = null;
            this.txtCoidNo.Size = new System.Drawing.Size(19, 20);
            this.txtCoidNo.TabIndex = 55;
            this.txtCoidNo.Visible = false;
            // 
            // txt_idx
            // 
            this.txt_idx.EditValue2 = null;
            this.txt_idx.EraserGroup = "CLR1";
            this.txt_idx.Location = new System.Drawing.Point(719, 6);
            this.txt_idx.Name = "txt_idx";
            this.txt_idx.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_idx.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_idx.RequireMessage = null;
            this.txt_idx.Size = new System.Drawing.Size(23, 20);
            this.txt_idx.TabIndex = 49;
            this.txt_idx.Visible = false;
            // 
            // txt_search
            // 
            this.txt_search.EditValue2 = null;
            this.txt_search.EraserGroup = "CLR1";
            this.txt_search.Location = new System.Drawing.Point(182, 47);
            this.txt_search.Name = "txt_search";
            this.txt_search.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_search.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_search.RequireMessage = null;
            this.txt_search.Size = new System.Drawing.Size(225, 20);
            this.txt_search.TabIndex = 48;
            // 
            // efwLabel3
            // 
            this.efwLabel3.EraserGroup = null;
            this.efwLabel3.IsMultiLang = false;
            this.efwLabel3.Location = new System.Drawing.Point(105, 50);
            this.efwLabel3.Name = "efwLabel3";
            this.efwLabel3.Size = new System.Drawing.Size(40, 14);
            this.efwLabel3.TabIndex = 47;
            this.efwLabel3.Text = "거래처명";
            // 
            // efwLabel2
            // 
            this.efwLabel2.EraserGroup = null;
            this.efwLabel2.IsMultiLang = false;
            this.efwLabel2.Location = new System.Drawing.Point(292, 18);
            this.efwLabel2.Name = "efwLabel2";
            this.efwLabel2.Size = new System.Drawing.Size(9, 14);
            this.efwLabel2.TabIndex = 46;
            this.efwLabel2.Text = "~";
            // 
            // dt_s_date
            // 
            this.dt_s_date.EditValue = new System.DateTime(2019, 6, 7, 0, 0, 0, 0);
            this.dt_s_date.IsRequire = true;
            this.dt_s_date.Location = new System.Drawing.Point(182, 15);
            this.dt_s_date.Name = "dt_s_date";
            this.dt_s_date.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(242)))), ((int)(((byte)(226)))));
            this.dt_s_date.Properties.Appearance.Options.UseBackColor = true;
            this.dt_s_date.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.dt_s_date.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.dt_s_date.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_s_date.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_s_date.Size = new System.Drawing.Size(103, 20);
            this.dt_s_date.TabIndex = 44;
            // 
            // dt_e_date
            // 
            this.dt_e_date.EditValue = new System.DateTime(2019, 6, 7, 0, 0, 0, 0);
            this.dt_e_date.IsRequire = true;
            this.dt_e_date.Location = new System.Drawing.Point(308, 15);
            this.dt_e_date.Name = "dt_e_date";
            this.dt_e_date.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(242)))), ((int)(((byte)(226)))));
            this.dt_e_date.Properties.Appearance.Options.UseBackColor = true;
            this.dt_e_date.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.dt_e_date.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.dt_e_date.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_e_date.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_e_date.Size = new System.Drawing.Size(99, 20);
            this.dt_e_date.TabIndex = 45;
            // 
            // rb_date_type
            // 
            this.rb_date_type.IsMultiLang = false;
            this.rb_date_type.Location = new System.Drawing.Point(17, 14);
            this.rb_date_type.Name = "rb_date_type";
            this.rb_date_type.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.rb_date_type.Properties.Appearance.Options.UseBackColor = true;
            this.rb_date_type.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.rb_date_type.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.rb_date_type.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rb_date_type.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("V", "방문일"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("P", "방문예정일")});
            this.rb_date_type.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rb_date_type.RequireMessage = null;
            this.rb_date_type.Size = new System.Drawing.Size(159, 23);
            this.rb_date_type.TabIndex = 43;
            // 
            // frmTM05
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.efwGroupControl1);
            this.Controls.Add(this.splitterControl1);
            this.Controls.Add(this.efwGroupControl5);
            this.Name = "frmTM05";
            this.Size = new System.Drawing.Size(1601, 807);
            this.Load += new System.EventHandler(this.FrmLoadEvent);
            this.Controls.SetChildIndex(this.efwGroupControl5, 0);
            this.Controls.SetChildIndex(this.splitterControl1, 0);
            this.Controls.SetChildIndex(this.efwGroupControl1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl5)).EndInit();
            this.efwGroupControl5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl3)).EndInit();
            this.layoutControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txt_content.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_visit_date.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_visit_date.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_advice_type.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_tel_no.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_hp_no.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_e_mail.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_person.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_agency_name.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_work_man.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_plan_date.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_plan_date.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_visit_area.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_visit_distant.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_move_type.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_car_mileage.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_oil_price.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_packing_price.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_gate_price.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_sales_price.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_remark.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ly_advice_type)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ly_advice_type1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl1)).EndInit();
            this.efwGroupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwPanelControl1)).EndInit();
            this.efwPanelControl1.ResumeLayout(false);
            this.efwPanelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.efwTextEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwTextEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCoidNo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_idx.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_search.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_s_date.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_s_date.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_e_date.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_e_date.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rb_date_type.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Easy.Framework.WinForm.Control.efwGroupControl efwGroupControl5;
        private DevExpress.XtraLayout.LayoutControl layoutControl3;
        private Easy.Framework.WinForm.Control.efwMemoEdit txt_content;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton7;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton6;
        private Easy.Framework.WinForm.Control.efwDateEdit dt_visit_date;
        private Easy.Framework.WinForm.Control.efwLookUpEdit cmb_advice_type;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_tel_no;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_hp_no;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_e_mail;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_person;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_agency_name;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_work_man;
        private Easy.Framework.WinForm.Control.efwDateEdit dt_plan_date;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_visit_area;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_visit_distant;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem ly_advice_type;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem item1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraEditors.SplitterControl splitterControl1;
        private Easy.Framework.WinForm.Control.efwGroupControl efwGroupControl1;
        private Easy.Framework.WinForm.Control.efwPanelControl efwPanelControl1;
        private Easy.Framework.WinForm.Control.efwTextEdit txtCoidNo;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_idx;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_search;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel3;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel2;
        private Easy.Framework.WinForm.Control.efwDateEdit dt_s_date;
        private Easy.Framework.WinForm.Control.efwDateEdit dt_e_date;
        private Easy.Framework.WinForm.Control.efwRadioGroup rb_date_type;
        private Easy.Framework.WinForm.Control.efwSimpleButton btnOpen;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private Easy.Framework.WinForm.Control.efwGridControl efwGridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private Easy.Framework.WinForm.Control.efwTextEdit efwTextEdit1;
        private Easy.Framework.WinForm.Control.efwTextEdit efwTextEdit2;
        private Easy.Framework.WinForm.Control.efwLookUpEdit cmb_move_type;
        private DevExpress.XtraLayout.LayoutControlItem ly_advice_type1;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_car_mileage;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_oil_price;
        private DevExpress.XtraLayout.LayoutControlItem item4;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_packing_price;
        private DevExpress.XtraLayout.LayoutControlItem item7;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_gate_price;
        private DevExpress.XtraLayout.LayoutControlItem item8;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_sales_price;
        private DevExpress.XtraLayout.LayoutControlItem item9;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_remark;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
    }
}