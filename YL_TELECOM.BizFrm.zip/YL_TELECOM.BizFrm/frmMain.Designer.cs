﻿namespace YL_TELECOM.BizFrm
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.efwPnlBody = new Easy.Framework.WinForm.Control.efwPanelControl();
            this.btnTM01 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwPanelControl1 = new Easy.Framework.WinForm.Control.efwPanelControl();
            this.efwSimpleButton7 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton6 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton5 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton4 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton3 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton1 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.btnTM02 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton2 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton8 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton9 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.efwPnlBody)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwPanelControl1)).BeginInit();
            this.efwPanelControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // efwPnlBody
            // 
            this.efwPnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.efwPnlBody.Location = new System.Drawing.Point(123, 0);
            this.efwPnlBody.Name = "efwPnlBody";
            this.efwPnlBody.Size = new System.Drawing.Size(1275, 808);
            this.efwPnlBody.TabIndex = 13;
            // 
            // btnTM01
            // 
            this.btnTM01.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTM01.IsMultiLang = false;
            this.btnTM01.Location = new System.Drawing.Point(2, 2);
            this.btnTM01.Name = "btnTM01";
            this.btnTM01.Size = new System.Drawing.Size(119, 35);
            this.btnTM01.TabIndex = 0;
            this.btnTM01.Text = "frmTM01";
            this.btnTM01.Click += new System.EventHandler(this.BtnTM01_Click);
            // 
            // efwPanelControl1
            // 
            this.efwPanelControl1.Controls.Add(this.efwSimpleButton9);
            this.efwPanelControl1.Controls.Add(this.efwSimpleButton8);
            this.efwPanelControl1.Controls.Add(this.efwSimpleButton7);
            this.efwPanelControl1.Controls.Add(this.efwSimpleButton6);
            this.efwPanelControl1.Controls.Add(this.efwSimpleButton5);
            this.efwPanelControl1.Controls.Add(this.efwSimpleButton4);
            this.efwPanelControl1.Controls.Add(this.efwSimpleButton3);
            this.efwPanelControl1.Controls.Add(this.efwSimpleButton1);
            this.efwPanelControl1.Controls.Add(this.btnTM02);
            this.efwPanelControl1.Controls.Add(this.efwSimpleButton2);
            this.efwPanelControl1.Controls.Add(this.btnTM01);
            this.efwPanelControl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.efwPanelControl1.Location = new System.Drawing.Point(0, 0);
            this.efwPanelControl1.Name = "efwPanelControl1";
            this.efwPanelControl1.Size = new System.Drawing.Size(123, 808);
            this.efwPanelControl1.TabIndex = 12;
            // 
            // efwSimpleButton7
            // 
            this.efwSimpleButton7.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwSimpleButton7.IsMultiLang = false;
            this.efwSimpleButton7.Location = new System.Drawing.Point(2, 247);
            this.efwSimpleButton7.Name = "efwSimpleButton7";
            this.efwSimpleButton7.Size = new System.Drawing.Size(119, 35);
            this.efwSimpleButton7.TabIndex = 10;
            this.efwSimpleButton7.Text = "frmTM08";
            this.efwSimpleButton7.Click += new System.EventHandler(this.efwSimpleButton7_Click);
            // 
            // efwSimpleButton6
            // 
            this.efwSimpleButton6.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwSimpleButton6.IsMultiLang = false;
            this.efwSimpleButton6.Location = new System.Drawing.Point(2, 212);
            this.efwSimpleButton6.Name = "efwSimpleButton6";
            this.efwSimpleButton6.Size = new System.Drawing.Size(119, 35);
            this.efwSimpleButton6.TabIndex = 9;
            this.efwSimpleButton6.Text = "frmTM07";
            this.efwSimpleButton6.Click += new System.EventHandler(this.efwSimpleButton6_Click);
            // 
            // efwSimpleButton5
            // 
            this.efwSimpleButton5.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwSimpleButton5.IsMultiLang = false;
            this.efwSimpleButton5.Location = new System.Drawing.Point(2, 177);
            this.efwSimpleButton5.Name = "efwSimpleButton5";
            this.efwSimpleButton5.Size = new System.Drawing.Size(119, 35);
            this.efwSimpleButton5.TabIndex = 8;
            this.efwSimpleButton5.Text = "frmTM06";
            this.efwSimpleButton5.Click += new System.EventHandler(this.efwSimpleButton5_Click);
            // 
            // efwSimpleButton4
            // 
            this.efwSimpleButton4.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwSimpleButton4.IsMultiLang = false;
            this.efwSimpleButton4.Location = new System.Drawing.Point(2, 142);
            this.efwSimpleButton4.Name = "efwSimpleButton4";
            this.efwSimpleButton4.Size = new System.Drawing.Size(119, 35);
            this.efwSimpleButton4.TabIndex = 7;
            this.efwSimpleButton4.Text = "frmTM05";
            this.efwSimpleButton4.Click += new System.EventHandler(this.efwSimpleButton4_Click);
            // 
            // efwSimpleButton3
            // 
            this.efwSimpleButton3.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwSimpleButton3.IsMultiLang = false;
            this.efwSimpleButton3.Location = new System.Drawing.Point(2, 107);
            this.efwSimpleButton3.Name = "efwSimpleButton3";
            this.efwSimpleButton3.Size = new System.Drawing.Size(119, 35);
            this.efwSimpleButton3.TabIndex = 6;
            this.efwSimpleButton3.Text = "frmTM04";
            this.efwSimpleButton3.Click += new System.EventHandler(this.efwSimpleButton3_Click);
            // 
            // efwSimpleButton1
            // 
            this.efwSimpleButton1.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwSimpleButton1.IsMultiLang = false;
            this.efwSimpleButton1.Location = new System.Drawing.Point(2, 72);
            this.efwSimpleButton1.Name = "efwSimpleButton1";
            this.efwSimpleButton1.Size = new System.Drawing.Size(119, 35);
            this.efwSimpleButton1.TabIndex = 5;
            this.efwSimpleButton1.Text = "frmTM03";
            this.efwSimpleButton1.Click += new System.EventHandler(this.efwSimpleButton1_Click);
            // 
            // btnTM02
            // 
            this.btnTM02.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTM02.IsMultiLang = false;
            this.btnTM02.Location = new System.Drawing.Point(2, 37);
            this.btnTM02.Name = "btnTM02";
            this.btnTM02.Size = new System.Drawing.Size(119, 35);
            this.btnTM02.TabIndex = 4;
            this.btnTM02.Text = "frmTM02";
            this.btnTM02.Click += new System.EventHandler(this.BtnTM02_Click);
            // 
            // efwSimpleButton2
            // 
            this.efwSimpleButton2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.efwSimpleButton2.IsMultiLang = false;
            this.efwSimpleButton2.Location = new System.Drawing.Point(2, 775);
            this.efwSimpleButton2.Name = "efwSimpleButton2";
            this.efwSimpleButton2.Size = new System.Drawing.Size(119, 31);
            this.efwSimpleButton2.TabIndex = 3;
            this.efwSimpleButton2.Text = "frmTest";
            // 
            // efwSimpleButton8
            // 
            this.efwSimpleButton8.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwSimpleButton8.IsMultiLang = false;
            this.efwSimpleButton8.Location = new System.Drawing.Point(2, 282);
            this.efwSimpleButton8.Name = "efwSimpleButton8";
            this.efwSimpleButton8.Size = new System.Drawing.Size(119, 35);
            this.efwSimpleButton8.TabIndex = 11;
            this.efwSimpleButton8.Text = "frmTM09";
            // 
            // efwSimpleButton9
            // 
            this.efwSimpleButton9.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwSimpleButton9.IsMultiLang = false;
            this.efwSimpleButton9.Location = new System.Drawing.Point(2, 317);
            this.efwSimpleButton9.Name = "efwSimpleButton9";
            this.efwSimpleButton9.Size = new System.Drawing.Size(119, 35);
            this.efwSimpleButton9.TabIndex = 12;
            this.efwSimpleButton9.Text = "frmTM10";
            this.efwSimpleButton9.Click += new System.EventHandler(this.efwSimpleButton9_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1398, 808);
            this.Controls.Add(this.efwPnlBody);
            this.Controls.Add(this.efwPanelControl1);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMain";
            ((System.ComponentModel.ISupportInitialize)(this.efwPnlBody)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwPanelControl1)).EndInit();
            this.efwPanelControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Easy.Framework.WinForm.Control.efwPanelControl efwPnlBody;
        private Easy.Framework.WinForm.Control.efwSimpleButton btnTM01;
        private Easy.Framework.WinForm.Control.efwPanelControl efwPanelControl1;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton2;
        private Easy.Framework.WinForm.Control.efwSimpleButton btnTM02;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton1;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton3;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton4;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton5;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton6;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton7;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton9;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton8;
    }
}