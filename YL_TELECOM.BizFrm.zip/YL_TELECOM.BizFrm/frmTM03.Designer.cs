﻿namespace YL_TELECOM.BizFrm
{
    partial class frmTM03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo1 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo2 = new Easy.Framework.WinForm.Control.ServiceInfo();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTM03));
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo3 = new Easy.Framework.WinForm.Control.ServiceInfo();
            this.efwPanelControl1 = new Easy.Framework.WinForm.Control.efwPanelControl();
            this.txtPay_NameQ = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel1 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtPay_CodeQ = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel9 = new Easy.Framework.WinForm.Control.efwLabel();
            this.efwGridControl1 = new Easy.Framework.WinForm.Control.efwGridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemMemoExEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.splitterControl1 = new DevExpress.XtraEditors.SplitterControl();
            this.efwGroupControl1 = new Easy.Framework.WinForm.Control.efwGroupControl();
            this.efwSimpleButton2 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwSimpleButton1 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.txtidx = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.cbis_use = new Easy.Framework.WinForm.Control.efwCheckEdit();
            this.txtal_open_donut_count = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel11 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtrecommend_donut_count = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel10 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtperiod_vip_donut_count = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel8 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtperiod_donut_count = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel6 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtvip_donut_count = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel5 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtdonut_count = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel4 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtpay_name = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel3 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtpay_code = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel2 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtBasic_Price = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel7 = new Easy.Framework.WinForm.Control.efwLabel();
            this.rbIs_Prepaid = new Easy.Framework.WinForm.Control.efwRadioGroup();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            ((System.ComponentModel.ISupportInitialize)(this.efwPanelControl1)).BeginInit();
            this.efwPanelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPay_NameQ.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPay_CodeQ.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl1)).BeginInit();
            this.efwGroupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtidx.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbis_use.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtal_open_donut_count.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtrecommend_donut_count.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtperiod_vip_donut_count.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtperiod_donut_count.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtvip_donut_count.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdonut_count.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpay_name.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpay_code.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBasic_Price.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rbIs_Prepaid.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            this.SuspendLayout();
            // 
            // efwPanelControl1
            // 
            this.efwPanelControl1.Controls.Add(this.txtPay_NameQ);
            this.efwPanelControl1.Controls.Add(this.efwLabel1);
            this.efwPanelControl1.Controls.Add(this.txtPay_CodeQ);
            this.efwPanelControl1.Controls.Add(this.efwLabel9);
            this.efwPanelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwPanelControl1.Location = new System.Drawing.Point(3, 35);
            this.efwPanelControl1.Name = "efwPanelControl1";
            this.efwPanelControl1.Size = new System.Drawing.Size(1151, 49);
            this.efwPanelControl1.TabIndex = 41;
            this.efwPanelControl1.Paint += new System.Windows.Forms.PaintEventHandler(this.efwPanelControl1_Paint);
            // 
            // txtPay_NameQ
            // 
            this.txtPay_NameQ.EditValue2 = null;
            this.txtPay_NameQ.EraserGroup = "CLR1";
            this.txtPay_NameQ.Location = new System.Drawing.Point(339, 15);
            this.txtPay_NameQ.Name = "txtPay_NameQ";
            this.txtPay_NameQ.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtPay_NameQ.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPay_NameQ.RequireMessage = null;
            this.txtPay_NameQ.Size = new System.Drawing.Size(148, 20);
            this.txtPay_NameQ.TabIndex = 47;
            this.txtPay_NameQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPay_NameQ_KeyDown);
            // 
            // efwLabel1
            // 
            this.efwLabel1.EraserGroup = null;
            this.efwLabel1.IsMultiLang = false;
            this.efwLabel1.Location = new System.Drawing.Point(275, 17);
            this.efwLabel1.Name = "efwLabel1";
            this.efwLabel1.Size = new System.Drawing.Size(40, 14);
            this.efwLabel1.TabIndex = 46;
            this.efwLabel1.Text = "요금제명";
            // 
            // txtPay_CodeQ
            // 
            this.txtPay_CodeQ.EditValue2 = null;
            this.txtPay_CodeQ.EraserGroup = "CLR1";
            this.txtPay_CodeQ.Location = new System.Drawing.Point(102, 15);
            this.txtPay_CodeQ.Name = "txtPay_CodeQ";
            this.txtPay_CodeQ.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtPay_CodeQ.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPay_CodeQ.RequireMessage = null;
            this.txtPay_CodeQ.Size = new System.Drawing.Size(136, 20);
            this.txtPay_CodeQ.TabIndex = 45;
            this.txtPay_CodeQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPay_CodeQ_KeyDown);
            // 
            // efwLabel9
            // 
            this.efwLabel9.EraserGroup = null;
            this.efwLabel9.IsMultiLang = false;
            this.efwLabel9.Location = new System.Drawing.Point(26, 17);
            this.efwLabel9.Name = "efwLabel9";
            this.efwLabel9.Size = new System.Drawing.Size(54, 14);
            this.efwLabel9.TabIndex = 44;
            this.efwLabel9.Text = "요금제 코드";
            // 
            // efwGridControl1
            // 
            this.efwGridControl1.BindSet = null;
            this.efwGridControl1.DBName = "";
            serviceInfo1.InstanceName = "";
            serviceInfo1.IsUserIDAdd = true;
            serviceInfo1.ParamsInfo = null;
            serviceInfo1.ProcName = "";
            serviceInfo1.UserParams = null;
            this.efwGridControl1.DeleteServiceInfo = serviceInfo1;
            this.efwGridControl1.Dock = System.Windows.Forms.DockStyle.Top;
            serviceInfo2.InstanceName = "";
            serviceInfo2.IsUserIDAdd = true;
            serviceInfo2.ParamsInfo = null;
            serviceInfo2.ProcName = "";
            serviceInfo2.UserParams = null;
            this.efwGridControl1.InsertServiceInfo = serviceInfo2;
            this.efwGridControl1.IsAddExcelBtn = true;
            this.efwGridControl1.isAddPrintBtn = true;
            this.efwGridControl1.IsMultiLang = false;
            this.efwGridControl1.Location = new System.Drawing.Point(3, 84);
            this.efwGridControl1.MainView = this.gridView1;
            this.efwGridControl1.Name = "efwGridControl1";
            this.efwGridControl1.NowRowHandle = 0;
            this.efwGridControl1.PKColumns = ((System.Collections.ArrayList)(resources.GetObject("efwGridControl1.PKColumns")));
            this.efwGridControl1.PrevRowHandle = -2147483648;
            this.efwGridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEdit1,
            this.repositoryItemMemoExEdit1,
            this.repositoryItemMemoEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryItemCheckEdit2,
            this.repositoryItemCheckEdit3,
            this.repositoryItemCheckEdit4});
            this.efwGridControl1.Size = new System.Drawing.Size(1151, 405);
            this.efwGridControl1.TabIndex = 43;
            this.efwGridControl1.TableName = "";
            serviceInfo3.InstanceName = "";
            serviceInfo3.IsUserIDAdd = true;
            serviceInfo3.ParamsInfo = null;
            serviceInfo3.ProcName = "";
            serviceInfo3.UserParams = null;
            this.efwGridControl1.UpdateServiceInfo = serviceInfo3;
            this.efwGridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Red;
            this.gridView1.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn12,
            this.gridColumn11,
            this.gridColumn22,
            this.gridColumn2,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn10});
            this.gridView1.GridControl = this.efwGridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "idx";
            this.gridColumn1.FieldName = "idx";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "코드";
            this.gridColumn3.FieldName = "pay_code";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 1;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "요금제명";
            this.gridColumn4.FieldName = "pay_name";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 2;
            // 
            // gridColumn22
            // 
            this.gridColumn22.Caption = "도넛(알뜰할인 일반)";
            this.gridColumn22.DisplayFormat.FormatString = "###,###,###";
            this.gridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn22.FieldName = "donut_count";
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.OptionsColumn.AllowEdit = false;
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 5;
            this.gridColumn22.Width = 81;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "VIP도넛 (알뜰할인 VIP이상)";
            this.gridColumn2.DisplayFormat.FormatString = "###,###,###";
            this.gridColumn2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn2.FieldName = "vip_donut_count";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 6;
            this.gridColumn2.Width = 83;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "일반+약정 유저(알뜰할인)";
            this.gridColumn5.DisplayFormat.FormatString = "###,###,###";
            this.gridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn5.FieldName = "period_donut_count";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 7;
            this.gridColumn5.Width = 86;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "VIP+약정 유저(알뜰할인)";
            this.gridColumn6.DisplayFormat.FormatString = "###,###,###";
            this.gridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn6.FieldName = "period_vip_donut_count";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 8;
            this.gridColumn6.Width = 147;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "VIP+약정(알뜰할인)";
            this.gridColumn7.DisplayFormat.FormatString = "###,###,###";
            this.gridColumn7.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn7.FieldName = "period_vip_donut_count";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.Width = 136;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "추천인 도넛(알뜰추천)";
            this.gridColumn8.DisplayFormat.FormatString = "###,###,###";
            this.gridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn8.FieldName = "recommend_donut_count";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 9;
            this.gridColumn8.Width = 112;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "알뜰개통금액";
            this.gridColumn9.DisplayFormat.FormatString = "###,###,###";
            this.gridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn9.FieldName = "al_open_donut_count";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 10;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "사용유무";
            this.gridColumn10.ColumnEdit = this.repositoryItemCheckEdit3;
            this.gridColumn10.DisplayFormat.FormatString = "###,###,###";
            this.gridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn10.FieldName = "is_use";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 11;
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            this.repositoryItemCheckEdit3.ValueChecked = "Y";
            this.repositoryItemCheckEdit3.ValueUnchecked = "N";
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            // 
            // repositoryItemMemoExEdit1
            // 
            this.repositoryItemMemoExEdit1.AutoHeight = false;
            this.repositoryItemMemoExEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit1.Name = "repositoryItemMemoExEdit1";
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            this.repositoryItemCheckEdit2.ValueChecked = "Y";
            this.repositoryItemCheckEdit2.ValueUnchecked = "N";
            // 
            // splitterControl1
            // 
            this.splitterControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitterControl1.Location = new System.Drawing.Point(3, 489);
            this.splitterControl1.Name = "splitterControl1";
            this.splitterControl1.Size = new System.Drawing.Size(1151, 5);
            this.splitterControl1.TabIndex = 44;
            this.splitterControl1.TabStop = false;
            // 
            // efwGroupControl1
            // 
            this.efwGroupControl1.CaptionImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwGroupControl1.CaptionImageOptions.Image")));
            this.efwGroupControl1.Controls.Add(this.rbIs_Prepaid);
            this.efwGroupControl1.Controls.Add(this.efwLabel7);
            this.efwGroupControl1.Controls.Add(this.txtBasic_Price);
            this.efwGroupControl1.Controls.Add(this.efwSimpleButton2);
            this.efwGroupControl1.Controls.Add(this.efwSimpleButton1);
            this.efwGroupControl1.Controls.Add(this.txtidx);
            this.efwGroupControl1.Controls.Add(this.cbis_use);
            this.efwGroupControl1.Controls.Add(this.txtal_open_donut_count);
            this.efwGroupControl1.Controls.Add(this.efwLabel11);
            this.efwGroupControl1.Controls.Add(this.txtrecommend_donut_count);
            this.efwGroupControl1.Controls.Add(this.efwLabel10);
            this.efwGroupControl1.Controls.Add(this.txtperiod_vip_donut_count);
            this.efwGroupControl1.Controls.Add(this.efwLabel8);
            this.efwGroupControl1.Controls.Add(this.txtperiod_donut_count);
            this.efwGroupControl1.Controls.Add(this.efwLabel6);
            this.efwGroupControl1.Controls.Add(this.txtvip_donut_count);
            this.efwGroupControl1.Controls.Add(this.efwLabel5);
            this.efwGroupControl1.Controls.Add(this.txtdonut_count);
            this.efwGroupControl1.Controls.Add(this.efwLabel4);
            this.efwGroupControl1.Controls.Add(this.txtpay_name);
            this.efwGroupControl1.Controls.Add(this.efwLabel3);
            this.efwGroupControl1.Controls.Add(this.txtpay_code);
            this.efwGroupControl1.Controls.Add(this.efwLabel2);
            this.efwGroupControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.efwGroupControl1.IsMultiLang = false;
            this.efwGroupControl1.Location = new System.Drawing.Point(3, 494);
            this.efwGroupControl1.Name = "efwGroupControl1";
            this.efwGroupControl1.Size = new System.Drawing.Size(1151, 154);
            this.efwGroupControl1.TabIndex = 45;
            this.efwGroupControl1.Text = "요금제별 적립금액 저장";
            // 
            // efwSimpleButton2
            // 
            this.efwSimpleButton2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwSimpleButton2.ImageOptions.Image")));
            this.efwSimpleButton2.IsMultiLang = false;
            this.efwSimpleButton2.Location = new System.Drawing.Point(836, 30);
            this.efwSimpleButton2.Name = "efwSimpleButton2";
            this.efwSimpleButton2.Size = new System.Drawing.Size(100, 23);
            this.efwSimpleButton2.TabIndex = 21;
            this.efwSimpleButton2.Text = "삭제";
            this.efwSimpleButton2.Click += new System.EventHandler(this.efwSimpleButton2_Click);
            // 
            // efwSimpleButton1
            // 
            this.efwSimpleButton1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwSimpleButton1.ImageOptions.Image")));
            this.efwSimpleButton1.IsMultiLang = false;
            this.efwSimpleButton1.Location = new System.Drawing.Point(730, 30);
            this.efwSimpleButton1.Name = "efwSimpleButton1";
            this.efwSimpleButton1.Size = new System.Drawing.Size(100, 23);
            this.efwSimpleButton1.TabIndex = 20;
            this.efwSimpleButton1.Text = "저장";
            this.efwSimpleButton1.Click += new System.EventHandler(this.efwSimpleButton1_Click);
            // 
            // txtidx
            // 
            this.txtidx.EditValue2 = null;
            this.txtidx.EraserGroup = "CLR1";
            this.txtidx.Location = new System.Drawing.Point(866, 87);
            this.txtidx.Name = "txtidx";
            this.txtidx.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtidx.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtidx.RequireMessage = null;
            this.txtidx.Size = new System.Drawing.Size(64, 20);
            this.txtidx.TabIndex = 19;
            this.txtidx.Visible = false;
            // 
            // cbis_use
            // 
            this.cbis_use.Location = new System.Drawing.Point(585, 32);
            this.cbis_use.Name = "cbis_use";
            this.cbis_use.Properties.Caption = "사용유무";
            this.cbis_use.Properties.ValueChecked = "Y";
            this.cbis_use.Properties.ValueUnchecked = "N";
            this.cbis_use.Size = new System.Drawing.Size(75, 19);
            this.cbis_use.TabIndex = 18;
            // 
            // txtal_open_donut_count
            // 
            this.txtal_open_donut_count.EditValue2 = null;
            this.txtal_open_donut_count.EraserGroup = "CLR1";
            this.txtal_open_donut_count.Location = new System.Drawing.Point(730, 87);
            this.txtal_open_donut_count.Name = "txtal_open_donut_count";
            this.txtal_open_donut_count.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtal_open_donut_count.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtal_open_donut_count.Properties.EditFormat.FormatString = "###,###,##0";
            this.txtal_open_donut_count.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtal_open_donut_count.RequireMessage = null;
            this.txtal_open_donut_count.Size = new System.Drawing.Size(100, 20);
            this.txtal_open_donut_count.TabIndex = 17;
            // 
            // efwLabel11
            // 
            this.efwLabel11.EraserGroup = null;
            this.efwLabel11.IsMultiLang = false;
            this.efwLabel11.Location = new System.Drawing.Point(585, 87);
            this.efwLabel11.Name = "efwLabel11";
            this.efwLabel11.Size = new System.Drawing.Size(60, 14);
            this.efwLabel11.TabIndex = 16;
            this.efwLabel11.Text = "알뜰개통금액";
            // 
            // txtrecommend_donut_count
            // 
            this.txtrecommend_donut_count.EditValue2 = null;
            this.txtrecommend_donut_count.EraserGroup = "CLR1";
            this.txtrecommend_donut_count.Location = new System.Drawing.Point(463, 87);
            this.txtrecommend_donut_count.Name = "txtrecommend_donut_count";
            this.txtrecommend_donut_count.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtrecommend_donut_count.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtrecommend_donut_count.Properties.EditFormat.FormatString = "###,###,##0";
            this.txtrecommend_donut_count.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtrecommend_donut_count.RequireMessage = null;
            this.txtrecommend_donut_count.Size = new System.Drawing.Size(100, 20);
            this.txtrecommend_donut_count.TabIndex = 15;
            // 
            // efwLabel10
            // 
            this.efwLabel10.EraserGroup = null;
            this.efwLabel10.IsMultiLang = false;
            this.efwLabel10.Location = new System.Drawing.Point(305, 87);
            this.efwLabel10.Name = "efwLabel10";
            this.efwLabel10.Size = new System.Drawing.Size(104, 14);
            this.efwLabel10.TabIndex = 14;
            this.efwLabel10.Text = "추천인 도넛(알뜰추천)";
            // 
            // txtperiod_vip_donut_count
            // 
            this.txtperiod_vip_donut_count.EditValue2 = null;
            this.txtperiod_vip_donut_count.EraserGroup = "CLR1";
            this.txtperiod_vip_donut_count.Location = new System.Drawing.Point(158, 87);
            this.txtperiod_vip_donut_count.Name = "txtperiod_vip_donut_count";
            this.txtperiod_vip_donut_count.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtperiod_vip_donut_count.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtperiod_vip_donut_count.Properties.EditFormat.FormatString = "###,###,##0";
            this.txtperiod_vip_donut_count.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtperiod_vip_donut_count.RequireMessage = null;
            this.txtperiod_vip_donut_count.Size = new System.Drawing.Size(125, 20);
            this.txtperiod_vip_donut_count.TabIndex = 13;
            // 
            // efwLabel8
            // 
            this.efwLabel8.EraserGroup = null;
            this.efwLabel8.IsMultiLang = false;
            this.efwLabel8.Location = new System.Drawing.Point(15, 87);
            this.efwLabel8.Name = "efwLabel8";
            this.efwLabel8.Size = new System.Drawing.Size(97, 14);
            this.efwLabel8.TabIndex = 12;
            this.efwLabel8.Text = "VIP+약정(알뜰할인)";
            // 
            // txtperiod_donut_count
            // 
            this.txtperiod_donut_count.EditValue2 = null;
            this.txtperiod_donut_count.EraserGroup = "CLR1";
            this.txtperiod_donut_count.Location = new System.Drawing.Point(730, 60);
            this.txtperiod_donut_count.Name = "txtperiod_donut_count";
            this.txtperiod_donut_count.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtperiod_donut_count.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtperiod_donut_count.Properties.EditFormat.FormatString = "###,###,##0";
            this.txtperiod_donut_count.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtperiod_donut_count.RequireMessage = null;
            this.txtperiod_donut_count.Size = new System.Drawing.Size(100, 20);
            this.txtperiod_donut_count.TabIndex = 9;
            // 
            // efwLabel6
            // 
            this.efwLabel6.EraserGroup = null;
            this.efwLabel6.IsMultiLang = false;
            this.efwLabel6.Location = new System.Drawing.Point(585, 63);
            this.efwLabel6.Name = "efwLabel6";
            this.efwLabel6.Size = new System.Drawing.Size(122, 14);
            this.efwLabel6.TabIndex = 8;
            this.efwLabel6.Text = "일반+약정 유저(알뜰할인)";
            // 
            // txtvip_donut_count
            // 
            this.txtvip_donut_count.EditValue2 = null;
            this.txtvip_donut_count.EraserGroup = "CLR1";
            this.txtvip_donut_count.Location = new System.Drawing.Point(463, 60);
            this.txtvip_donut_count.Name = "txtvip_donut_count";
            this.txtvip_donut_count.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtvip_donut_count.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtvip_donut_count.Properties.EditFormat.FormatString = "###,###,##0";
            this.txtvip_donut_count.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtvip_donut_count.RequireMessage = null;
            this.txtvip_donut_count.Size = new System.Drawing.Size(100, 20);
            this.txtvip_donut_count.TabIndex = 7;
            // 
            // efwLabel5
            // 
            this.efwLabel5.EraserGroup = null;
            this.efwLabel5.IsMultiLang = false;
            this.efwLabel5.Location = new System.Drawing.Point(305, 63);
            this.efwLabel5.Name = "efwLabel5";
            this.efwLabel5.Size = new System.Drawing.Size(136, 14);
            this.efwLabel5.TabIndex = 6;
            this.efwLabel5.Text = "VIP도넛 (알뜰할인 VIP이상)";
            // 
            // txtdonut_count
            // 
            this.txtdonut_count.EditValue2 = null;
            this.txtdonut_count.EraserGroup = "CLR1";
            this.txtdonut_count.Location = new System.Drawing.Point(158, 60);
            this.txtdonut_count.Name = "txtdonut_count";
            this.txtdonut_count.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtdonut_count.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtdonut_count.Properties.EditFormat.FormatString = "###,###,##0";
            this.txtdonut_count.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtdonut_count.RequireMessage = null;
            this.txtdonut_count.Size = new System.Drawing.Size(125, 20);
            this.txtdonut_count.TabIndex = 5;
            // 
            // efwLabel4
            // 
            this.efwLabel4.EraserGroup = null;
            this.efwLabel4.IsMultiLang = false;
            this.efwLabel4.Location = new System.Drawing.Point(15, 63);
            this.efwLabel4.Name = "efwLabel4";
            this.efwLabel4.Size = new System.Drawing.Size(94, 14);
            this.efwLabel4.TabIndex = 4;
            this.efwLabel4.Text = "도넛(알뜰할인 일반)";
            // 
            // txtpay_name
            // 
            this.txtpay_name.EditValue2 = null;
            this.txtpay_name.EraserGroup = "CLR1";
            this.txtpay_name.Location = new System.Drawing.Point(382, 31);
            this.txtpay_name.Name = "txtpay_name";
            this.txtpay_name.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtpay_name.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtpay_name.RequireMessage = null;
            this.txtpay_name.Size = new System.Drawing.Size(181, 20);
            this.txtpay_name.TabIndex = 3;
            // 
            // efwLabel3
            // 
            this.efwLabel3.EraserGroup = null;
            this.efwLabel3.IsMultiLang = false;
            this.efwLabel3.Location = new System.Drawing.Point(305, 34);
            this.efwLabel3.Name = "efwLabel3";
            this.efwLabel3.Size = new System.Drawing.Size(40, 14);
            this.efwLabel3.TabIndex = 2;
            this.efwLabel3.Text = "요금제명";
            // 
            // txtpay_code
            // 
            this.txtpay_code.EditValue2 = null;
            this.txtpay_code.EraserGroup = "CLR1";
            this.txtpay_code.Location = new System.Drawing.Point(158, 31);
            this.txtpay_code.Name = "txtpay_code";
            this.txtpay_code.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtpay_code.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtpay_code.RequireMessage = null;
            this.txtpay_code.Size = new System.Drawing.Size(125, 20);
            this.txtpay_code.TabIndex = 1;
            // 
            // efwLabel2
            // 
            this.efwLabel2.EraserGroup = null;
            this.efwLabel2.IsMultiLang = false;
            this.efwLabel2.Location = new System.Drawing.Point(15, 34);
            this.efwLabel2.Name = "efwLabel2";
            this.efwLabel2.Size = new System.Drawing.Size(20, 14);
            this.efwLabel2.TabIndex = 0;
            this.efwLabel2.Text = "코드";
            // 
            // txtBasic_Price
            // 
            this.txtBasic_Price.EditValue2 = null;
            this.txtBasic_Price.EraserGroup = "CLR1";
            this.txtBasic_Price.Location = new System.Drawing.Point(158, 113);
            this.txtBasic_Price.Name = "txtBasic_Price";
            this.txtBasic_Price.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtBasic_Price.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtBasic_Price.Properties.EditFormat.FormatString = "###,###,##0";
            this.txtBasic_Price.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBasic_Price.RequireMessage = null;
            this.txtBasic_Price.Size = new System.Drawing.Size(125, 20);
            this.txtBasic_Price.TabIndex = 23;
            // 
            // efwLabel7
            // 
            this.efwLabel7.EraserGroup = null;
            this.efwLabel7.IsMultiLang = false;
            this.efwLabel7.Location = new System.Drawing.Point(12, 116);
            this.efwLabel7.Name = "efwLabel7";
            this.efwLabel7.Size = new System.Drawing.Size(40, 14);
            this.efwLabel7.TabIndex = 24;
            this.efwLabel7.Text = "기본요금";
            // 
            // rbIs_Prepaid
            // 
            this.rbIs_Prepaid.IsMultiLang = false;
            this.rbIs_Prepaid.Location = new System.Drawing.Point(305, 112);
            this.rbIs_Prepaid.Name = "rbIs_Prepaid";
            this.rbIs_Prepaid.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.rbIs_Prepaid.Properties.Appearance.Options.UseBackColor = true;
            this.rbIs_Prepaid.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.rbIs_Prepaid.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.rbIs_Prepaid.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rbIs_Prepaid.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("N", "후불      "),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Y", "선불     ")});
            this.rbIs_Prepaid.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rbIs_Prepaid.RequireMessage = null;
            this.rbIs_Prepaid.Size = new System.Drawing.Size(217, 23);
            this.rbIs_Prepaid.TabIndex = 74;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "선불유무";
            this.gridColumn11.ColumnEdit = this.repositoryItemCheckEdit4;
            this.gridColumn11.FieldName = "is_prepaid";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.AllowEdit = false;
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 4;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "기본요금";
            this.gridColumn12.DisplayFormat.FormatString = "###,###,###";
            this.gridColumn12.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn12.FieldName = "basic_price";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 3;
            // 
            // repositoryItemCheckEdit4
            // 
            this.repositoryItemCheckEdit4.AutoHeight = false;
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            this.repositoryItemCheckEdit4.ValueChecked = "Y";
            this.repositoryItemCheckEdit4.ValueUnchecked = "N";
            // 
            // frmTM03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.efwGroupControl1);
            this.Controls.Add(this.splitterControl1);
            this.Controls.Add(this.efwGridControl1);
            this.Controls.Add(this.efwPanelControl1);
            this.Name = "frmTM03";
            this.Size = new System.Drawing.Size(1157, 648);
            this.Controls.SetChildIndex(this.efwPanelControl1, 0);
            this.Controls.SetChildIndex(this.efwGridControl1, 0);
            this.Controls.SetChildIndex(this.splitterControl1, 0);
            this.Controls.SetChildIndex(this.efwGroupControl1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.efwPanelControl1)).EndInit();
            this.efwPanelControl1.ResumeLayout(false);
            this.efwPanelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPay_NameQ.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPay_CodeQ.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl1)).EndInit();
            this.efwGroupControl1.ResumeLayout(false);
            this.efwGroupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtidx.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbis_use.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtal_open_donut_count.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtrecommend_donut_count.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtperiod_vip_donut_count.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtperiod_donut_count.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtvip_donut_count.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdonut_count.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpay_name.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpay_code.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBasic_Price.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rbIs_Prepaid.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Easy.Framework.WinForm.Control.efwPanelControl efwPanelControl1;
        private Easy.Framework.WinForm.Control.efwTextEdit txtPay_CodeQ;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel9;
        private Easy.Framework.WinForm.Control.efwGridControl efwGridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private Easy.Framework.WinForm.Control.efwTextEdit txtPay_NameQ;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel1;
        private DevExpress.XtraEditors.SplitterControl splitterControl1;
        private Easy.Framework.WinForm.Control.efwGroupControl efwGroupControl1;
        private Easy.Framework.WinForm.Control.efwCheckEdit cbis_use;
        private Easy.Framework.WinForm.Control.efwTextEdit txtal_open_donut_count;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel11;
        private Easy.Framework.WinForm.Control.efwTextEdit txtrecommend_donut_count;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel10;
        private Easy.Framework.WinForm.Control.efwTextEdit txtperiod_vip_donut_count;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel8;
        private Easy.Framework.WinForm.Control.efwTextEdit txtperiod_donut_count;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel6;
        private Easy.Framework.WinForm.Control.efwTextEdit txtvip_donut_count;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel5;
        private Easy.Framework.WinForm.Control.efwTextEdit txtdonut_count;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel4;
        private Easy.Framework.WinForm.Control.efwTextEdit txtpay_name;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel3;
        private Easy.Framework.WinForm.Control.efwTextEdit txtpay_code;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel2;
        private Easy.Framework.WinForm.Control.efwTextEdit txtidx;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton1;
        private Easy.Framework.WinForm.Control.efwSimpleButton efwSimpleButton2;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel7;
        private Easy.Framework.WinForm.Control.efwTextEdit txtBasic_Price;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private Easy.Framework.WinForm.Control.efwRadioGroup rbIs_Prepaid;
    }
}