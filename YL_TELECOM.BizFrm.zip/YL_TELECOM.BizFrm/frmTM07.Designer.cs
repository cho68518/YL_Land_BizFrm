﻿namespace YL_TELECOM.BizFrm
{
    partial class frmTM07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTM07));
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo1 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo2 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo3 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ChildHierarchy childHierarchy1 = new Easy.Framework.WinForm.Control.ChildHierarchy();
            Easy.Framework.WinForm.Control.Hierarchy hierarchy1 = new Easy.Framework.WinForm.Control.Hierarchy();
            Easy.Framework.WinForm.Control.ChildHierarchy childHierarchy2 = new Easy.Framework.WinForm.Control.ChildHierarchy();
            Easy.Framework.WinForm.Control.Hierarchy hierarchy2 = new Easy.Framework.WinForm.Control.Hierarchy();
            Easy.Framework.WinForm.Control.ChildHierarchy childHierarchy3 = new Easy.Framework.WinForm.Control.ChildHierarchy();
            Easy.Framework.WinForm.Control.Hierarchy hierarchy3 = new Easy.Framework.WinForm.Control.Hierarchy();
            Easy.Framework.WinForm.Control.ChildHierarchy childHierarchy4 = new Easy.Framework.WinForm.Control.ChildHierarchy();
            Easy.Framework.WinForm.Control.Hierarchy hierarchy4 = new Easy.Framework.WinForm.Control.Hierarchy();
            this.efwGroupControl1 = new Easy.Framework.WinForm.Control.efwGroupControl();
            this.layoutControl2 = new DevExpress.XtraLayout.LayoutControl();
            this.efwGridControl1 = new Easy.Framework.WinForm.Control.efwGridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn27 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn28 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.efwPanelControl2 = new Easy.Framework.WinForm.Control.efwPanelControl();
            this.efwLabel7 = new Easy.Framework.WinForm.Control.efwLabel();
            this.efwLabel23 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtS_ADDRESS1 = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_IDX = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_U_ID = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.efwLabel2 = new Easy.Framework.WinForm.Control.efwLabel();
            this.txtQ_AGENCY_NAME = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterControl1 = new DevExpress.XtraEditors.SplitterControl();
            this.efwGroupControl2 = new Easy.Framework.WinForm.Control.efwGroupControl();
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.btnSAVE = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.BtnNEW = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.txtS_PASSWORD = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.cmbS_STATUS = new Easy.Framework.WinForm.Control.efwLookUpEdit();
            this.txtS_ADDRESS = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.btnS_ZIPCODE = new Easy.Framework.WinForm.Control.efwButtonEdit();
            this.txtS_FAX = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_PHONE = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_TEL = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_RESPON_NAME = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_ACCOUNT = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.cmbS_BANK = new Easy.Framework.WinForm.Control.efwLookUpEdit();
            this.txtS_DEPOSITOR = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_BUSINESS_TYPE = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_BUSINESS_CONDITION = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.cmbS_TAX_TYPE = new Easy.Framework.WinForm.Control.efwLookUpEdit();
            this.txtS_SALES_NUM = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_CORPORATE_NUM = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_BUSINESS_NUM = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_NICKNAME = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_ID = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_BOSS_NAME = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txtS_COMPANY_NAME = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.cmbS_DIVISION = new Easy.Framework.WinForm.Control.efwLookUpEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem21 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem22 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem24 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem23 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem25 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem19 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem22 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem21 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem9 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem23 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem18 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem12 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem20 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem6 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem7 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem8 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem25 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem26 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem10 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem11 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem13 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem14 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem16 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem17 = new DevExpress.XtraLayout.EmptySpaceItem();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl1)).BeginInit();
            this.efwGroupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl2)).BeginInit();
            this.layoutControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwPanelControl2)).BeginInit();
            this.efwPanelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_ADDRESS1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_IDX.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_U_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQ_AGENCY_NAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl2)).BeginInit();
            this.efwGroupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_PASSWORD.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbS_STATUS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_ADDRESS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnS_ZIPCODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_FAX.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_PHONE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_TEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_RESPON_NAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_ACCOUNT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbS_BANK.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_DEPOSITOR.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_BUSINESS_TYPE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_BUSINESS_CONDITION.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbS_TAX_TYPE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_SALES_NUM.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_CORPORATE_NUM.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_BUSINESS_NUM.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_NICKNAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_BOSS_NAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_COMPANY_NAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbS_DIVISION.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem17)).BeginInit();
            this.SuspendLayout();
            // 
            // efwGroupControl1
            // 
            this.efwGroupControl1.CaptionImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwGroupControl1.CaptionImageOptions.Image")));
            this.efwGroupControl1.Controls.Add(this.layoutControl2);
            this.efwGroupControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwGroupControl1.IsMultiLang = false;
            this.efwGroupControl1.Location = new System.Drawing.Point(3, 35);
            this.efwGroupControl1.Name = "efwGroupControl1";
            this.efwGroupControl1.Size = new System.Drawing.Size(1184, 456);
            this.efwGroupControl1.TabIndex = 21;
            this.efwGroupControl1.Text = "거래처 목록";
            // 
            // layoutControl2
            // 
            this.layoutControl2.Controls.Add(this.efwGridControl1);
            this.layoutControl2.Controls.Add(this.efwPanelControl2);
            this.layoutControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl2.Location = new System.Drawing.Point(2, 23);
            this.layoutControl2.Name = "layoutControl2";
            this.layoutControl2.Root = this.layoutControlGroup2;
            this.layoutControl2.Size = new System.Drawing.Size(1180, 431);
            this.layoutControl2.TabIndex = 0;
            this.layoutControl2.Text = "layoutControl2";
            // 
            // efwGridControl1
            // 
            this.efwGridControl1.BindSet = null;
            this.efwGridControl1.DBName = "";
            serviceInfo1.InstanceName = "";
            serviceInfo1.IsUserIDAdd = true;
            serviceInfo1.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo1.ParamsInfo")));
            serviceInfo1.ProcName = "";
            serviceInfo1.UserParams = ((System.Collections.Generic.List<object>)(resources.GetObject("serviceInfo1.UserParams")));
            this.efwGridControl1.DeleteServiceInfo = serviceInfo1;
            serviceInfo2.InstanceName = "";
            serviceInfo2.IsUserIDAdd = true;
            serviceInfo2.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo2.ParamsInfo")));
            serviceInfo2.ProcName = "";
            serviceInfo2.UserParams = ((System.Collections.Generic.List<object>)(resources.GetObject("serviceInfo2.UserParams")));
            this.efwGridControl1.InsertServiceInfo = serviceInfo2;
            this.efwGridControl1.IsAddExcelBtn = true;
            this.efwGridControl1.isAddPrintBtn = true;
            this.efwGridControl1.IsEditable = false;
            this.efwGridControl1.IsMultiLang = false;
            this.efwGridControl1.Location = new System.Drawing.Point(7, 55);
            this.efwGridControl1.MainView = this.gridView1;
            this.efwGridControl1.Name = "efwGridControl1";
            this.efwGridControl1.NowRowHandle = 0;
            this.efwGridControl1.PKColumns = ((System.Collections.ArrayList)(resources.GetObject("efwGridControl1.PKColumns")));
            this.efwGridControl1.PrevRowHandle = -2147483648;
            this.efwGridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemGridLookUpEdit1});
            this.efwGridControl1.Size = new System.Drawing.Size(1166, 372);
            this.efwGridControl1.TabIndex = 8;
            this.efwGridControl1.TableName = "";
            serviceInfo3.InstanceName = "";
            serviceInfo3.IsUserIDAdd = true;
            serviceInfo3.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo3.ParamsInfo")));
            serviceInfo3.ProcName = "";
            serviceInfo3.UserParams = ((System.Collections.Generic.List<object>)(resources.GetObject("serviceInfo3.UserParams")));
            this.efwGridControl1.UpdateServiceInfo = serviceInfo3;
            this.efwGridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            this.efwGridControl1.Click += new System.EventHandler(this.efwGridControl1_Click_1);
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn15,
            this.gridColumn14,
            this.gridColumn17,
            this.gridColumn18,
            this.gridColumn19,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23,
            this.gridColumn24,
            this.gridColumn25,
            this.gridColumn16,
            this.gridColumn26,
            this.gridColumn27,
            this.gridColumn28});
            this.gridView1.GridControl = this.efwGridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "s_idx";
            this.gridColumn1.FieldName = "s_idx";
            this.gridColumn1.Name = "gridColumn1";
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "구분";
            this.gridColumn2.FieldName = "s_division_nm";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 0;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "업체명";
            this.gridColumn3.FieldName = "s_company_name";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 1;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "s_u_id";
            this.gridColumn4.FieldName = "s_u_id";
            this.gridColumn4.Name = "gridColumn4";
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "아이디";
            this.gridColumn5.FieldName = "s_id";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 2;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "닉네임";
            this.gridColumn6.FieldName = "s_nickname";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 3;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "비밀번호";
            this.gridColumn7.FieldName = "s_password";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 4;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "대표자명";
            this.gridColumn8.FieldName = "s_boss_name";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 5;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "사업자번호";
            this.gridColumn9.FieldName = "s_business_num";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 6;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "법인번호";
            this.gridColumn10.FieldName = "s_corporate_num";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 7;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "통신판매번호";
            this.gridColumn11.FieldName = "s_sales_num";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 8;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "업태";
            this.gridColumn12.FieldName = "s_business_condition";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 9;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "업종";
            this.gridColumn13.FieldName = "s_business_type";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 10;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "과세유형";
            this.gridColumn15.FieldName = "s_tax_type_nm";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 11;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "상태";
            this.gridColumn14.FieldName = "s_status_nm";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 12;
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "얘금주";
            this.gridColumn17.FieldName = "s_depositor";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 13;
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "은행명";
            this.gridColumn18.FieldName = "s_bank_nm";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 14;
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "계좌번호";
            this.gridColumn19.FieldName = "s_account";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 15;
            // 
            // gridColumn20
            // 
            this.gridColumn20.Caption = "담당자명";
            this.gridColumn20.FieldName = "s_respon_name";
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 16;
            // 
            // gridColumn21
            // 
            this.gridColumn21.Caption = "전화번호";
            this.gridColumn21.FieldName = "s_tel";
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 17;
            // 
            // gridColumn22
            // 
            this.gridColumn22.Caption = "폰번호";
            this.gridColumn22.FieldName = "s_phone";
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 18;
            // 
            // gridColumn23
            // 
            this.gridColumn23.Caption = "팩스번";
            this.gridColumn23.FieldName = "s_fax";
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 19;
            // 
            // gridColumn24
            // 
            this.gridColumn24.Caption = "우편번호";
            this.gridColumn24.FieldName = "s_zipcode";
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 20;
            // 
            // gridColumn25
            // 
            this.gridColumn25.Caption = "주소";
            this.gridColumn25.FieldName = "s_address";
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 21;
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "s_division";
            this.gridColumn16.FieldName = "s_division";
            this.gridColumn16.Name = "gridColumn16";
            // 
            // gridColumn26
            // 
            this.gridColumn26.Caption = "s_status";
            this.gridColumn26.FieldName = "s_status";
            this.gridColumn26.Name = "gridColumn26";
            // 
            // gridColumn27
            // 
            this.gridColumn27.Caption = "s_tax_type";
            this.gridColumn27.FieldName = "s_tax_type";
            this.gridColumn27.Name = "gridColumn27";
            // 
            // gridColumn28
            // 
            this.gridColumn28.Caption = "s_bank";
            this.gridColumn28.FieldName = "s_bank";
            this.gridColumn28.Name = "gridColumn28";
            // 
            // repositoryItemGridLookUpEdit1
            // 
            this.repositoryItemGridLookUpEdit1.AutoHeight = false;
            this.repositoryItemGridLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEdit1.Name = "repositoryItemGridLookUpEdit1";
            this.repositoryItemGridLookUpEdit1.PopupView = this.gridView2;
            // 
            // gridView2
            // 
            this.gridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // efwPanelControl2
            // 
            this.efwPanelControl2.Controls.Add(this.efwLabel7);
            this.efwPanelControl2.Controls.Add(this.efwLabel23);
            this.efwPanelControl2.Controls.Add(this.txtS_ADDRESS1);
            this.efwPanelControl2.Controls.Add(this.txtS_IDX);
            this.efwPanelControl2.Controls.Add(this.txtS_U_ID);
            this.efwPanelControl2.Controls.Add(this.efwLabel2);
            this.efwPanelControl2.Controls.Add(this.txtQ_AGENCY_NAME);
            this.efwPanelControl2.Location = new System.Drawing.Point(7, 7);
            this.efwPanelControl2.Name = "efwPanelControl2";
            this.efwPanelControl2.Size = new System.Drawing.Size(1166, 44);
            this.efwPanelControl2.TabIndex = 7;
            // 
            // efwLabel7
            // 
            this.efwLabel7.EraserGroup = null;
            this.efwLabel7.IsMultiLang = false;
            this.efwLabel7.Location = new System.Drawing.Point(682, 18);
            this.efwLabel7.Name = "efwLabel7";
            this.efwLabel7.Size = new System.Drawing.Size(27, 14);
            this.efwLabel7.TabIndex = 58;
            this.efwLabel7.Text = "s_idx";
            this.efwLabel7.Visible = false;
            // 
            // efwLabel23
            // 
            this.efwLabel23.EraserGroup = null;
            this.efwLabel23.IsMultiLang = false;
            this.efwLabel23.Location = new System.Drawing.Point(478, 15);
            this.efwLabel23.Name = "efwLabel23";
            this.efwLabel23.Size = new System.Drawing.Size(23, 14);
            this.efwLabel23.TabIndex = 57;
            this.efwLabel23.Text = "u_id";
            this.efwLabel23.Visible = false;
            // 
            // txtS_ADDRESS1
            // 
            this.txtS_ADDRESS1.EditValue2 = null;
            this.txtS_ADDRESS1.EraserGroup = "CLR1";
            this.txtS_ADDRESS1.Location = new System.Drawing.Point(901, 12);
            this.txtS_ADDRESS1.Name = "txtS_ADDRESS1";
            this.txtS_ADDRESS1.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_ADDRESS1.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_ADDRESS1.RequireMessage = null;
            this.txtS_ADDRESS1.Size = new System.Drawing.Size(57, 20);
            this.txtS_ADDRESS1.TabIndex = 56;
            this.txtS_ADDRESS1.Visible = false;
            // 
            // txtS_IDX
            // 
            this.txtS_IDX.EditValue = "";
            this.txtS_IDX.EditValue2 = null;
            this.txtS_IDX.EraserGroup = "CLR1";
            this.txtS_IDX.Location = new System.Drawing.Point(733, 12);
            this.txtS_IDX.Name = "txtS_IDX";
            this.txtS_IDX.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_IDX.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_IDX.RequireMessage = null;
            this.txtS_IDX.Size = new System.Drawing.Size(153, 20);
            this.txtS_IDX.TabIndex = 52;
            this.txtS_IDX.Visible = false;
            // 
            // txtS_U_ID
            // 
            this.txtS_U_ID.EditValue2 = null;
            this.txtS_U_ID.EraserGroup = "CLR1";
            this.txtS_U_ID.Location = new System.Drawing.Point(507, 12);
            this.txtS_U_ID.Name = "txtS_U_ID";
            this.txtS_U_ID.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_U_ID.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_U_ID.RequireMessage = null;
            this.txtS_U_ID.Size = new System.Drawing.Size(153, 20);
            this.txtS_U_ID.TabIndex = 50;
            this.txtS_U_ID.Visible = false;
            // 
            // efwLabel2
            // 
            this.efwLabel2.EraserGroup = null;
            this.efwLabel2.IsMultiLang = false;
            this.efwLabel2.Location = new System.Drawing.Point(17, 15);
            this.efwLabel2.Name = "efwLabel2";
            this.efwLabel2.Size = new System.Drawing.Size(40, 14);
            this.efwLabel2.TabIndex = 1;
            this.efwLabel2.Text = "거래처명";
            // 
            // txtQ_AGENCY_NAME
            // 
            this.txtQ_AGENCY_NAME.EditValue2 = null;
            this.txtQ_AGENCY_NAME.Location = new System.Drawing.Point(77, 12);
            this.txtQ_AGENCY_NAME.Name = "txtQ_AGENCY_NAME";
            this.txtQ_AGENCY_NAME.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtQ_AGENCY_NAME.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtQ_AGENCY_NAME.RequireMessage = null;
            this.txtQ_AGENCY_NAME.Size = new System.Drawing.Size(218, 20);
            this.txtQ_AGENCY_NAME.TabIndex = 0;
            this.txtQ_AGENCY_NAME.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQ_AGENCY_NAME_KeyDown);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup2.GroupBordersVisible = false;
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2});
            this.layoutControlGroup2.Name = "Root";
            this.layoutControlGroup2.Padding = new DevExpress.XtraLayout.Utils.Padding(5, 5, 5, 2);
            this.layoutControlGroup2.Size = new System.Drawing.Size(1180, 431);
            this.layoutControlGroup2.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.efwPanelControl2;
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(1170, 48);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.efwGridControl1;
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 48);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(1170, 376);
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // splitterControl1
            // 
            this.splitterControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitterControl1.Location = new System.Drawing.Point(3, 491);
            this.splitterControl1.Name = "splitterControl1";
            this.splitterControl1.Size = new System.Drawing.Size(1184, 5);
            this.splitterControl1.TabIndex = 22;
            this.splitterControl1.TabStop = false;
            // 
            // efwGroupControl2
            // 
            this.efwGroupControl2.CaptionImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwGroupControl2.CaptionImageOptions.Image")));
            this.efwGroupControl2.Controls.Add(this.layoutControl1);
            this.efwGroupControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.efwGroupControl2.IsMultiLang = false;
            this.efwGroupControl2.Location = new System.Drawing.Point(3, 496);
            this.efwGroupControl2.Name = "efwGroupControl2";
            this.efwGroupControl2.Size = new System.Drawing.Size(1184, 261);
            this.efwGroupControl2.TabIndex = 23;
            this.efwGroupControl2.Text = "거래처 등록";
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.btnSAVE);
            this.layoutControl1.Controls.Add(this.BtnNEW);
            this.layoutControl1.Controls.Add(this.txtS_PASSWORD);
            this.layoutControl1.Controls.Add(this.cmbS_STATUS);
            this.layoutControl1.Controls.Add(this.txtS_ADDRESS);
            this.layoutControl1.Controls.Add(this.btnS_ZIPCODE);
            this.layoutControl1.Controls.Add(this.txtS_FAX);
            this.layoutControl1.Controls.Add(this.txtS_PHONE);
            this.layoutControl1.Controls.Add(this.txtS_TEL);
            this.layoutControl1.Controls.Add(this.txtS_RESPON_NAME);
            this.layoutControl1.Controls.Add(this.txtS_ACCOUNT);
            this.layoutControl1.Controls.Add(this.cmbS_BANK);
            this.layoutControl1.Controls.Add(this.txtS_DEPOSITOR);
            this.layoutControl1.Controls.Add(this.txtS_BUSINESS_TYPE);
            this.layoutControl1.Controls.Add(this.txtS_BUSINESS_CONDITION);
            this.layoutControl1.Controls.Add(this.cmbS_TAX_TYPE);
            this.layoutControl1.Controls.Add(this.txtS_SALES_NUM);
            this.layoutControl1.Controls.Add(this.txtS_CORPORATE_NUM);
            this.layoutControl1.Controls.Add(this.txtS_BUSINESS_NUM);
            this.layoutControl1.Controls.Add(this.txtS_NICKNAME);
            this.layoutControl1.Controls.Add(this.txtS_ID);
            this.layoutControl1.Controls.Add(this.txtS_BOSS_NAME);
            this.layoutControl1.Controls.Add(this.txtS_COMPANY_NAME);
            this.layoutControl1.Controls.Add(this.cmbS_DIVISION);
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(2, 23);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.layoutControlGroup1;
            this.layoutControl1.Size = new System.Drawing.Size(1180, 236);
            this.layoutControl1.TabIndex = 0;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // btnSAVE
            // 
            this.btnSAVE.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSAVE.ImageOptions.Image")));
            this.btnSAVE.IsMultiLang = false;
            this.btnSAVE.Location = new System.Drawing.Point(796, 7);
            this.btnSAVE.Name = "btnSAVE";
            this.btnSAVE.Size = new System.Drawing.Size(91, 22);
            this.btnSAVE.StyleController = this.layoutControl1;
            this.btnSAVE.TabIndex = 75;
            this.btnSAVE.Text = "저장";
            this.btnSAVE.Click += new System.EventHandler(this.btnSAVE_Click);
            // 
            // BtnNEW
            // 
            this.BtnNEW.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnNEW.ImageOptions.Image")));
            this.BtnNEW.IsMultiLang = false;
            this.BtnNEW.Location = new System.Drawing.Point(704, 7);
            this.BtnNEW.Name = "BtnNEW";
            this.BtnNEW.Size = new System.Drawing.Size(88, 22);
            this.BtnNEW.StyleController = this.layoutControl1;
            this.BtnNEW.TabIndex = 74;
            this.BtnNEW.Text = "신규";
            this.BtnNEW.Click += new System.EventHandler(this.BtnNEW_Click);
            // 
            // txtS_PASSWORD
            // 
            this.txtS_PASSWORD.EditValue2 = null;
            this.txtS_PASSWORD.EraserGroup = "CLR1";
            this.txtS_PASSWORD.Location = new System.Drawing.Point(550, 57);
            this.txtS_PASSWORD.Name = "txtS_PASSWORD";
            this.txtS_PASSWORD.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_PASSWORD.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_PASSWORD.RequireMessage = null;
            this.txtS_PASSWORD.Size = new System.Drawing.Size(140, 20);
            this.txtS_PASSWORD.StyleController = this.layoutControl1;
            this.txtS_PASSWORD.TabIndex = 73;
            // 
            // cmbS_STATUS
            // 
            childHierarchy1.CodeCtrl = null;
            childHierarchy1.DbName = null;
            childHierarchy1.SpName = null;
            this.cmbS_STATUS.ChildHierarchyInfo = childHierarchy1;
            this.cmbS_STATUS.EraserGroup = "CLR1";
            hierarchy1.DbName = null;
            hierarchy1.SpName = null;
            this.cmbS_STATUS.HierarchyInfo = hierarchy1;
            this.cmbS_STATUS.IsMultiLang = false;
            this.cmbS_STATUS.Location = new System.Drawing.Point(74, 201);
            this.cmbS_STATUS.Name = "cmbS_STATUS";
            this.cmbS_STATUS.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbS_STATUS.Size = new System.Drawing.Size(184, 20);
            this.cmbS_STATUS.StyleController = this.layoutControl1;
            this.cmbS_STATUS.TabIndex = 72;
            // 
            // txtS_ADDRESS
            // 
            this.txtS_ADDRESS.EditValue2 = null;
            this.txtS_ADDRESS.EraserGroup = "CLR1";
            this.txtS_ADDRESS.Location = new System.Drawing.Point(174, 177);
            this.txtS_ADDRESS.Name = "txtS_ADDRESS";
            this.txtS_ADDRESS.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_ADDRESS.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_ADDRESS.RequireMessage = null;
            this.txtS_ADDRESS.Size = new System.Drawing.Size(516, 20);
            this.txtS_ADDRESS.StyleController = this.layoutControl1;
            this.txtS_ADDRESS.TabIndex = 71;
            // 
            // btnS_ZIPCODE
            // 
            this.btnS_ZIPCODE.ByteLength = 10;
            this.btnS_ZIPCODE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnS_ZIPCODE.EditValue2 = null;
            this.btnS_ZIPCODE.EraserGroup = "CLR1";
            this.btnS_ZIPCODE.Location = new System.Drawing.Point(74, 177);
            this.btnS_ZIPCODE.Name = "btnS_ZIPCODE";
            this.btnS_ZIPCODE.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.btnS_ZIPCODE.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.btnS_ZIPCODE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.btnS_ZIPCODE.Size = new System.Drawing.Size(96, 20);
            this.btnS_ZIPCODE.StyleController = this.layoutControl1;
            this.btnS_ZIPCODE.TabIndex = 70;
            this.btnS_ZIPCODE.TabStop = false;
            this.btnS_ZIPCODE.Click += new System.EventHandler(this.btnS_ZIPCODE_Click);
            // 
            // txtS_FAX
            // 
            this.txtS_FAX.EditValue2 = null;
            this.txtS_FAX.EraserGroup = "CLR1";
            this.txtS_FAX.Location = new System.Drawing.Point(771, 153);
            this.txtS_FAX.Name = "txtS_FAX";
            this.txtS_FAX.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_FAX.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_FAX.RequireMessage = null;
            this.txtS_FAX.Size = new System.Drawing.Size(116, 20);
            this.txtS_FAX.StyleController = this.layoutControl1;
            this.txtS_FAX.TabIndex = 69;
            // 
            // txtS_PHONE
            // 
            this.txtS_PHONE.EditValue2 = null;
            this.txtS_PHONE.EraserGroup = "CLR1";
            this.txtS_PHONE.Location = new System.Drawing.Point(550, 153);
            this.txtS_PHONE.Name = "txtS_PHONE";
            this.txtS_PHONE.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_PHONE.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_PHONE.RequireMessage = null;
            this.txtS_PHONE.Size = new System.Drawing.Size(140, 20);
            this.txtS_PHONE.StyleController = this.layoutControl1;
            this.txtS_PHONE.TabIndex = 68;
            // 
            // txtS_TEL
            // 
            this.txtS_TEL.EditValue2 = null;
            this.txtS_TEL.EraserGroup = "CLR1";
            this.txtS_TEL.Location = new System.Drawing.Point(339, 153);
            this.txtS_TEL.Name = "txtS_TEL";
            this.txtS_TEL.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_TEL.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_TEL.RequireMessage = null;
            this.txtS_TEL.Size = new System.Drawing.Size(130, 20);
            this.txtS_TEL.StyleController = this.layoutControl1;
            this.txtS_TEL.TabIndex = 67;
            // 
            // txtS_RESPON_NAME
            // 
            this.txtS_RESPON_NAME.EditValue2 = null;
            this.txtS_RESPON_NAME.EraserGroup = "CLR1";
            this.txtS_RESPON_NAME.Location = new System.Drawing.Point(74, 153);
            this.txtS_RESPON_NAME.Name = "txtS_RESPON_NAME";
            this.txtS_RESPON_NAME.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_RESPON_NAME.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_RESPON_NAME.RequireMessage = null;
            this.txtS_RESPON_NAME.Size = new System.Drawing.Size(184, 20);
            this.txtS_RESPON_NAME.StyleController = this.layoutControl1;
            this.txtS_RESPON_NAME.TabIndex = 66;
            // 
            // txtS_ACCOUNT
            // 
            this.txtS_ACCOUNT.EditValue2 = null;
            this.txtS_ACCOUNT.EraserGroup = "CLR1";
            this.txtS_ACCOUNT.Location = new System.Drawing.Point(550, 129);
            this.txtS_ACCOUNT.Name = "txtS_ACCOUNT";
            this.txtS_ACCOUNT.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_ACCOUNT.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_ACCOUNT.RequireMessage = null;
            this.txtS_ACCOUNT.Size = new System.Drawing.Size(140, 20);
            this.txtS_ACCOUNT.StyleController = this.layoutControl1;
            this.txtS_ACCOUNT.TabIndex = 65;
            // 
            // cmbS_BANK
            // 
            childHierarchy2.CodeCtrl = null;
            childHierarchy2.DbName = null;
            childHierarchy2.SpName = null;
            this.cmbS_BANK.ChildHierarchyInfo = childHierarchy2;
            this.cmbS_BANK.EraserGroup = "CLR1";
            hierarchy2.DbName = null;
            hierarchy2.SpName = null;
            this.cmbS_BANK.HierarchyInfo = hierarchy2;
            this.cmbS_BANK.IsMultiLang = false;
            this.cmbS_BANK.Location = new System.Drawing.Point(339, 129);
            this.cmbS_BANK.Name = "cmbS_BANK";
            this.cmbS_BANK.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbS_BANK.Size = new System.Drawing.Size(130, 20);
            this.cmbS_BANK.StyleController = this.layoutControl1;
            this.cmbS_BANK.TabIndex = 64;
            // 
            // txtS_DEPOSITOR
            // 
            this.txtS_DEPOSITOR.EditValue2 = null;
            this.txtS_DEPOSITOR.EraserGroup = "CLR1";
            this.txtS_DEPOSITOR.Location = new System.Drawing.Point(74, 129);
            this.txtS_DEPOSITOR.Name = "txtS_DEPOSITOR";
            this.txtS_DEPOSITOR.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_DEPOSITOR.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_DEPOSITOR.RequireMessage = null;
            this.txtS_DEPOSITOR.Size = new System.Drawing.Size(184, 20);
            this.txtS_DEPOSITOR.StyleController = this.layoutControl1;
            this.txtS_DEPOSITOR.TabIndex = 63;
            // 
            // txtS_BUSINESS_TYPE
            // 
            this.txtS_BUSINESS_TYPE.EditValue2 = null;
            this.txtS_BUSINESS_TYPE.EraserGroup = "CLR1";
            this.txtS_BUSINESS_TYPE.Location = new System.Drawing.Point(339, 105);
            this.txtS_BUSINESS_TYPE.Name = "txtS_BUSINESS_TYPE";
            this.txtS_BUSINESS_TYPE.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_BUSINESS_TYPE.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_BUSINESS_TYPE.RequireMessage = null;
            this.txtS_BUSINESS_TYPE.Size = new System.Drawing.Size(130, 20);
            this.txtS_BUSINESS_TYPE.StyleController = this.layoutControl1;
            this.txtS_BUSINESS_TYPE.TabIndex = 62;
            // 
            // txtS_BUSINESS_CONDITION
            // 
            this.txtS_BUSINESS_CONDITION.EditValue2 = null;
            this.txtS_BUSINESS_CONDITION.EraserGroup = "CLR1";
            this.txtS_BUSINESS_CONDITION.Location = new System.Drawing.Point(74, 105);
            this.txtS_BUSINESS_CONDITION.Name = "txtS_BUSINESS_CONDITION";
            this.txtS_BUSINESS_CONDITION.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_BUSINESS_CONDITION.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_BUSINESS_CONDITION.RequireMessage = null;
            this.txtS_BUSINESS_CONDITION.Size = new System.Drawing.Size(184, 20);
            this.txtS_BUSINESS_CONDITION.StyleController = this.layoutControl1;
            this.txtS_BUSINESS_CONDITION.TabIndex = 61;
            // 
            // cmbS_TAX_TYPE
            // 
            childHierarchy3.CodeCtrl = null;
            childHierarchy3.DbName = null;
            childHierarchy3.SpName = null;
            this.cmbS_TAX_TYPE.ChildHierarchyInfo = childHierarchy3;
            this.cmbS_TAX_TYPE.EraserGroup = "CLR1";
            hierarchy3.DbName = null;
            hierarchy3.SpName = null;
            this.cmbS_TAX_TYPE.HierarchyInfo = hierarchy3;
            this.cmbS_TAX_TYPE.IsMultiLang = false;
            this.cmbS_TAX_TYPE.Location = new System.Drawing.Point(771, 81);
            this.cmbS_TAX_TYPE.Name = "cmbS_TAX_TYPE";
            this.cmbS_TAX_TYPE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbS_TAX_TYPE.Size = new System.Drawing.Size(116, 20);
            this.cmbS_TAX_TYPE.StyleController = this.layoutControl1;
            this.cmbS_TAX_TYPE.TabIndex = 60;
            // 
            // txtS_SALES_NUM
            // 
            this.txtS_SALES_NUM.EditValue2 = null;
            this.txtS_SALES_NUM.EraserGroup = "CLR1";
            this.txtS_SALES_NUM.Location = new System.Drawing.Point(550, 81);
            this.txtS_SALES_NUM.Name = "txtS_SALES_NUM";
            this.txtS_SALES_NUM.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_SALES_NUM.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_SALES_NUM.RequireMessage = null;
            this.txtS_SALES_NUM.Size = new System.Drawing.Size(140, 20);
            this.txtS_SALES_NUM.StyleController = this.layoutControl1;
            this.txtS_SALES_NUM.TabIndex = 59;
            // 
            // txtS_CORPORATE_NUM
            // 
            this.txtS_CORPORATE_NUM.EditValue2 = null;
            this.txtS_CORPORATE_NUM.EraserGroup = "CLR1";
            this.txtS_CORPORATE_NUM.Location = new System.Drawing.Point(339, 81);
            this.txtS_CORPORATE_NUM.Name = "txtS_CORPORATE_NUM";
            this.txtS_CORPORATE_NUM.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_CORPORATE_NUM.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_CORPORATE_NUM.RequireMessage = null;
            this.txtS_CORPORATE_NUM.Size = new System.Drawing.Size(130, 20);
            this.txtS_CORPORATE_NUM.StyleController = this.layoutControl1;
            this.txtS_CORPORATE_NUM.TabIndex = 58;
            // 
            // txtS_BUSINESS_NUM
            // 
            this.txtS_BUSINESS_NUM.EditValue2 = null;
            this.txtS_BUSINESS_NUM.EraserGroup = "CLR1";
            this.txtS_BUSINESS_NUM.Location = new System.Drawing.Point(74, 81);
            this.txtS_BUSINESS_NUM.Name = "txtS_BUSINESS_NUM";
            this.txtS_BUSINESS_NUM.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_BUSINESS_NUM.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_BUSINESS_NUM.RequireMessage = null;
            this.txtS_BUSINESS_NUM.Size = new System.Drawing.Size(184, 20);
            this.txtS_BUSINESS_NUM.StyleController = this.layoutControl1;
            this.txtS_BUSINESS_NUM.TabIndex = 57;
            // 
            // txtS_NICKNAME
            // 
            this.txtS_NICKNAME.EditValue2 = null;
            this.txtS_NICKNAME.EraserGroup = "CLR1";
            this.txtS_NICKNAME.Location = new System.Drawing.Point(339, 57);
            this.txtS_NICKNAME.Name = "txtS_NICKNAME";
            this.txtS_NICKNAME.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_NICKNAME.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_NICKNAME.RequireMessage = null;
            this.txtS_NICKNAME.Size = new System.Drawing.Size(130, 20);
            this.txtS_NICKNAME.StyleController = this.layoutControl1;
            this.txtS_NICKNAME.TabIndex = 56;
            // 
            // txtS_ID
            // 
            this.txtS_ID.EditValue2 = null;
            this.txtS_ID.EraserGroup = "CLR1";
            this.txtS_ID.Location = new System.Drawing.Point(74, 57);
            this.txtS_ID.Name = "txtS_ID";
            this.txtS_ID.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_ID.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_ID.RequireMessage = null;
            this.txtS_ID.Size = new System.Drawing.Size(184, 20);
            this.txtS_ID.StyleController = this.layoutControl1;
            this.txtS_ID.TabIndex = 55;
            // 
            // txtS_BOSS_NAME
            // 
            this.txtS_BOSS_NAME.EditValue2 = null;
            this.txtS_BOSS_NAME.EraserGroup = "CLR1";
            this.txtS_BOSS_NAME.Location = new System.Drawing.Point(550, 33);
            this.txtS_BOSS_NAME.Name = "txtS_BOSS_NAME";
            this.txtS_BOSS_NAME.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_BOSS_NAME.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_BOSS_NAME.RequireMessage = null;
            this.txtS_BOSS_NAME.Size = new System.Drawing.Size(140, 20);
            this.txtS_BOSS_NAME.StyleController = this.layoutControl1;
            this.txtS_BOSS_NAME.TabIndex = 54;
            // 
            // txtS_COMPANY_NAME
            // 
            this.txtS_COMPANY_NAME.EditValue2 = null;
            this.txtS_COMPANY_NAME.EraserGroup = "CLR1";
            this.txtS_COMPANY_NAME.Location = new System.Drawing.Point(74, 33);
            this.txtS_COMPANY_NAME.Name = "txtS_COMPANY_NAME";
            this.txtS_COMPANY_NAME.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txtS_COMPANY_NAME.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtS_COMPANY_NAME.RequireMessage = null;
            this.txtS_COMPANY_NAME.Size = new System.Drawing.Size(395, 20);
            this.txtS_COMPANY_NAME.StyleController = this.layoutControl1;
            this.txtS_COMPANY_NAME.TabIndex = 5;
            // 
            // cmbS_DIVISION
            // 
            childHierarchy4.CodeCtrl = null;
            childHierarchy4.DbName = null;
            childHierarchy4.SpName = null;
            this.cmbS_DIVISION.ChildHierarchyInfo = childHierarchy4;
            this.cmbS_DIVISION.EraserGroup = "CLR1";
            hierarchy4.DbName = null;
            hierarchy4.SpName = null;
            this.cmbS_DIVISION.HierarchyInfo = hierarchy4;
            this.cmbS_DIVISION.IsMultiLang = false;
            this.cmbS_DIVISION.Location = new System.Drawing.Point(74, 7);
            this.cmbS_DIVISION.Name = "cmbS_DIVISION";
            this.cmbS_DIVISION.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbS_DIVISION.Size = new System.Drawing.Size(184, 20);
            this.cmbS_DIVISION.StyleController = this.layoutControl1;
            this.cmbS_DIVISION.TabIndex = 4;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem3,
            this.layoutControlItem21,
            this.emptySpaceItem2,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.layoutControlItem6,
            this.emptySpaceItem22,
            this.layoutControlItem7,
            this.layoutControlItem24,
            this.emptySpaceItem23,
            this.layoutControlItem8,
            this.layoutControlItem12,
            this.layoutControlItem14,
            this.layoutControlItem17,
            this.layoutControlItem9,
            this.layoutControlItem13,
            this.layoutControlItem15,
            this.layoutControlItem18,
            this.layoutControlItem10,
            this.emptySpaceItem25,
            this.layoutControlItem16,
            this.layoutControlItem19,
            this.emptySpaceItem19,
            this.layoutControlItem22,
            this.emptySpaceItem21,
            this.emptySpaceItem9,
            this.layoutControlItem11,
            this.layoutControlItem23,
            this.emptySpaceItem18,
            this.layoutControlItem20,
            this.emptySpaceItem12,
            this.emptySpaceItem20,
            this.emptySpaceItem4,
            this.emptySpaceItem6,
            this.emptySpaceItem7,
            this.emptySpaceItem8,
            this.layoutControlItem25,
            this.layoutControlItem26,
            this.emptySpaceItem10});
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Padding = new DevExpress.XtraLayout.Utils.Padding(5, 5, 5, 2);
            this.layoutControlGroup1.Size = new System.Drawing.Size(1180, 236);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.cmbS_DIVISION;
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(255, 26);
            this.layoutControlItem3.Text = "구분";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem21
            // 
            this.layoutControlItem21.Control = this.btnS_ZIPCODE;
            this.layoutControlItem21.Location = new System.Drawing.Point(0, 170);
            this.layoutControlItem21.Name = "layoutControlItem21";
            this.layoutControlItem21.Size = new System.Drawing.Size(167, 24);
            this.layoutControlItem21.Text = "주소";
            this.layoutControlItem21.TextSize = new System.Drawing.Size(64, 14);
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.Location = new System.Drawing.Point(255, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(442, 26);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.txtS_COMPANY_NAME;
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(466, 24);
            this.layoutControlItem4.Text = "거래처명";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.txtS_BOSS_NAME;
            this.layoutControlItem5.Location = new System.Drawing.Point(476, 26);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(211, 24);
            this.layoutControlItem5.Text = "대표자명";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.txtS_ID;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(255, 24);
            this.layoutControlItem6.Text = "아이디";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(64, 14);
            // 
            // emptySpaceItem22
            // 
            this.emptySpaceItem22.AllowHotTrack = false;
            this.emptySpaceItem22.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem22.Location = new System.Drawing.Point(255, 50);
            this.emptySpaceItem22.Name = "emptySpaceItem22";
            this.emptySpaceItem22.Size = new System.Drawing.Size(10, 120);
            this.emptySpaceItem22.Text = "emptySpaceItem2";
            this.emptySpaceItem22.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.txtS_NICKNAME;
            this.layoutControlItem7.Location = new System.Drawing.Point(265, 50);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(201, 24);
            this.layoutControlItem7.Text = "닉네임";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem24
            // 
            this.layoutControlItem24.Control = this.txtS_PASSWORD;
            this.layoutControlItem24.Location = new System.Drawing.Point(476, 50);
            this.layoutControlItem24.Name = "layoutControlItem24";
            this.layoutControlItem24.Size = new System.Drawing.Size(211, 24);
            this.layoutControlItem24.Text = "비밀번호";
            this.layoutControlItem24.TextSize = new System.Drawing.Size(64, 14);
            // 
            // emptySpaceItem23
            // 
            this.emptySpaceItem23.AllowHotTrack = false;
            this.emptySpaceItem23.Location = new System.Drawing.Point(697, 26);
            this.emptySpaceItem23.Name = "emptySpaceItem23";
            this.emptySpaceItem23.Size = new System.Drawing.Size(187, 23);
            this.emptySpaceItem23.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.txtS_BUSINESS_NUM;
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 74);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(255, 24);
            this.layoutControlItem8.Text = "사업자번호";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.txtS_BUSINESS_CONDITION;
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 98);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(255, 24);
            this.layoutControlItem12.Text = "업태";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.txtS_DEPOSITOR;
            this.layoutControlItem14.Location = new System.Drawing.Point(0, 122);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(255, 24);
            this.layoutControlItem14.Text = "예금주";
            this.layoutControlItem14.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.txtS_RESPON_NAME;
            this.layoutControlItem17.Location = new System.Drawing.Point(0, 146);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(255, 24);
            this.layoutControlItem17.Text = "담당자명";
            this.layoutControlItem17.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.txtS_CORPORATE_NUM;
            this.layoutControlItem9.Location = new System.Drawing.Point(265, 74);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(201, 24);
            this.layoutControlItem9.Text = "법인등록 번호";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.txtS_BUSINESS_TYPE;
            this.layoutControlItem13.Location = new System.Drawing.Point(265, 98);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(201, 24);
            this.layoutControlItem13.Text = "업종";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.cmbS_BANK;
            this.layoutControlItem15.Location = new System.Drawing.Point(265, 122);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(201, 24);
            this.layoutControlItem15.Text = "은행명";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.txtS_TEL;
            this.layoutControlItem18.Location = new System.Drawing.Point(265, 146);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(201, 24);
            this.layoutControlItem18.Text = "전화번호";
            this.layoutControlItem18.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.txtS_SALES_NUM;
            this.layoutControlItem10.Location = new System.Drawing.Point(476, 74);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(211, 24);
            this.layoutControlItem10.Text = "통신판매 번호";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(64, 14);
            // 
            // emptySpaceItem25
            // 
            this.emptySpaceItem25.AllowHotTrack = false;
            this.emptySpaceItem25.Location = new System.Drawing.Point(476, 98);
            this.emptySpaceItem25.Name = "emptySpaceItem25";
            this.emptySpaceItem25.Size = new System.Drawing.Size(211, 24);
            this.emptySpaceItem25.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.txtS_ACCOUNT;
            this.layoutControlItem16.Location = new System.Drawing.Point(476, 122);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(211, 24);
            this.layoutControlItem16.Text = "계좌번호";
            this.layoutControlItem16.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.txtS_PHONE;
            this.layoutControlItem19.Location = new System.Drawing.Point(476, 146);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(211, 24);
            this.layoutControlItem19.Text = "휴대폰 번호";
            this.layoutControlItem19.TextSize = new System.Drawing.Size(64, 14);
            // 
            // emptySpaceItem19
            // 
            this.emptySpaceItem19.AllowHotTrack = false;
            this.emptySpaceItem19.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem19.Location = new System.Drawing.Point(697, 194);
            this.emptySpaceItem19.Name = "emptySpaceItem19";
            this.emptySpaceItem19.Size = new System.Drawing.Size(187, 24);
            this.emptySpaceItem19.Text = "emptySpaceItem2";
            this.emptySpaceItem19.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem22
            // 
            this.layoutControlItem22.Control = this.txtS_ADDRESS;
            this.layoutControlItem22.Location = new System.Drawing.Point(167, 170);
            this.layoutControlItem22.Name = "layoutControlItem22";
            this.layoutControlItem22.Size = new System.Drawing.Size(520, 24);
            this.layoutControlItem22.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem22.TextVisible = false;
            // 
            // emptySpaceItem21
            // 
            this.emptySpaceItem21.AllowHotTrack = false;
            this.emptySpaceItem21.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem21.Location = new System.Drawing.Point(466, 26);
            this.emptySpaceItem21.Name = "emptySpaceItem21";
            this.emptySpaceItem21.Size = new System.Drawing.Size(10, 144);
            this.emptySpaceItem21.Text = "emptySpaceItem2";
            this.emptySpaceItem21.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem9
            // 
            this.emptySpaceItem9.AllowHotTrack = false;
            this.emptySpaceItem9.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem9.Location = new System.Drawing.Point(697, 98);
            this.emptySpaceItem9.Name = "emptySpaceItem9";
            this.emptySpaceItem9.Size = new System.Drawing.Size(187, 24);
            this.emptySpaceItem9.Text = "emptySpaceItem2";
            this.emptySpaceItem9.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.cmbS_TAX_TYPE;
            this.layoutControlItem11.Location = new System.Drawing.Point(697, 74);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(187, 24);
            this.layoutControlItem11.Text = "과세 유형";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(64, 14);
            // 
            // layoutControlItem23
            // 
            this.layoutControlItem23.Control = this.cmbS_STATUS;
            this.layoutControlItem23.Location = new System.Drawing.Point(0, 194);
            this.layoutControlItem23.Name = "layoutControlItem23";
            this.layoutControlItem23.Size = new System.Drawing.Size(255, 24);
            this.layoutControlItem23.Text = "판매여부";
            this.layoutControlItem23.TextSize = new System.Drawing.Size(64, 14);
            // 
            // emptySpaceItem18
            // 
            this.emptySpaceItem18.AllowHotTrack = false;
            this.emptySpaceItem18.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem18.Location = new System.Drawing.Point(687, 26);
            this.emptySpaceItem18.Name = "emptySpaceItem18";
            this.emptySpaceItem18.Size = new System.Drawing.Size(10, 192);
            this.emptySpaceItem18.Text = "emptySpaceItem2";
            this.emptySpaceItem18.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.Control = this.txtS_FAX;
            this.layoutControlItem20.Location = new System.Drawing.Point(697, 146);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Size = new System.Drawing.Size(187, 24);
            this.layoutControlItem20.Text = "FAX 번호";
            this.layoutControlItem20.TextSize = new System.Drawing.Size(64, 14);
            // 
            // emptySpaceItem12
            // 
            this.emptySpaceItem12.AllowHotTrack = false;
            this.emptySpaceItem12.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem12.Location = new System.Drawing.Point(884, 26);
            this.emptySpaceItem12.Name = "emptySpaceItem12";
            this.emptySpaceItem12.Size = new System.Drawing.Size(286, 192);
            this.emptySpaceItem12.Text = "emptySpaceItem2";
            this.emptySpaceItem12.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem20
            // 
            this.emptySpaceItem20.AllowHotTrack = false;
            this.emptySpaceItem20.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem20.Location = new System.Drawing.Point(255, 194);
            this.emptySpaceItem20.Name = "emptySpaceItem20";
            this.emptySpaceItem20.Size = new System.Drawing.Size(432, 24);
            this.emptySpaceItem20.Text = "emptySpaceItem2";
            this.emptySpaceItem20.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem4.Location = new System.Drawing.Point(697, 49);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(187, 25);
            this.emptySpaceItem4.Text = "emptySpaceItem2";
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem6
            // 
            this.emptySpaceItem6.AllowHotTrack = false;
            this.emptySpaceItem6.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem6.Location = new System.Drawing.Point(697, 122);
            this.emptySpaceItem6.Name = "emptySpaceItem6";
            this.emptySpaceItem6.Size = new System.Drawing.Size(187, 24);
            this.emptySpaceItem6.Text = "emptySpaceItem2";
            this.emptySpaceItem6.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem7
            // 
            this.emptySpaceItem7.AllowHotTrack = false;
            this.emptySpaceItem7.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem7.Location = new System.Drawing.Point(697, 170);
            this.emptySpaceItem7.Name = "emptySpaceItem7";
            this.emptySpaceItem7.Size = new System.Drawing.Size(187, 24);
            this.emptySpaceItem7.Text = "emptySpaceItem2";
            this.emptySpaceItem7.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem8
            // 
            this.emptySpaceItem8.AllowHotTrack = false;
            this.emptySpaceItem8.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem8.Location = new System.Drawing.Point(0, 218);
            this.emptySpaceItem8.Name = "emptySpaceItem8";
            this.emptySpaceItem8.Size = new System.Drawing.Size(1170, 11);
            this.emptySpaceItem8.Text = "emptySpaceItem2";
            this.emptySpaceItem8.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem25
            // 
            this.layoutControlItem25.Control = this.BtnNEW;
            this.layoutControlItem25.Location = new System.Drawing.Point(697, 0);
            this.layoutControlItem25.Name = "layoutControlItem25";
            this.layoutControlItem25.Size = new System.Drawing.Size(92, 26);
            this.layoutControlItem25.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem25.TextVisible = false;
            // 
            // layoutControlItem26
            // 
            this.layoutControlItem26.Control = this.btnSAVE;
            this.layoutControlItem26.Location = new System.Drawing.Point(789, 0);
            this.layoutControlItem26.Name = "layoutControlItem26";
            this.layoutControlItem26.Size = new System.Drawing.Size(95, 26);
            this.layoutControlItem26.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem26.TextVisible = false;
            // 
            // emptySpaceItem10
            // 
            this.emptySpaceItem10.AllowHotTrack = false;
            this.emptySpaceItem10.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem10.Location = new System.Drawing.Point(884, 0);
            this.emptySpaceItem10.Name = "emptySpaceItem10";
            this.emptySpaceItem10.Size = new System.Drawing.Size(286, 26);
            this.emptySpaceItem10.Text = "emptySpaceItem2";
            this.emptySpaceItem10.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem1.Location = new System.Drawing.Point(1109, 24);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(131, 24);
            this.emptySpaceItem1.Text = "emptySpaceItem2";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem11
            // 
            this.emptySpaceItem11.AllowHotTrack = false;
            this.emptySpaceItem11.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem11.Location = new System.Drawing.Point(978, 24);
            this.emptySpaceItem11.Name = "emptySpaceItem11";
            this.emptySpaceItem11.Size = new System.Drawing.Size(10, 144);
            this.emptySpaceItem11.Text = "emptySpaceItem2";
            this.emptySpaceItem11.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem3.Location = new System.Drawing.Point(1109, 24);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(131, 24);
            this.emptySpaceItem3.Text = "emptySpaceItem2";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem13
            // 
            this.emptySpaceItem13.AllowHotTrack = false;
            this.emptySpaceItem13.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem13.Location = new System.Drawing.Point(847, 24);
            this.emptySpaceItem13.Name = "emptySpaceItem13";
            this.emptySpaceItem13.Size = new System.Drawing.Size(10, 189);
            this.emptySpaceItem13.Text = "emptySpaceItem2";
            this.emptySpaceItem13.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem14
            // 
            this.emptySpaceItem14.AllowHotTrack = false;
            this.emptySpaceItem14.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem14.Location = new System.Drawing.Point(978, 24);
            this.emptySpaceItem14.Name = "emptySpaceItem14";
            this.emptySpaceItem14.Size = new System.Drawing.Size(10, 144);
            this.emptySpaceItem14.Text = "emptySpaceItem2";
            this.emptySpaceItem14.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem16
            // 
            this.emptySpaceItem16.AllowHotTrack = false;
            this.emptySpaceItem16.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem16.Location = new System.Drawing.Point(847, 24);
            this.emptySpaceItem16.Name = "emptySpaceItem16";
            this.emptySpaceItem16.Size = new System.Drawing.Size(10, 189);
            this.emptySpaceItem16.Text = "emptySpaceItem2";
            this.emptySpaceItem16.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem17
            // 
            this.emptySpaceItem17.AllowHotTrack = false;
            this.emptySpaceItem17.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem17.Location = new System.Drawing.Point(988, 24);
            this.emptySpaceItem17.Name = "emptySpaceItem17";
            this.emptySpaceItem17.Size = new System.Drawing.Size(252, 14);
            this.emptySpaceItem17.Text = "emptySpaceItem2";
            this.emptySpaceItem17.TextSize = new System.Drawing.Size(0, 0);
            // 
            // frmTM07
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.efwGroupControl2);
            this.Controls.Add(this.splitterControl1);
            this.Controls.Add(this.efwGroupControl1);
            this.Name = "frmTM07";
            this.Size = new System.Drawing.Size(1190, 757);
            this.Load += new System.EventHandler(this.frmTM07_Load);
            this.Controls.SetChildIndex(this.efwGroupControl1, 0);
            this.Controls.SetChildIndex(this.splitterControl1, 0);
            this.Controls.SetChildIndex(this.efwGroupControl2, 0);
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl1)).EndInit();
            this.efwGroupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl2)).EndInit();
            this.layoutControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwPanelControl2)).EndInit();
            this.efwPanelControl2.ResumeLayout(false);
            this.efwPanelControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_ADDRESS1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_IDX.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_U_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQ_AGENCY_NAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl2)).EndInit();
            this.efwGroupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtS_PASSWORD.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbS_STATUS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_ADDRESS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnS_ZIPCODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_FAX.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_PHONE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_TEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_RESPON_NAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_ACCOUNT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbS_BANK.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_DEPOSITOR.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_BUSINESS_TYPE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_BUSINESS_CONDITION.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbS_TAX_TYPE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_SALES_NUM.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_CORPORATE_NUM.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_BUSINESS_NUM.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_NICKNAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_BOSS_NAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtS_COMPANY_NAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbS_DIVISION.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem17)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Easy.Framework.WinForm.Control.efwGroupControl efwGroupControl1;
        private DevExpress.XtraLayout.LayoutControl layoutControl2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private Easy.Framework.WinForm.Control.efwPanelControl efwPanelControl2;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel2;
        private Easy.Framework.WinForm.Control.efwTextEdit txtQ_AGENCY_NAME;
        private DevExpress.XtraEditors.SplitterControl splitterControl1;
        private Easy.Framework.WinForm.Control.efwGridControl efwGridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn27;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn28;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEdit1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel7;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel23;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_ADDRESS1;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_IDX;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_U_ID;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private Easy.Framework.WinForm.Control.efwGroupControl efwGroupControl2;
        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_PASSWORD;
        private Easy.Framework.WinForm.Control.efwLookUpEdit cmbS_STATUS;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_ADDRESS;
        private Easy.Framework.WinForm.Control.efwButtonEdit btnS_ZIPCODE;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_FAX;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_PHONE;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_TEL;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_RESPON_NAME;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_ACCOUNT;
        private Easy.Framework.WinForm.Control.efwLookUpEdit cmbS_BANK;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_DEPOSITOR;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_BUSINESS_TYPE;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_BUSINESS_CONDITION;
        private Easy.Framework.WinForm.Control.efwLookUpEdit cmbS_TAX_TYPE;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_SALES_NUM;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_CORPORATE_NUM;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_BUSINESS_NUM;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_NICKNAME;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_ID;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_BOSS_NAME;
        private Easy.Framework.WinForm.Control.efwTextEdit txtS_COMPANY_NAME;
        private Easy.Framework.WinForm.Control.efwLookUpEdit cmbS_DIVISION;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem21;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem22;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem23;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem24;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem11;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem13;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem14;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem16;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem9;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem17;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem18;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem19;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem21;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem22;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem23;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem25;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem12;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem20;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem6;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem7;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem8;
        private Easy.Framework.WinForm.Control.efwSimpleButton BtnNEW;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem25;
        private Easy.Framework.WinForm.Control.efwSimpleButton btnSAVE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem26;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem10;
    }
}