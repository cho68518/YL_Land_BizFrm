﻿namespace YL_RM.BizFrm
{
    partial class frmRM01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRM01));
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.simpleButton9 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton10 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton7 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton8 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton5 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton6 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton3 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton4 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.picBest_Pic5 = new DevExpress.XtraEditors.PictureEdit();
            this.txtShooting_Date5 = new DevExpress.XtraEditors.TextEdit();
            this.label7 = new System.Windows.Forms.Label();
            this.picBest_Pic4 = new DevExpress.XtraEditors.PictureEdit();
            this.txtShooting_Date4 = new DevExpress.XtraEditors.TextEdit();
            this.label6 = new System.Windows.Forms.Label();
            this.picBest_Pic3 = new DevExpress.XtraEditors.PictureEdit();
            this.txtShooting_Date3 = new DevExpress.XtraEditors.TextEdit();
            this.label5 = new System.Windows.Forms.Label();
            this.picBest_Pic2 = new DevExpress.XtraEditors.PictureEdit();
            this.txtShooting_Date2 = new DevExpress.XtraEditors.TextEdit();
            this.label4 = new System.Windows.Forms.Label();
            this.picBest_Pic1 = new DevExpress.XtraEditors.PictureEdit();
            this.txtShooting_Date1 = new DevExpress.XtraEditors.TextEdit();
            this.label3 = new System.Windows.Forms.Label();
            this.splitterControl1 = new DevExpress.XtraEditors.SplitterControl();
            this.efwGridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtPic_Url1 = new DevExpress.XtraEditors.TextEdit();
            this.txtPic_Url2 = new DevExpress.XtraEditors.TextEdit();
            this.txtPic_Url4 = new DevExpress.XtraEditors.TextEdit();
            this.txtPic_Url5 = new DevExpress.XtraEditors.TextEdit();
            this.txtPic_Url3 = new DevExpress.XtraEditors.TextEdit();
            this.label2 = new System.Windows.Forms.Label();
            this.dtE_DATE = new DevExpress.XtraEditors.DateEdit();
            this.dtS_DATE = new DevExpress.XtraEditors.DateEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.ckChoice4 = new DevExpress.XtraEditors.CheckEdit();
            this.ckChoice3 = new DevExpress.XtraEditors.CheckEdit();
            this.ckChoice2 = new DevExpress.XtraEditors.CheckEdit();
            this.ckChoice1 = new DevExpress.XtraEditors.CheckEdit();
            this.pictureEdit7 = new DevExpress.XtraEditors.PictureEdit();
            this.pictureEdit8 = new DevExpress.XtraEditors.PictureEdit();
            this.pictureEdit5 = new DevExpress.XtraEditors.PictureEdit();
            this.pictureEdit6 = new DevExpress.XtraEditors.PictureEdit();
            this.pictureEdit3 = new DevExpress.XtraEditors.PictureEdit();
            this.pictureEdit4 = new DevExpress.XtraEditors.PictureEdit();
            this.pictureEdit2 = new DevExpress.XtraEditors.PictureEdit();
            this.pictureEdit1 = new DevExpress.XtraEditors.PictureEdit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtE_DATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtE_DATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtS_DATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtS_DATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckChoice4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckChoice3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckChoice2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckChoice1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit7.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit8.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.Location = new System.Drawing.Point(3, 35);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.groupControl1);
            this.splitContainerControl1.Panel1.Controls.Add(this.splitterControl1);
            this.splitContainerControl1.Panel1.Controls.Add(this.efwGridControl1);
            this.splitContainerControl1.Panel1.Controls.Add(this.panel2);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.ckChoice4);
            this.splitContainerControl1.Panel2.Controls.Add(this.ckChoice3);
            this.splitContainerControl1.Panel2.Controls.Add(this.ckChoice2);
            this.splitContainerControl1.Panel2.Controls.Add(this.ckChoice1);
            this.splitContainerControl1.Panel2.Controls.Add(this.pictureEdit7);
            this.splitContainerControl1.Panel2.Controls.Add(this.pictureEdit8);
            this.splitContainerControl1.Panel2.Controls.Add(this.pictureEdit5);
            this.splitContainerControl1.Panel2.Controls.Add(this.pictureEdit6);
            this.splitContainerControl1.Panel2.Controls.Add(this.pictureEdit3);
            this.splitContainerControl1.Panel2.Controls.Add(this.pictureEdit4);
            this.splitContainerControl1.Panel2.Controls.Add(this.pictureEdit2);
            this.splitContainerControl1.Panel2.Controls.Add(this.pictureEdit1);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1436, 817);
            this.splitContainerControl1.SplitterPosition = 946;
            this.splitContainerControl1.TabIndex = 2;
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.simpleButton9);
            this.groupControl1.Controls.Add(this.simpleButton10);
            this.groupControl1.Controls.Add(this.simpleButton7);
            this.groupControl1.Controls.Add(this.simpleButton8);
            this.groupControl1.Controls.Add(this.simpleButton5);
            this.groupControl1.Controls.Add(this.simpleButton6);
            this.groupControl1.Controls.Add(this.simpleButton3);
            this.groupControl1.Controls.Add(this.simpleButton4);
            this.groupControl1.Controls.Add(this.simpleButton2);
            this.groupControl1.Controls.Add(this.simpleButton1);
            this.groupControl1.Controls.Add(this.picBest_Pic5);
            this.groupControl1.Controls.Add(this.txtShooting_Date5);
            this.groupControl1.Controls.Add(this.label7);
            this.groupControl1.Controls.Add(this.picBest_Pic4);
            this.groupControl1.Controls.Add(this.txtShooting_Date4);
            this.groupControl1.Controls.Add(this.label6);
            this.groupControl1.Controls.Add(this.picBest_Pic3);
            this.groupControl1.Controls.Add(this.txtShooting_Date3);
            this.groupControl1.Controls.Add(this.label5);
            this.groupControl1.Controls.Add(this.picBest_Pic2);
            this.groupControl1.Controls.Add(this.txtShooting_Date2);
            this.groupControl1.Controls.Add(this.label4);
            this.groupControl1.Controls.Add(this.picBest_Pic1);
            this.groupControl1.Controls.Add(this.txtShooting_Date1);
            this.groupControl1.Controls.Add(this.label3);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl1.Location = new System.Drawing.Point(0, 577);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(946, 240);
            this.groupControl1.TabIndex = 3;
            this.groupControl1.Text = "발모후기 선택";
            // 
            // simpleButton9
            // 
            this.simpleButton9.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton9.ImageOptions.Image")));
            this.simpleButton9.Location = new System.Drawing.Point(826, 197);
            this.simpleButton9.Name = "simpleButton9";
            this.simpleButton9.Size = new System.Drawing.Size(75, 23);
            this.simpleButton9.TabIndex = 32;
            this.simpleButton9.Text = "After";
            // 
            // simpleButton10
            // 
            this.simpleButton10.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton10.ImageOptions.Image")));
            this.simpleButton10.Location = new System.Drawing.Point(744, 197);
            this.simpleButton10.Name = "simpleButton10";
            this.simpleButton10.Size = new System.Drawing.Size(75, 23);
            this.simpleButton10.TabIndex = 31;
            this.simpleButton10.Text = "Before";
            // 
            // simpleButton7
            // 
            this.simpleButton7.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton7.ImageOptions.Image")));
            this.simpleButton7.Location = new System.Drawing.Point(650, 197);
            this.simpleButton7.Name = "simpleButton7";
            this.simpleButton7.Size = new System.Drawing.Size(75, 23);
            this.simpleButton7.TabIndex = 30;
            this.simpleButton7.Text = "After";
            // 
            // simpleButton8
            // 
            this.simpleButton8.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton8.ImageOptions.Image")));
            this.simpleButton8.Location = new System.Drawing.Point(568, 197);
            this.simpleButton8.Name = "simpleButton8";
            this.simpleButton8.Size = new System.Drawing.Size(75, 23);
            this.simpleButton8.TabIndex = 29;
            this.simpleButton8.Text = "Before";
            // 
            // simpleButton5
            // 
            this.simpleButton5.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton5.ImageOptions.Image")));
            this.simpleButton5.Location = new System.Drawing.Point(474, 197);
            this.simpleButton5.Name = "simpleButton5";
            this.simpleButton5.Size = new System.Drawing.Size(75, 23);
            this.simpleButton5.TabIndex = 28;
            this.simpleButton5.Text = "After";
            // 
            // simpleButton6
            // 
            this.simpleButton6.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton6.ImageOptions.Image")));
            this.simpleButton6.Location = new System.Drawing.Point(392, 197);
            this.simpleButton6.Name = "simpleButton6";
            this.simpleButton6.Size = new System.Drawing.Size(75, 23);
            this.simpleButton6.TabIndex = 27;
            this.simpleButton6.Text = "Before";
            // 
            // simpleButton3
            // 
            this.simpleButton3.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton3.ImageOptions.Image")));
            this.simpleButton3.Location = new System.Drawing.Point(298, 197);
            this.simpleButton3.Name = "simpleButton3";
            this.simpleButton3.Size = new System.Drawing.Size(75, 23);
            this.simpleButton3.TabIndex = 26;
            this.simpleButton3.Text = "After";
            // 
            // simpleButton4
            // 
            this.simpleButton4.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton4.ImageOptions.Image")));
            this.simpleButton4.Location = new System.Drawing.Point(216, 197);
            this.simpleButton4.Name = "simpleButton4";
            this.simpleButton4.Size = new System.Drawing.Size(75, 23);
            this.simpleButton4.TabIndex = 25;
            this.simpleButton4.Text = "Before";
            // 
            // simpleButton2
            // 
            this.simpleButton2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton2.ImageOptions.Image")));
            this.simpleButton2.Location = new System.Drawing.Point(120, 197);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(75, 23);
            this.simpleButton2.TabIndex = 24;
            this.simpleButton2.Text = "After";
            // 
            // simpleButton1
            // 
            this.simpleButton1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.ImageOptions.Image")));
            this.simpleButton1.Location = new System.Drawing.Point(38, 197);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(75, 23);
            this.simpleButton1.TabIndex = 23;
            this.simpleButton1.Text = "Before";
            // 
            // picBest_Pic5
            // 
            this.picBest_Pic5.Location = new System.Drawing.Point(738, 55);
            this.picBest_Pic5.Name = "picBest_Pic5";
            this.picBest_Pic5.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.picBest_Pic5.Size = new System.Drawing.Size(170, 132);
            this.picBest_Pic5.TabIndex = 22;
            // 
            // txtShooting_Date5
            // 
            this.txtShooting_Date5.Location = new System.Drawing.Point(816, 29);
            this.txtShooting_Date5.Name = "txtShooting_Date5";
            this.txtShooting_Date5.Size = new System.Drawing.Size(92, 20);
            this.txtShooting_Date5.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(762, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 14);
            this.label7.TabIndex = 21;
            this.label7.Text = "촬영일";
            // 
            // picBest_Pic4
            // 
            this.picBest_Pic4.Location = new System.Drawing.Point(562, 55);
            this.picBest_Pic4.Name = "picBest_Pic4";
            this.picBest_Pic4.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.picBest_Pic4.Size = new System.Drawing.Size(170, 132);
            this.picBest_Pic4.TabIndex = 19;
            // 
            // txtShooting_Date4
            // 
            this.txtShooting_Date4.Location = new System.Drawing.Point(640, 29);
            this.txtShooting_Date4.Name = "txtShooting_Date4";
            this.txtShooting_Date4.Size = new System.Drawing.Size(92, 20);
            this.txtShooting_Date4.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(586, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 14);
            this.label6.TabIndex = 18;
            this.label6.Text = "촬영일";
            // 
            // picBest_Pic3
            // 
            this.picBest_Pic3.Location = new System.Drawing.Point(386, 55);
            this.picBest_Pic3.Name = "picBest_Pic3";
            this.picBest_Pic3.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.picBest_Pic3.Size = new System.Drawing.Size(170, 132);
            this.picBest_Pic3.TabIndex = 16;
            // 
            // txtShooting_Date3
            // 
            this.txtShooting_Date3.Location = new System.Drawing.Point(464, 29);
            this.txtShooting_Date3.Name = "txtShooting_Date3";
            this.txtShooting_Date3.Size = new System.Drawing.Size(92, 20);
            this.txtShooting_Date3.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(410, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 14);
            this.label5.TabIndex = 15;
            this.label5.Text = "촬영일";
            // 
            // picBest_Pic2
            // 
            this.picBest_Pic2.Location = new System.Drawing.Point(210, 55);
            this.picBest_Pic2.Name = "picBest_Pic2";
            this.picBest_Pic2.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.picBest_Pic2.Size = new System.Drawing.Size(170, 132);
            this.picBest_Pic2.TabIndex = 13;
            // 
            // txtShooting_Date2
            // 
            this.txtShooting_Date2.Location = new System.Drawing.Point(288, 29);
            this.txtShooting_Date2.Name = "txtShooting_Date2";
            this.txtShooting_Date2.Size = new System.Drawing.Size(92, 20);
            this.txtShooting_Date2.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(234, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 14);
            this.label4.TabIndex = 12;
            this.label4.Text = "촬영일";
            // 
            // picBest_Pic1
            // 
            this.picBest_Pic1.Location = new System.Drawing.Point(34, 55);
            this.picBest_Pic1.Name = "picBest_Pic1";
            this.picBest_Pic1.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.picBest_Pic1.Size = new System.Drawing.Size(170, 132);
            this.picBest_Pic1.TabIndex = 10;
            // 
            // txtShooting_Date1
            // 
            this.txtShooting_Date1.Location = new System.Drawing.Point(112, 29);
            this.txtShooting_Date1.Name = "txtShooting_Date1";
            this.txtShooting_Date1.Size = new System.Drawing.Size(92, 20);
            this.txtShooting_Date1.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 14);
            this.label3.TabIndex = 9;
            this.label3.Text = "촬영일";
            // 
            // splitterControl1
            // 
            this.splitterControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitterControl1.Location = new System.Drawing.Point(0, 572);
            this.splitterControl1.Name = "splitterControl1";
            this.splitterControl1.Size = new System.Drawing.Size(946, 5);
            this.splitterControl1.TabIndex = 2;
            this.splitterControl1.TabStop = false;
            // 
            // efwGridControl1
            // 
            this.efwGridControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwGridControl1.Location = new System.Drawing.Point(0, 56);
            this.efwGridControl1.MainView = this.gridView1;
            this.efwGridControl1.Name = "efwGridControl1";
            this.efwGridControl1.Size = new System.Drawing.Size(946, 516);
            this.efwGridControl1.TabIndex = 1;
            this.efwGridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.efwGridControl1;
            this.gridView1.Name = "gridView1";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtPic_Url1);
            this.panel2.Controls.Add(this.txtPic_Url2);
            this.panel2.Controls.Add(this.txtPic_Url4);
            this.panel2.Controls.Add(this.txtPic_Url5);
            this.panel2.Controls.Add(this.txtPic_Url3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.dtE_DATE);
            this.panel2.Controls.Add(this.dtS_DATE);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(946, 56);
            this.panel2.TabIndex = 0;
            // 
            // txtPic_Url1
            // 
            this.txtPic_Url1.Location = new System.Drawing.Point(411, 19);
            this.txtPic_Url1.Name = "txtPic_Url1";
            this.txtPic_Url1.Size = new System.Drawing.Size(30, 20);
            this.txtPic_Url1.TabIndex = 8;
            // 
            // txtPic_Url2
            // 
            this.txtPic_Url2.Location = new System.Drawing.Point(447, 19);
            this.txtPic_Url2.Name = "txtPic_Url2";
            this.txtPic_Url2.Size = new System.Drawing.Size(30, 20);
            this.txtPic_Url2.TabIndex = 7;
            // 
            // txtPic_Url4
            // 
            this.txtPic_Url4.Location = new System.Drawing.Point(519, 19);
            this.txtPic_Url4.Name = "txtPic_Url4";
            this.txtPic_Url4.Size = new System.Drawing.Size(30, 20);
            this.txtPic_Url4.TabIndex = 6;
            // 
            // txtPic_Url5
            // 
            this.txtPic_Url5.Location = new System.Drawing.Point(555, 19);
            this.txtPic_Url5.Name = "txtPic_Url5";
            this.txtPic_Url5.Size = new System.Drawing.Size(30, 20);
            this.txtPic_Url5.TabIndex = 5;
            // 
            // txtPic_Url3
            // 
            this.txtPic_Url3.Location = new System.Drawing.Point(483, 19);
            this.txtPic_Url3.Name = "txtPic_Url3";
            this.txtPic_Url3.Size = new System.Drawing.Size(30, 20);
            this.txtPic_Url3.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(187, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 14);
            this.label2.TabIndex = 3;
            this.label2.Text = "~";
            // 
            // dtE_DATE
            // 
            this.dtE_DATE.EditValue = new System.DateTime(2020, 10, 21, 12, 37, 3, 0);
            this.dtE_DATE.Location = new System.Drawing.Point(210, 19);
            this.dtE_DATE.Name = "dtE_DATE";
            this.dtE_DATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtE_DATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtE_DATE.Size = new System.Drawing.Size(100, 20);
            this.dtE_DATE.TabIndex = 2;
            // 
            // dtS_DATE
            // 
            this.dtS_DATE.EditValue = new System.DateTime(2020, 10, 21, 12, 36, 52, 0);
            this.dtS_DATE.Location = new System.Drawing.Point(81, 19);
            this.dtS_DATE.Name = "dtS_DATE";
            this.dtS_DATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtS_DATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtS_DATE.Size = new System.Drawing.Size(100, 20);
            this.dtS_DATE.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "등록일";
            // 
            // ckChoice4
            // 
            this.ckChoice4.Location = new System.Drawing.Point(19, 666);
            this.ckChoice4.Name = "ckChoice4";
            this.ckChoice4.Properties.Caption = "checkEdit4";
            this.ckChoice4.Size = new System.Drawing.Size(17, 19);
            this.ckChoice4.TabIndex = 44;
            // 
            // ckChoice3
            // 
            this.ckChoice3.Location = new System.Drawing.Point(19, 486);
            this.ckChoice3.Name = "ckChoice3";
            this.ckChoice3.Properties.Caption = "checkEdit3";
            this.ckChoice3.Size = new System.Drawing.Size(17, 19);
            this.ckChoice3.TabIndex = 43;
            // 
            // ckChoice2
            // 
            this.ckChoice2.Location = new System.Drawing.Point(19, 306);
            this.ckChoice2.Name = "ckChoice2";
            this.ckChoice2.Properties.Caption = "checkEdit2";
            this.ckChoice2.Size = new System.Drawing.Size(17, 19);
            this.ckChoice2.TabIndex = 42;
            // 
            // ckChoice1
            // 
            this.ckChoice1.Location = new System.Drawing.Point(19, 121);
            this.ckChoice1.Name = "ckChoice1";
            this.ckChoice1.Properties.Caption = "checkEdit1";
            this.ckChoice1.Size = new System.Drawing.Size(17, 19);
            this.ckChoice1.TabIndex = 41;
            // 
            // pictureEdit7
            // 
            this.pictureEdit7.Location = new System.Drawing.Point(259, 588);
            this.pictureEdit7.Name = "pictureEdit7";
            this.pictureEdit7.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit7.Size = new System.Drawing.Size(200, 174);
            this.pictureEdit7.TabIndex = 40;
            // 
            // pictureEdit8
            // 
            this.pictureEdit8.Location = new System.Drawing.Point(53, 588);
            this.pictureEdit8.Name = "pictureEdit8";
            this.pictureEdit8.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit8.Size = new System.Drawing.Size(200, 174);
            this.pictureEdit8.TabIndex = 39;
            // 
            // pictureEdit5
            // 
            this.pictureEdit5.Location = new System.Drawing.Point(259, 408);
            this.pictureEdit5.Name = "pictureEdit5";
            this.pictureEdit5.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit5.Size = new System.Drawing.Size(200, 174);
            this.pictureEdit5.TabIndex = 38;
            // 
            // pictureEdit6
            // 
            this.pictureEdit6.Location = new System.Drawing.Point(53, 408);
            this.pictureEdit6.Name = "pictureEdit6";
            this.pictureEdit6.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit6.Size = new System.Drawing.Size(200, 174);
            this.pictureEdit6.TabIndex = 37;
            // 
            // pictureEdit3
            // 
            this.pictureEdit3.Location = new System.Drawing.Point(259, 228);
            this.pictureEdit3.Name = "pictureEdit3";
            this.pictureEdit3.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit3.Size = new System.Drawing.Size(200, 174);
            this.pictureEdit3.TabIndex = 36;
            // 
            // pictureEdit4
            // 
            this.pictureEdit4.Location = new System.Drawing.Point(53, 228);
            this.pictureEdit4.Name = "pictureEdit4";
            this.pictureEdit4.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit4.Size = new System.Drawing.Size(200, 174);
            this.pictureEdit4.TabIndex = 35;
            // 
            // pictureEdit2
            // 
            this.pictureEdit2.Location = new System.Drawing.Point(259, 43);
            this.pictureEdit2.Name = "pictureEdit2";
            this.pictureEdit2.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit2.Size = new System.Drawing.Size(200, 174);
            this.pictureEdit2.TabIndex = 34;
            // 
            // pictureEdit1
            // 
            this.pictureEdit1.Location = new System.Drawing.Point(53, 43);
            this.pictureEdit1.Name = "pictureEdit1";
            this.pictureEdit1.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit1.Size = new System.Drawing.Size(200, 174);
            this.pictureEdit1.TabIndex = 33;
            // 
            // frmRM01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainerControl1);
            this.Name = "frmRM01";
            this.Size = new System.Drawing.Size(1442, 852);
            this.Load += new System.EventHandler(this.frmRM01_Load);
            this.Controls.SetChildIndex(this.splitContainerControl1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBest_Pic1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShooting_Date1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPic_Url3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtE_DATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtE_DATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtS_DATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtS_DATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckChoice4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckChoice3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckChoice2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckChoice1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit7.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit8.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private DevExpress.XtraEditors.DateEdit dtE_DATE;
        private DevExpress.XtraEditors.DateEdit dtS_DATE;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.SimpleButton simpleButton9;
        private DevExpress.XtraEditors.SimpleButton simpleButton10;
        private DevExpress.XtraEditors.SimpleButton simpleButton7;
        private DevExpress.XtraEditors.SimpleButton simpleButton8;
        private DevExpress.XtraEditors.SimpleButton simpleButton5;
        private DevExpress.XtraEditors.SimpleButton simpleButton6;
        private DevExpress.XtraEditors.SimpleButton simpleButton3;
        private DevExpress.XtraEditors.SimpleButton simpleButton4;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.PictureEdit picBest_Pic5;
        private DevExpress.XtraEditors.TextEdit txtShooting_Date5;
        private System.Windows.Forms.Label label7;
        private DevExpress.XtraEditors.PictureEdit picBest_Pic4;
        private DevExpress.XtraEditors.TextEdit txtShooting_Date4;
        private System.Windows.Forms.Label label6;
        private DevExpress.XtraEditors.PictureEdit picBest_Pic3;
        private DevExpress.XtraEditors.TextEdit txtShooting_Date3;
        private System.Windows.Forms.Label label5;
        private DevExpress.XtraEditors.PictureEdit picBest_Pic2;
        private DevExpress.XtraEditors.TextEdit txtShooting_Date2;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraEditors.PictureEdit picBest_Pic1;
        private DevExpress.XtraEditors.TextEdit txtShooting_Date1;
        private System.Windows.Forms.Label label3;
        private DevExpress.XtraEditors.SplitterControl splitterControl1;
        private DevExpress.XtraGrid.GridControl efwGridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.TextEdit txtPic_Url1;
        private DevExpress.XtraEditors.TextEdit txtPic_Url2;
        private DevExpress.XtraEditors.TextEdit txtPic_Url4;
        private DevExpress.XtraEditors.TextEdit txtPic_Url5;
        private DevExpress.XtraEditors.TextEdit txtPic_Url3;
        private DevExpress.XtraEditors.CheckEdit ckChoice4;
        private DevExpress.XtraEditors.CheckEdit ckChoice3;
        private DevExpress.XtraEditors.CheckEdit ckChoice2;
        private DevExpress.XtraEditors.CheckEdit ckChoice1;
        private DevExpress.XtraEditors.PictureEdit pictureEdit7;
        private DevExpress.XtraEditors.PictureEdit pictureEdit8;
        private DevExpress.XtraEditors.PictureEdit pictureEdit5;
        private DevExpress.XtraEditors.PictureEdit pictureEdit6;
        private DevExpress.XtraEditors.PictureEdit pictureEdit3;
        private DevExpress.XtraEditors.PictureEdit pictureEdit4;
        private DevExpress.XtraEditors.PictureEdit pictureEdit2;
        private DevExpress.XtraEditors.PictureEdit pictureEdit1;
    }
}