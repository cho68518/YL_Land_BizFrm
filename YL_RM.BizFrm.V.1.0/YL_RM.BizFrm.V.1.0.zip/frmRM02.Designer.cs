﻿namespace YL_RM.BizFrm
{
    partial class frmRM02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRM02));
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo1 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo2 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo3 = new Easy.Framework.WinForm.Control.ServiceInfo();
            SpiceLogic.HtmlEditorControl.Domain.DesignTime.DictionaryFileInfo dictionaryFileInfo1 = new SpiceLogic.HtmlEditorControl.Domain.DesignTime.DictionaryFileInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo4 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo5 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ServiceInfo serviceInfo6 = new Easy.Framework.WinForm.Control.ServiceInfo();
            Easy.Framework.WinForm.Control.ChildHierarchy childHierarchy1 = new Easy.Framework.WinForm.Control.ChildHierarchy();
            Easy.Framework.WinForm.Control.Hierarchy hierarchy1 = new Easy.Framework.WinForm.Control.Hierarchy();
            this.efwXtraTabControl1 = new Easy.Framework.WinForm.Control.efwXtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.efwGroupControl2 = new Easy.Framework.WinForm.Control.efwGroupControl();
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.chk_is_use = new Easy.Framework.WinForm.Control.efwCheckEdit();
            this.btn_new1 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.btn_save1 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.txt_idx = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_remark = new Easy.Framework.WinForm.Control.efwMemoEdit();
            this.chk_is_comment = new Easy.Framework.WinForm.Control.efwCheckEdit();
            this.chk_is_file = new Easy.Framework.WinForm.Control.efwCheckEdit();
            this.chk_is_notice = new Easy.Framework.WinForm.Control.efwCheckEdit();
            this.txt_board_name = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_board_cd = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.Root = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem6 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.panel5 = new System.Windows.Forms.Panel();
            this.splitterControl2 = new DevExpress.XtraEditors.SplitterControl();
            this.efwGroupControl1 = new Easy.Framework.WinForm.Control.efwGroupControl();
            this.efwGridControl1 = new Easy.Framework.WinForm.Control.efwGridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemMemoExEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_sch1 = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.btnSch1 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwLabel3 = new Easy.Framework.WinForm.Control.efwLabel();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.efwGroupControl4 = new Easy.Framework.WinForm.Control.efwGroupControl();
            this.dataLayoutControl1 = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.txt_content = new SpiceLogic.WinHTMLEditor.WinForm.WinFormHtmlEditor();
            this.txt_board_name2 = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_board_cd2 = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.btn_del2 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.btn_save2 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.btn_new2 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem8 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem9 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem10 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterControl1 = new DevExpress.XtraEditors.SplitterControl();
            this.efwGroupControl3 = new Easy.Framework.WinForm.Control.efwGroupControl();
            this.efwGridControl2 = new Easy.Framework.WinForm.Control.efwGridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemMemoExEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.repositoryItemMemoEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txt_sch2 = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.btnSch2 = new Easy.Framework.WinForm.Control.efwSimpleButton();
            this.efwLabel2 = new Easy.Framework.WinForm.Control.efwLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cmbBoard = new Easy.Framework.WinForm.Control.efwLookUpEdit();
            this.efwLabel1 = new Easy.Framework.WinForm.Control.efwLabel();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.txt_idx2 = new Easy.Framework.WinForm.Control.efwTextEdit();
            this.txt_idx2222 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.efwXtraTabControl1)).BeginInit();
            this.efwXtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl2)).BeginInit();
            this.efwGroupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chk_is_use.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_idx.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_remark.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chk_is_comment.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chk_is_file.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chk_is_notice.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_board_name.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_board_cd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl1)).BeginInit();
            this.efwGroupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_sch1.Properties)).BeginInit();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl4)).BeginInit();
            this.efwGroupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).BeginInit();
            this.dataLayoutControl1.SuspendLayout();
            this.txt_content.Toolbar1.SuspendLayout();
            this.txt_content.Toolbar2.SuspendLayout();
            this.txt_content.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_board_name2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_board_cd2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl3)).BeginInit();
            this.efwGroupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_sch2.Properties)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbBoard.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_idx2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_idx2222)).BeginInit();
            this.SuspendLayout();
            // 
            // efwXtraTabControl1
            // 
            this.efwXtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.efwXtraTabControl1.IsMultiLang = false;
            this.efwXtraTabControl1.Location = new System.Drawing.Point(3, 35);
            this.efwXtraTabControl1.Name = "efwXtraTabControl1";
            this.efwXtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.efwXtraTabControl1.Size = new System.Drawing.Size(1262, 808);
            this.efwXtraTabControl1.TabIndex = 9;
            this.efwXtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2});
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.efwGroupControl2);
            this.xtraTabPage1.Controls.Add(this.splitterControl2);
            this.xtraTabPage1.Controls.Add(this.efwGroupControl1);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Padding = new System.Windows.Forms.Padding(5);
            this.xtraTabPage1.Size = new System.Drawing.Size(1256, 779);
            this.xtraTabPage1.Text = "게시판관리";
            // 
            // efwGroupControl2
            // 
            this.efwGroupControl2.CaptionImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwGroupControl2.CaptionImageOptions.Image")));
            this.efwGroupControl2.Controls.Add(this.layoutControl1);
            this.efwGroupControl2.Controls.Add(this.panel5);
            this.efwGroupControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.efwGroupControl2.IsMultiLang = false;
            this.efwGroupControl2.Location = new System.Drawing.Point(5, 359);
            this.efwGroupControl2.Name = "efwGroupControl2";
            this.efwGroupControl2.Size = new System.Drawing.Size(1246, 415);
            this.efwGroupControl2.TabIndex = 35;
            this.efwGroupControl2.Text = "게시판 등록";
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.chk_is_use);
            this.layoutControl1.Controls.Add(this.btn_new1);
            this.layoutControl1.Controls.Add(this.btn_save1);
            this.layoutControl1.Controls.Add(this.txt_idx);
            this.layoutControl1.Controls.Add(this.txt_remark);
            this.layoutControl1.Controls.Add(this.chk_is_comment);
            this.layoutControl1.Controls.Add(this.chk_is_file);
            this.layoutControl1.Controls.Add(this.chk_is_notice);
            this.layoutControl1.Controls.Add(this.txt_board_name);
            this.layoutControl1.Controls.Add(this.txt_board_cd);
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(2, 56);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.Root;
            this.layoutControl1.Size = new System.Drawing.Size(1242, 357);
            this.layoutControl1.TabIndex = 0;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // chk_is_use
            // 
            this.chk_is_use.Location = new System.Drawing.Point(293, 38);
            this.chk_is_use.Name = "chk_is_use";
            this.chk_is_use.Properties.Caption = "사용여부";
            this.chk_is_use.Size = new System.Drawing.Size(62, 19);
            this.chk_is_use.StyleController = this.layoutControl1;
            this.chk_is_use.TabIndex = 14;
            // 
            // btn_new1
            // 
            this.btn_new1.ButtonType = Easy.Framework.Util.BtnType.NewMode;
            this.btn_new1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_new1.ImageOptions.Image")));
            this.btn_new1.IsMultiLang = false;
            this.btn_new1.Location = new System.Drawing.Point(546, 12);
            this.btn_new1.Name = "btn_new1";
            this.btn_new1.Size = new System.Drawing.Size(86, 22);
            this.btn_new1.StyleController = this.layoutControl1;
            this.btn_new1.TabIndex = 13;
            this.btn_new1.Text = "신규";
            this.btn_new1.Click += new System.EventHandler(this.btn_new1_Click);
            // 
            // btn_save1
            // 
            this.btn_save1.ButtonType = Easy.Framework.Util.BtnType.Save;
            this.btn_save1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_save1.ImageOptions.Image")));
            this.btn_save1.IsMultiLang = false;
            this.btn_save1.Location = new System.Drawing.Point(636, 12);
            this.btn_save1.Name = "btn_save1";
            this.btn_save1.Size = new System.Drawing.Size(86, 22);
            this.btn_save1.StyleController = this.layoutControl1;
            this.btn_save1.TabIndex = 12;
            this.btn_save1.Text = "저장";
            this.btn_save1.Click += new System.EventHandler(this.btn_save1_Click);
            // 
            // txt_idx
            // 
            this.txt_idx.EditValue2 = null;
            this.txt_idx.EraserGroup = "ER1";
            this.txt_idx.Location = new System.Drawing.Point(192, 38);
            this.txt_idx.Name = "txt_idx";
            this.txt_idx.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_idx.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_idx.Properties.ReadOnly = true;
            this.txt_idx.RequireMessage = null;
            this.txt_idx.Size = new System.Drawing.Size(97, 20);
            this.txt_idx.StyleController = this.layoutControl1;
            this.txt_idx.TabIndex = 11;
            this.txt_idx.Visible = false;
            // 
            // txt_remark
            // 
            this.txt_remark.ByteLength = 255;
            this.txt_remark.EraserGroup = "ER1";
            this.txt_remark.Location = new System.Drawing.Point(117, 155);
            this.txt_remark.Name = "txt_remark";
            this.txt_remark.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_remark.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_remark.Size = new System.Drawing.Size(605, 190);
            this.txt_remark.StyleController = this.layoutControl1;
            this.txt_remark.TabIndex = 10;
            // 
            // chk_is_comment
            // 
            this.chk_is_comment.Location = new System.Drawing.Point(118, 132);
            this.chk_is_comment.Name = "chk_is_comment";
            this.chk_is_comment.Properties.Caption = "댓글사용";
            this.chk_is_comment.Size = new System.Drawing.Size(288, 19);
            this.chk_is_comment.StyleController = this.layoutControl1;
            this.chk_is_comment.TabIndex = 8;
            // 
            // chk_is_file
            // 
            this.chk_is_file.Location = new System.Drawing.Point(118, 109);
            this.chk_is_file.Name = "chk_is_file";
            this.chk_is_file.Properties.Caption = "파일사용";
            this.chk_is_file.Size = new System.Drawing.Size(288, 19);
            this.chk_is_file.StyleController = this.layoutControl1;
            this.chk_is_file.TabIndex = 7;
            // 
            // chk_is_notice
            // 
            this.chk_is_notice.Location = new System.Drawing.Point(118, 86);
            this.chk_is_notice.Name = "chk_is_notice";
            this.chk_is_notice.Properties.Caption = "공지여부";
            this.chk_is_notice.Size = new System.Drawing.Size(288, 19);
            this.chk_is_notice.StyleController = this.layoutControl1;
            this.chk_is_notice.TabIndex = 6;
            // 
            // txt_board_name
            // 
            this.txt_board_name.ByteLength = 255;
            this.txt_board_name.EditValue2 = null;
            this.txt_board_name.EraserGroup = "ER1";
            this.txt_board_name.IsRequire = true;
            this.txt_board_name.Location = new System.Drawing.Point(117, 62);
            this.txt_board_name.Name = "txt_board_name";
            this.txt_board_name.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(242)))), ((int)(((byte)(226)))));
            this.txt_board_name.Properties.Appearance.Options.UseBackColor = true;
            this.txt_board_name.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_board_name.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_board_name.RequireGroup = "R1";
            this.txt_board_name.RequireMessage = "게시판명을 입력하세요!";
            this.txt_board_name.Size = new System.Drawing.Size(605, 20);
            this.txt_board_name.StyleController = this.layoutControl1;
            this.txt_board_name.TabIndex = 5;
            // 
            // txt_board_cd
            // 
            this.txt_board_cd.ByteLength = 2;
            this.txt_board_cd.EditValue2 = null;
            this.txt_board_cd.EraserGroup = "ER1";
            this.txt_board_cd.IsRequire = true;
            this.txt_board_cd.Location = new System.Drawing.Point(117, 38);
            this.txt_board_cd.Name = "txt_board_cd";
            this.txt_board_cd.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(242)))), ((int)(((byte)(226)))));
            this.txt_board_cd.Properties.Appearance.Options.UseBackColor = true;
            this.txt_board_cd.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_board_cd.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_board_cd.RequireGroup = "R1";
            this.txt_board_cd.RequireMessage = "게시판코드를 입력하세요!";
            this.txt_board_cd.Size = new System.Drawing.Size(71, 20);
            this.txt_board_cd.StyleController = this.layoutControl1;
            this.txt_board_cd.TabIndex = 4;
            // 
            // Root
            // 
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem3,
            this.emptySpaceItem2,
            this.emptySpaceItem1,
            this.layoutControlItem7,
            this.emptySpaceItem4,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.emptySpaceItem5,
            this.layoutControlItem6,
            this.layoutControlItem9,
            this.layoutControlItem10,
            this.emptySpaceItem6,
            this.layoutControlItem11});
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(1242, 357);
            this.Root.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.txt_board_cd;
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(180, 24);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(180, 24);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(180, 24);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.Text = "게시판코드";
            this.layoutControlItem1.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem1.TextSize = new System.Drawing.Size(100, 20);
            this.layoutControlItem1.TextToControlDistance = 5;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.txt_board_name;
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(714, 24);
            this.layoutControlItem2.Text = "게시판명";
            this.layoutControlItem2.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(100, 20);
            this.layoutControlItem2.TextToControlDistance = 5;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.chk_is_notice;
            this.layoutControlItem3.Location = new System.Drawing.Point(106, 74);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(292, 23);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(292, 23);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(292, 23);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 74);
            this.emptySpaceItem2.MaxSize = new System.Drawing.Size(106, 0);
            this.emptySpaceItem2.MinSize = new System.Drawing.Size(106, 24);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(106, 69);
            this.emptySpaceItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem2.Text = " ";
            this.emptySpaceItem2.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(100, 20);
            this.emptySpaceItem2.TextVisible = true;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.Location = new System.Drawing.Point(714, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(508, 337);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.txt_remark;
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 143);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(714, 194);
            this.layoutControlItem7.Text = "비고";
            this.layoutControlItem7.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem7.TextSize = new System.Drawing.Size(100, 20);
            this.layoutControlItem7.TextToControlDistance = 5;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.Location = new System.Drawing.Point(398, 74);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(316, 69);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.chk_is_file;
            this.layoutControlItem4.Location = new System.Drawing.Point(106, 97);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(292, 23);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.chk_is_comment;
            this.layoutControlItem5.Location = new System.Drawing.Point(106, 120);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(292, 23);
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.Location = new System.Drawing.Point(347, 26);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(367, 24);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.txt_idx;
            this.layoutControlItem6.Location = new System.Drawing.Point(180, 26);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(101, 24);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            this.layoutControlItem6.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.btn_save1;
            this.layoutControlItem9.Location = new System.Drawing.Point(624, 0);
            this.layoutControlItem9.MaxSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(90, 26);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.btn_new1;
            this.layoutControlItem10.Location = new System.Drawing.Point(534, 0);
            this.layoutControlItem10.MaxSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem10.MinSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(90, 26);
            this.layoutControlItem10.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextVisible = false;
            // 
            // emptySpaceItem6
            // 
            this.emptySpaceItem6.AllowHotTrack = false;
            this.emptySpaceItem6.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem6.Name = "emptySpaceItem6";
            this.emptySpaceItem6.Size = new System.Drawing.Size(534, 26);
            this.emptySpaceItem6.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.chk_is_use;
            this.layoutControlItem11.Location = new System.Drawing.Point(281, 26);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(66, 24);
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextVisible = false;
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(2, 23);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1242, 33);
            this.panel5.TabIndex = 8;
            this.panel5.Visible = false;
            // 
            // splitterControl2
            // 
            this.splitterControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitterControl2.Location = new System.Drawing.Point(5, 354);
            this.splitterControl2.Name = "splitterControl2";
            this.splitterControl2.Size = new System.Drawing.Size(1246, 5);
            this.splitterControl2.TabIndex = 34;
            this.splitterControl2.TabStop = false;
            // 
            // efwGroupControl1
            // 
            this.efwGroupControl1.CaptionImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwGroupControl1.CaptionImageOptions.Image")));
            this.efwGroupControl1.Controls.Add(this.efwGridControl1);
            this.efwGroupControl1.Controls.Add(this.panel2);
            this.efwGroupControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwGroupControl1.IsMultiLang = false;
            this.efwGroupControl1.Location = new System.Drawing.Point(5, 5);
            this.efwGroupControl1.Name = "efwGroupControl1";
            this.efwGroupControl1.Size = new System.Drawing.Size(1246, 349);
            this.efwGroupControl1.TabIndex = 0;
            this.efwGroupControl1.Text = "게시판 목록";
            // 
            // efwGridControl1
            // 
            this.efwGridControl1.BindSet = null;
            this.efwGridControl1.DBName = "";
            serviceInfo1.InstanceName = "";
            serviceInfo1.IsUserIDAdd = true;
            serviceInfo1.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo1.ParamsInfo")));
            serviceInfo1.ProcName = "";
            serviceInfo1.UserParams = null;
            this.efwGridControl1.DeleteServiceInfo = serviceInfo1;
            this.efwGridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.efwGridControl1.EraserGroup = "CLR1";
            serviceInfo2.InstanceName = "";
            serviceInfo2.IsUserIDAdd = true;
            serviceInfo2.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo2.ParamsInfo")));
            serviceInfo2.ProcName = "";
            serviceInfo2.UserParams = null;
            this.efwGridControl1.InsertServiceInfo = serviceInfo2;
            this.efwGridControl1.IsAddExcelBtn = true;
            this.efwGridControl1.isAddPrintBtn = true;
            this.efwGridControl1.IsEditable = false;
            this.efwGridControl1.IsMultiLang = false;
            this.efwGridControl1.Location = new System.Drawing.Point(2, 62);
            this.efwGridControl1.MainView = this.gridView1;
            this.efwGridControl1.Name = "efwGridControl1";
            this.efwGridControl1.NowRowHandle = 0;
            this.efwGridControl1.PKColumns = ((System.Collections.ArrayList)(resources.GetObject("efwGridControl1.PKColumns")));
            this.efwGridControl1.PrevRowHandle = -2147483648;
            this.efwGridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEdit1,
            this.repositoryItemMemoExEdit1,
            this.repositoryItemMemoEdit1,
            this.repositoryItemMemoExEdit3});
            this.efwGridControl1.Size = new System.Drawing.Size(1242, 285);
            this.efwGridControl1.TabIndex = 8;
            this.efwGridControl1.TableName = "";
            serviceInfo3.InstanceName = "";
            serviceInfo3.IsUserIDAdd = true;
            serviceInfo3.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo3.ParamsInfo")));
            serviceInfo3.ProcName = "";
            serviceInfo3.UserParams = null;
            this.efwGridControl1.UpdateServiceInfo = serviceInfo3;
            this.efwGridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn8,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7});
            this.gridView1.GridControl = this.efwGridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "idx";
            this.gridColumn1.FieldName = "idx";
            this.gridColumn1.Name = "gridColumn1";
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "게시판코드";
            this.gridColumn2.FieldName = "board_cd";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 0;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "게시판명";
            this.gridColumn3.FieldName = "board_name";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 1;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "사용여부";
            this.gridColumn8.FieldName = "is_use";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 2;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "공지여부";
            this.gridColumn4.FieldName = "is_notice";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "파일사용";
            this.gridColumn5.FieldName = "is_file";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "댓글사용";
            this.gridColumn6.FieldName = "is_comment";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "비고";
            this.gridColumn7.ColumnEdit = this.repositoryItemMemoExEdit3;
            this.gridColumn7.FieldName = "remark";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 6;
            // 
            // repositoryItemMemoExEdit3
            // 
            this.repositoryItemMemoExEdit3.AutoHeight = false;
            this.repositoryItemMemoExEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit3.Name = "repositoryItemMemoExEdit3";
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            // 
            // repositoryItemMemoExEdit1
            // 
            this.repositoryItemMemoExEdit1.AutoHeight = false;
            this.repositoryItemMemoExEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit1.Name = "repositoryItemMemoExEdit1";
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txt_sch1);
            this.panel2.Controls.Add(this.btnSch1);
            this.panel2.Controls.Add(this.efwLabel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(2, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1242, 39);
            this.panel2.TabIndex = 7;
            // 
            // txt_sch1
            // 
            this.txt_sch1.EditValue2 = null;
            this.txt_sch1.Location = new System.Drawing.Point(104, 9);
            this.txt_sch1.Name = "txt_sch1";
            this.txt_sch1.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_sch1.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_sch1.RequireMessage = null;
            this.txt_sch1.Size = new System.Drawing.Size(268, 20);
            this.txt_sch1.TabIndex = 7;
            // 
            // btnSch1
            // 
            this.btnSch1.ButtonType = Easy.Framework.Util.BtnType.Search;
            this.btnSch1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSch1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSch1.ImageOptions.Image")));
            this.btnSch1.IsMultiLang = false;
            this.btnSch1.Location = new System.Drawing.Point(377, 7);
            this.btnSch1.Name = "btnSch1";
            this.btnSch1.Size = new System.Drawing.Size(75, 23);
            this.btnSch1.TabIndex = 6;
            this.btnSch1.Text = "조회";
            this.btnSch1.Click += new System.EventHandler(this.btnSch1_Click);
            // 
            // efwLabel3
            // 
            this.efwLabel3.EraserGroup = null;
            this.efwLabel3.IsMultiLang = false;
            this.efwLabel3.Location = new System.Drawing.Point(40, 12);
            this.efwLabel3.Name = "efwLabel3";
            this.efwLabel3.Size = new System.Drawing.Size(30, 14);
            this.efwLabel3.TabIndex = 3;
            this.efwLabel3.Text = "검색명";
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.efwGroupControl4);
            this.xtraTabPage2.Controls.Add(this.splitterControl1);
            this.xtraTabPage2.Controls.Add(this.efwGroupControl3);
            this.xtraTabPage2.Controls.Add(this.panel3);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Padding = new System.Windows.Forms.Padding(5);
            this.xtraTabPage2.Size = new System.Drawing.Size(1256, 779);
            this.xtraTabPage2.Text = "글 등록";
            // 
            // efwGroupControl4
            // 
            this.efwGroupControl4.CaptionImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwGroupControl4.CaptionImageOptions.Image")));
            this.efwGroupControl4.Controls.Add(this.dataLayoutControl1);
            this.efwGroupControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.efwGroupControl4.IsMultiLang = false;
            this.efwGroupControl4.Location = new System.Drawing.Point(5, 403);
            this.efwGroupControl4.Name = "efwGroupControl4";
            this.efwGroupControl4.Size = new System.Drawing.Size(1246, 371);
            this.efwGroupControl4.TabIndex = 36;
            this.efwGroupControl4.Text = "글 등록";
            // 
            // dataLayoutControl1
            // 
            this.dataLayoutControl1.Controls.Add(this.txt_idx2);
            this.dataLayoutControl1.Controls.Add(this.txt_content);
            this.dataLayoutControl1.Controls.Add(this.txt_board_name2);
            this.dataLayoutControl1.Controls.Add(this.txt_board_cd2);
            this.dataLayoutControl1.Controls.Add(this.btn_del2);
            this.dataLayoutControl1.Controls.Add(this.btn_save2);
            this.dataLayoutControl1.Controls.Add(this.btn_new2);
            this.dataLayoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataLayoutControl1.Location = new System.Drawing.Point(2, 23);
            this.dataLayoutControl1.Name = "dataLayoutControl1";
            this.dataLayoutControl1.Root = this.layoutControlGroup2;
            this.dataLayoutControl1.Size = new System.Drawing.Size(1242, 346);
            this.dataLayoutControl1.TabIndex = 1;
            this.dataLayoutControl1.Text = "dataLayoutControl1";
            // 
            // txt_content
            // 
            this.txt_content.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.txt_content.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.txt_content.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.txt_content.BodyStyle = "FONT-SIZE: 10pt; FONT-FAMILY: 굴림체; COLOR: black";
            // 
            // txt_content.BtnAlignCenter
            // 
            this.txt_content.BtnAlignCenter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnAlignCenter.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnAlignCenter.Image")));
            this.txt_content.BtnAlignCenter.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnAlignCenter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnAlignCenter.Name = "_factoryBtnAlignCenter";
            this.txt_content.BtnAlignCenter.Size = new System.Drawing.Size(26, 26);
            this.txt_content.BtnAlignCenter.Text = "Align Centre";
            // 
            // txt_content.BtnAlignLeft
            // 
            this.txt_content.BtnAlignLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnAlignLeft.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnAlignLeft.Image")));
            this.txt_content.BtnAlignLeft.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnAlignLeft.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnAlignLeft.Name = "_factoryBtnAlignLeft";
            this.txt_content.BtnAlignLeft.Size = new System.Drawing.Size(26, 26);
            this.txt_content.BtnAlignLeft.Text = "Align Left";
            // 
            // txt_content.BtnAlignRight
            // 
            this.txt_content.BtnAlignRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnAlignRight.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnAlignRight.Image")));
            this.txt_content.BtnAlignRight.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnAlignRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnAlignRight.Name = "_factoryBtnAlignRight";
            this.txt_content.BtnAlignRight.Size = new System.Drawing.Size(26, 26);
            this.txt_content.BtnAlignRight.Text = "Align Right";
            // 
            // txt_content.BtnBodyStyle
            // 
            this.txt_content.BtnBodyStyle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnBodyStyle.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnBodyStyle.Image")));
            this.txt_content.BtnBodyStyle.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnBodyStyle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnBodyStyle.Name = "_factoryBtnBodyStyle";
            this.txt_content.BtnBodyStyle.Size = new System.Drawing.Size(27, 26);
            this.txt_content.BtnBodyStyle.Text = "Document Style ";
            this.txt_content.BtnBodyStyle.Visible = false;
            // 
            // txt_content.BtnBold
            // 
            this.txt_content.BtnBold.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnBold.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnBold.Image")));
            this.txt_content.BtnBold.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnBold.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnBold.Name = "_factoryBtnBold";
            this.txt_content.BtnBold.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnBold.Text = "Bold";
            // 
            // txt_content.BtnCopy
            // 
            this.txt_content.BtnCopy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnCopy.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnCopy.Image")));
            this.txt_content.BtnCopy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnCopy.Name = "_factoryBtnCopy";
            this.txt_content.BtnCopy.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnCopy.Text = "Copy";
            // 
            // txt_content.BtnCut
            // 
            this.txt_content.BtnCut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnCut.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnCut.Image")));
            this.txt_content.BtnCut.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnCut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnCut.Name = "_factoryBtnCut";
            this.txt_content.BtnCut.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnCut.Text = "Cut";
            // 
            // txt_content.BtnFontColor
            // 
            this.txt_content.BtnFontColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnFontColor.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnFontColor.Image")));
            this.txt_content.BtnFontColor.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnFontColor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnFontColor.Name = "_factoryBtnFontColor";
            this.txt_content.BtnFontColor.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnFontColor.Text = "Apply Font Color";
            // 
            // txt_content.BtnFormatRedo
            // 
            this.txt_content.BtnFormatRedo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnFormatRedo.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnFormatRedo.Image")));
            this.txt_content.BtnFormatRedo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnFormatRedo.Name = "_factoryBtnRedo";
            this.txt_content.BtnFormatRedo.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnFormatRedo.Text = "Redo";
            // 
            // txt_content.BtnFormatReset
            // 
            this.txt_content.BtnFormatReset.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnFormatReset.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnFormatReset.Image")));
            this.txt_content.BtnFormatReset.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnFormatReset.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnFormatReset.Name = "_factoryBtnFormatReset";
            this.txt_content.BtnFormatReset.Size = new System.Drawing.Size(34, 26);
            this.txt_content.BtnFormatReset.Text = "Remove Format";
            // 
            // txt_content.BtnFormatUndo
            // 
            this.txt_content.BtnFormatUndo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnFormatUndo.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnFormatUndo.Image")));
            this.txt_content.BtnFormatUndo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnFormatUndo.Name = "_factoryBtnUndo";
            this.txt_content.BtnFormatUndo.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnFormatUndo.Text = "Undo";
            // 
            // txt_content.BtnHighlightColor
            // 
            this.txt_content.BtnHighlightColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnHighlightColor.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnHighlightColor.Image")));
            this.txt_content.BtnHighlightColor.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnHighlightColor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnHighlightColor.Name = "_factoryBtnHighlightColor";
            this.txt_content.BtnHighlightColor.Size = new System.Drawing.Size(27, 26);
            this.txt_content.BtnHighlightColor.Text = "Apply Highlight Color";
            // 
            // txt_content.BtnHorizontalRule
            // 
            this.txt_content.BtnHorizontalRule.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnHorizontalRule.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnHorizontalRule.Image")));
            this.txt_content.BtnHorizontalRule.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnHorizontalRule.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnHorizontalRule.Name = "_factoryBtnHorizontalRule";
            this.txt_content.BtnHorizontalRule.Size = new System.Drawing.Size(24, 26);
            this.txt_content.BtnHorizontalRule.Text = "Insert Horizontal Rule";
            // 
            // txt_content.BtnHyperlink
            // 
            this.txt_content.BtnHyperlink.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnHyperlink.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnHyperlink.Image")));
            this.txt_content.BtnHyperlink.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnHyperlink.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnHyperlink.Name = "_factoryBtnHyperlink";
            this.txt_content.BtnHyperlink.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnHyperlink.Text = "Hyperlink";
            // 
            // txt_content.BtnImage
            // 
            this.txt_content.BtnImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnImage.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnImage.Image")));
            this.txt_content.BtnImage.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnImage.Name = "_factoryBtnImage";
            this.txt_content.BtnImage.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnImage.Text = "Image";
            this.txt_content.BtnImage.Visible = false;
            // 
            // txt_content.BtnIndent
            // 
            this.txt_content.BtnIndent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnIndent.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnIndent.Image")));
            this.txt_content.BtnIndent.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnIndent.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnIndent.Name = "_factoryBtnIndent";
            this.txt_content.BtnIndent.Size = new System.Drawing.Size(27, 26);
            this.txt_content.BtnIndent.Text = "Indent";
            // 
            // txt_content.BtnInsertYouTubeVideo
            // 
            this.txt_content.BtnInsertYouTubeVideo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnInsertYouTubeVideo.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnInsertYouTubeVideo.Image")));
            this.txt_content.BtnInsertYouTubeVideo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnInsertYouTubeVideo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnInsertYouTubeVideo.Name = "_factoryBtnInsertYouTubeVideo";
            this.txt_content.BtnInsertYouTubeVideo.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnInsertYouTubeVideo.Text = "Insert YouTube Video";
            this.txt_content.BtnInsertYouTubeVideo.Visible = false;
            // 
            // txt_content.BtnItalic
            // 
            this.txt_content.BtnItalic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnItalic.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnItalic.Image")));
            this.txt_content.BtnItalic.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnItalic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnItalic.Name = "_factoryBtnItalic";
            this.txt_content.BtnItalic.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnItalic.Text = "Italic";
            // 
            // txt_content.BtnNew
            // 
            this.txt_content.BtnNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnNew.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnNew.Image")));
            this.txt_content.BtnNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnNew.Name = "_factoryBtnNew";
            this.txt_content.BtnNew.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnNew.Text = "New";
            this.txt_content.BtnNew.Visible = false;
            // 
            // txt_content.BtnOpen
            // 
            this.txt_content.BtnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnOpen.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnOpen.Image")));
            this.txt_content.BtnOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnOpen.Name = "_factoryBtnOpen";
            this.txt_content.BtnOpen.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnOpen.Text = "Open";
            this.txt_content.BtnOpen.Visible = false;
            // 
            // txt_content.BtnOrderedList
            // 
            this.txt_content.BtnOrderedList.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnOrderedList.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnOrderedList.Image")));
            this.txt_content.BtnOrderedList.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnOrderedList.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnOrderedList.Name = "_factoryBtnOrderedList";
            this.txt_content.BtnOrderedList.Size = new System.Drawing.Size(24, 26);
            this.txt_content.BtnOrderedList.Text = "Numbered List";
            // 
            // txt_content.BtnOutdent
            // 
            this.txt_content.BtnOutdent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnOutdent.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnOutdent.Image")));
            this.txt_content.BtnOutdent.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnOutdent.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnOutdent.Name = "_factoryBtnOutdent";
            this.txt_content.BtnOutdent.Size = new System.Drawing.Size(27, 26);
            this.txt_content.BtnOutdent.Text = "Outdent";
            // 
            // txt_content.BtnPaste
            // 
            this.txt_content.BtnPaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnPaste.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnPaste.Image")));
            this.txt_content.BtnPaste.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnPaste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnPaste.Name = "_factoryBtnPaste";
            this.txt_content.BtnPaste.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnPaste.Text = "Paste";
            // 
            // txt_content.BtnPasteFromMSWord
            // 
            this.txt_content.BtnPasteFromMSWord.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnPasteFromMSWord.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnPasteFromMSWord.Image")));
            this.txt_content.BtnPasteFromMSWord.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnPasteFromMSWord.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnPasteFromMSWord.Name = "_factoryBtnPasteFromMSWord";
            this.txt_content.BtnPasteFromMSWord.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnPasteFromMSWord.Text = "Paste the Content that you Copied from MS Word";
            // 
            // txt_content.BtnPrint
            // 
            this.txt_content.BtnPrint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnPrint.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnPrint.Image")));
            this.txt_content.BtnPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnPrint.Name = "_factoryBtnPrint";
            this.txt_content.BtnPrint.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnPrint.Text = "Print";
            // 
            // txt_content.BtnSave
            // 
            this.txt_content.BtnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnSave.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnSave.Image")));
            this.txt_content.BtnSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnSave.Name = "_factoryBtnSave";
            this.txt_content.BtnSave.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnSave.Text = "Save";
            this.txt_content.BtnSave.Visible = false;
            // 
            // txt_content.BtnSearch
            // 
            this.txt_content.BtnSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnSearch.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnSearch.Image")));
            this.txt_content.BtnSearch.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnSearch.Name = "_factoryBtnSearch";
            this.txt_content.BtnSearch.Size = new System.Drawing.Size(24, 26);
            this.txt_content.BtnSearch.Text = "Search";
            // 
            // txt_content.BtnSpellCheck
            // 
            this.txt_content.BtnSpellCheck.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnSpellCheck.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnSpellCheck.Image")));
            this.txt_content.BtnSpellCheck.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnSpellCheck.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnSpellCheck.Name = "_factoryBtnSpellCheck";
            this.txt_content.BtnSpellCheck.Size = new System.Drawing.Size(26, 26);
            this.txt_content.BtnSpellCheck.Text = "Check Spelling";
            // 
            // txt_content.BtnStrikeThrough
            // 
            this.txt_content.BtnStrikeThrough.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnStrikeThrough.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnStrikeThrough.Image")));
            this.txt_content.BtnStrikeThrough.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnStrikeThrough.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnStrikeThrough.Name = "_factoryBtnStrikeThrough";
            this.txt_content.BtnStrikeThrough.Size = new System.Drawing.Size(24, 26);
            this.txt_content.BtnStrikeThrough.Text = "Strike Thru";
            this.txt_content.BtnStrikeThrough.Visible = false;
            // 
            // txt_content.BtnSubscript
            // 
            this.txt_content.BtnSubscript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnSubscript.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnSubscript.Image")));
            this.txt_content.BtnSubscript.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnSubscript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnSubscript.Name = "_factoryBtnSubscript";
            this.txt_content.BtnSubscript.Size = new System.Drawing.Size(27, 26);
            this.txt_content.BtnSubscript.Text = "Subscript";
            this.txt_content.BtnSubscript.Visible = false;
            // 
            // txt_content.BtnSuperScript
            // 
            this.txt_content.BtnSuperScript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnSuperScript.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnSuperScript.Image")));
            this.txt_content.BtnSuperScript.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnSuperScript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnSuperScript.Name = "_factoryBtnSuperScript";
            this.txt_content.BtnSuperScript.Size = new System.Drawing.Size(27, 26);
            this.txt_content.BtnSuperScript.Text = "Superscript";
            this.txt_content.BtnSuperScript.Visible = false;
            // 
            // txt_content.BtnSymbol
            // 
            this.txt_content.BtnSymbol.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnSymbol.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnSymbol.Image")));
            this.txt_content.BtnSymbol.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnSymbol.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnSymbol.Name = "_factoryBtnSymbol";
            this.txt_content.BtnSymbol.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnSymbol.Text = "Insert Symbols";
            this.txt_content.BtnSymbol.Visible = false;
            // 
            // txt_content.BtnTable
            // 
            this.txt_content.BtnTable.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnTable.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnTable.Image")));
            this.txt_content.BtnTable.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnTable.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnTable.Name = "_factoryBtnTable";
            this.txt_content.BtnTable.Size = new System.Drawing.Size(24, 26);
            this.txt_content.BtnTable.Text = "Table";
            this.txt_content.BtnTable.Visible = false;
            // 
            // txt_content.BtnUnderline
            // 
            this.txt_content.BtnUnderline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnUnderline.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnUnderline.Image")));
            this.txt_content.BtnUnderline.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnUnderline.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnUnderline.Name = "_factoryBtnUnderline";
            this.txt_content.BtnUnderline.Size = new System.Drawing.Size(23, 26);
            this.txt_content.BtnUnderline.Text = "Underline";
            // 
            // txt_content.BtnUnOrderedList
            // 
            this.txt_content.BtnUnOrderedList.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.txt_content.BtnUnOrderedList.Image = ((System.Drawing.Image)(resources.GetObject("txt_content.BtnUnOrderedList.Image")));
            this.txt_content.BtnUnOrderedList.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.txt_content.BtnUnOrderedList.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txt_content.BtnUnOrderedList.Name = "_factoryBtnUnOrderedList";
            this.txt_content.BtnUnOrderedList.Size = new System.Drawing.Size(24, 26);
            this.txt_content.BtnUnOrderedList.Text = "Bullet List";
            // 
            // txt_content.CmbFontName
            // 
            this.txt_content.CmbFontName.AddSystemFonts = true;
            this.txt_content.CmbFontName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_content.CmbFontName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_content.CmbFontName.MaxDropDownItems = 17;
            this.txt_content.CmbFontName.Name = "_factoryCmbFontName";
            this.txt_content.CmbFontName.Size = new System.Drawing.Size(145, 29);
            this.txt_content.CmbFontName.Text = "굴림체";
            // 
            // txt_content.CmbFontSize
            // 
            this.txt_content.CmbFontSize.Name = "_factoryCmbFontSize";
            this.txt_content.CmbFontSize.Size = new System.Drawing.Size(87, 29);
            this.txt_content.CmbFontSize.Text = "10pt";
            // 
            // txt_content.CmbTitleInsert
            // 
            this.txt_content.CmbTitleInsert.Name = "_factoryCmbTitleInsert";
            this.txt_content.CmbTitleInsert.Size = new System.Drawing.Size(116, 29);
            this.txt_content.CmbTitleInsert.Visible = false;
            this.txt_content.DefaultFontFamily = "굴림체";
            this.txt_content.DefaultFontSizeInPt = "10pt";
            this.txt_content.DocumentHtml = resources.GetString("txt_content.DocumentHtml");
            this.txt_content.EditorContextMenuStrip = null;
            this.txt_content.HeaderStyleContentElementID = "page_style";
            this.txt_content.HorizontalScroll = null;
            this.txt_content.Location = new System.Drawing.Point(107, 62);
            this.txt_content.Name = "txt_content";
            this.txt_content.Options.ConvertFileUrlsToLocalPaths = true;
            this.txt_content.Options.CustomDOCTYPE = null;
            this.txt_content.Options.FooterTagNavigatorFont = null;
            this.txt_content.Options.FooterTagNavigatorTextColor = System.Drawing.Color.Teal;
            this.txt_content.Options.FTPSettingsForRemoteResources.ConnectionMode = SpiceLogic.HtmlEditorControl.Domain.BOs.UserOptions.FTPSettings.ConnectionModes.Active;
            this.txt_content.Options.FTPSettingsForRemoteResources.Host = null;
            this.txt_content.Options.FTPSettingsForRemoteResources.Password = null;
            this.txt_content.Options.FTPSettingsForRemoteResources.Port = null;
            this.txt_content.Options.FTPSettingsForRemoteResources.RemoteFolderPath = null;
            this.txt_content.Options.FTPSettingsForRemoteResources.Timeout = 4000;
            this.txt_content.Options.FTPSettingsForRemoteResources.UrlOfTheRemoteFolderPath = null;
            this.txt_content.Options.FTPSettingsForRemoteResources.UserName = null;
            this.txt_content.Options.PasteImageFromClipboardBehavior = SpiceLogic.HtmlEditorControl.Domain.BOs.UserOptions.UserOption.ImageStorage.Base64;
            this.txt_content.Size = new System.Drawing.Size(698, 272);
            this.txt_content.SpellCheckOptions.CurlyUnderlineImageFilePath = null;
            dictionaryFileInfo1.AffixFilePath = null;
            dictionaryFileInfo1.DictionaryFilePath = null;
            dictionaryFileInfo1.EnableUserDictionary = true;
            dictionaryFileInfo1.UserDictionaryFilePath = null;
            this.txt_content.SpellCheckOptions.DictionaryFile = dictionaryFileInfo1;
            this.txt_content.SpellCheckOptions.NHunspellDllFolderPath = null;
            this.txt_content.SpellCheckOptions.WaitAlertMessage = "Searching next messpelled word..... (please wait)";
            this.txt_content.TabIndex = 19;
            // 
            // txt_content.TlstrpSeparator1
            // 
            this.txt_content.TlstrpSeparator1.Name = "_toolStripSeparator1";
            this.txt_content.TlstrpSeparator1.Size = new System.Drawing.Size(6, 29);
            // 
            // txt_content.TlstrpSeparator2
            // 
            this.txt_content.TlstrpSeparator2.Name = "_toolStripSeparator2";
            this.txt_content.TlstrpSeparator2.Size = new System.Drawing.Size(6, 29);
            // 
            // txt_content.TlstrpSeparator3
            // 
            this.txt_content.TlstrpSeparator3.Name = "_toolStripSeparator3";
            this.txt_content.TlstrpSeparator3.Size = new System.Drawing.Size(6, 29);
            // 
            // txt_content.TlstrpSeparator4
            // 
            this.txt_content.TlstrpSeparator4.Name = "_toolStripSeparator4";
            this.txt_content.TlstrpSeparator4.Size = new System.Drawing.Size(6, 29);
            // 
            // txt_content.TlstrpSeparator5
            // 
            this.txt_content.TlstrpSeparator5.Name = "_toolStripSeparator5";
            this.txt_content.TlstrpSeparator5.Size = new System.Drawing.Size(6, 29);
            // 
            // txt_content.TlstrpSeparator6
            // 
            this.txt_content.TlstrpSeparator6.Name = "_toolStripSeparator6";
            this.txt_content.TlstrpSeparator6.Size = new System.Drawing.Size(6, 29);
            // 
            // txt_content.TlstrpSeparator7
            // 
            this.txt_content.TlstrpSeparator7.Name = "_toolStripSeparator7";
            this.txt_content.TlstrpSeparator7.Size = new System.Drawing.Size(6, 29);
            // 
            // txt_content.TlstrpSeparator8
            // 
            this.txt_content.TlstrpSeparator8.Name = "_toolStripSeparator8";
            this.txt_content.TlstrpSeparator8.Size = new System.Drawing.Size(6, 29);
            // 
            // txt_content.TlstrpSeparator9
            // 
            this.txt_content.TlstrpSeparator9.Name = "_toolStripSeparator9";
            this.txt_content.TlstrpSeparator9.Size = new System.Drawing.Size(6, 29);
            this.txt_content.TlstrpSeparator9.Visible = false;
            // 
            // txt_content.WinFormHtmlEditor_Toolbar1
            // 
            this.txt_content.Toolbar1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.txt_content.BtnNew,
            this.txt_content.BtnOpen,
            this.txt_content.BtnSave,
            this.txt_content.TlstrpSeparator1,
            this.txt_content.CmbFontName,
            this.txt_content.CmbFontSize,
            this.txt_content.TlstrpSeparator2,
            this.txt_content.BtnCut,
            this.txt_content.BtnCopy,
            this.txt_content.BtnPaste,
            this.txt_content.BtnPasteFromMSWord,
            this.txt_content.TlstrpSeparator3,
            this.txt_content.BtnBold,
            this.txt_content.BtnItalic,
            this.txt_content.BtnUnderline,
            this.txt_content.TlstrpSeparator4,
            this.txt_content.BtnFormatReset,
            this.txt_content.BtnFormatUndo,
            this.txt_content.BtnFormatRedo,
            this.txt_content.BtnPrint,
            this.txt_content.BtnSpellCheck,
            this.txt_content.BtnSearch});
            this.txt_content.Toolbar1.Location = new System.Drawing.Point(0, 0);
            this.txt_content.Toolbar1.Name = "WinFormHtmlEditor_Toolbar1";
            this.txt_content.Toolbar1.Size = new System.Drawing.Size(698, 29);
            this.txt_content.Toolbar1.TabIndex = 0;
            // 
            // txt_content.WinFormHtmlEditor_Toolbar2
            // 
            this.txt_content.Toolbar2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.txt_content.CmbTitleInsert,
            this.txt_content.BtnHighlightColor,
            this.txt_content.BtnFontColor,
            this.txt_content.TlstrpSeparator5,
            this.txt_content.BtnHyperlink,
            this.txt_content.BtnImage,
            this.txt_content.BtnInsertYouTubeVideo,
            this.txt_content.BtnTable,
            this.txt_content.BtnSymbol,
            this.txt_content.BtnHorizontalRule,
            this.txt_content.TlstrpSeparator6,
            this.txt_content.BtnOrderedList,
            this.txt_content.BtnUnOrderedList,
            this.txt_content.TlstrpSeparator7,
            this.txt_content.BtnAlignLeft,
            this.txt_content.BtnAlignCenter,
            this.txt_content.BtnAlignRight,
            this.txt_content.TlstrpSeparator8,
            this.txt_content.BtnOutdent,
            this.txt_content.BtnIndent,
            this.txt_content.TlstrpSeparator9,
            this.txt_content.BtnStrikeThrough,
            this.txt_content.BtnSuperScript,
            this.txt_content.BtnSubscript,
            this.txt_content.BtnBodyStyle});
            this.txt_content.Toolbar2.Location = new System.Drawing.Point(0, 29);
            this.txt_content.Toolbar2.Name = "WinFormHtmlEditor_Toolbar2";
            this.txt_content.Toolbar2.Size = new System.Drawing.Size(698, 29);
            this.txt_content.Toolbar2.TabIndex = 0;
            this.txt_content.ToolbarContextMenuStrip = null;
            // 
            // txt_content.WinFormHtmlEditor_ToolbarFooter
            // 
            this.txt_content.ToolbarFooter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txt_content.ToolbarFooter.Location = new System.Drawing.Point(0, 247);
            this.txt_content.ToolbarFooter.Name = "WinFormHtmlEditor_ToolbarFooter";
            this.txt_content.ToolbarFooter.Size = new System.Drawing.Size(698, 25);
            this.txt_content.ToolbarFooter.TabIndex = 7;
            this.txt_content.VerticalScroll = null;
            this.txt_content.z__ignore = false;
            // 
            // txt_board_name2
            // 
            this.txt_board_name2.EditValue2 = null;
            this.txt_board_name2.Location = new System.Drawing.Point(192, 38);
            this.txt_board_name2.Name = "txt_board_name2";
            this.txt_board_name2.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_board_name2.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_board_name2.Properties.ReadOnly = true;
            this.txt_board_name2.RequireMessage = null;
            this.txt_board_name2.Size = new System.Drawing.Size(343, 20);
            this.txt_board_name2.StyleController = this.dataLayoutControl1;
            this.txt_board_name2.TabIndex = 18;
            // 
            // txt_board_cd2
            // 
            this.txt_board_cd2.EditValue2 = null;
            this.txt_board_cd2.IsRequire = true;
            this.txt_board_cd2.Location = new System.Drawing.Point(107, 38);
            this.txt_board_cd2.Name = "txt_board_cd2";
            this.txt_board_cd2.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(242)))), ((int)(((byte)(226)))));
            this.txt_board_cd2.Properties.Appearance.Options.UseBackColor = true;
            this.txt_board_cd2.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_board_cd2.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_board_cd2.Properties.ReadOnly = true;
            this.txt_board_cd2.RequireGroup = "R2";
            this.txt_board_cd2.RequireMessage = "게시판코드를 선택하세요!";
            this.txt_board_cd2.Size = new System.Drawing.Size(81, 20);
            this.txt_board_cd2.StyleController = this.dataLayoutControl1;
            this.txt_board_cd2.TabIndex = 17;
            // 
            // btn_del2
            // 
            this.btn_del2.ButtonType = Easy.Framework.Util.BtnType.Delete;
            this.btn_del2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_del2.ImageOptions.Image")));
            this.btn_del2.IsMultiLang = false;
            this.btn_del2.Location = new System.Drawing.Point(719, 12);
            this.btn_del2.Name = "btn_del2";
            this.btn_del2.Size = new System.Drawing.Size(86, 22);
            this.btn_del2.StyleController = this.dataLayoutControl1;
            this.btn_del2.TabIndex = 16;
            this.btn_del2.Text = "삭제";
            this.btn_del2.Click += new System.EventHandler(this.btn_del2_Click);
            // 
            // btn_save2
            // 
            this.btn_save2.ButtonType = Easy.Framework.Util.BtnType.Save;
            this.btn_save2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_save2.ImageOptions.Image")));
            this.btn_save2.IsMultiLang = false;
            this.btn_save2.Location = new System.Drawing.Point(629, 12);
            this.btn_save2.Name = "btn_save2";
            this.btn_save2.Size = new System.Drawing.Size(86, 22);
            this.btn_save2.StyleController = this.dataLayoutControl1;
            this.btn_save2.TabIndex = 15;
            this.btn_save2.Text = "저장";
            this.btn_save2.Click += new System.EventHandler(this.btn_save2_Click);
            // 
            // btn_new2
            // 
            this.btn_new2.ButtonType = Easy.Framework.Util.BtnType.NewMode;
            this.btn_new2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_new2.ImageOptions.Image")));
            this.btn_new2.IsMultiLang = false;
            this.btn_new2.Location = new System.Drawing.Point(539, 12);
            this.btn_new2.Name = "btn_new2";
            this.btn_new2.Size = new System.Drawing.Size(86, 22);
            this.btn_new2.StyleController = this.dataLayoutControl1;
            this.btn_new2.TabIndex = 14;
            this.btn_new2.Text = "신규";
            this.btn_new2.Click += new System.EventHandler(this.btn_new2_Click);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup2.GroupBordersVisible = false;
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem8,
            this.layoutControlItem12,
            this.layoutControlItem13,
            this.emptySpaceItem8,
            this.emptySpaceItem9,
            this.layoutControlItem14,
            this.layoutControlItem15,
            this.emptySpaceItem10,
            this.layoutControlItem16,
            this.txt_idx2222});
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(1242, 346);
            this.layoutControlGroup2.TextVisible = false;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.btn_new2;
            this.layoutControlItem8.Location = new System.Drawing.Point(527, 0);
            this.layoutControlItem8.MaxSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem8.MinSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(90, 26);
            this.layoutControlItem8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem8.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem8.TextVisible = false;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.btn_save2;
            this.layoutControlItem12.Location = new System.Drawing.Point(617, 0);
            this.layoutControlItem12.MaxSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem12.MinSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(90, 26);
            this.layoutControlItem12.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.btn_del2;
            this.layoutControlItem13.Location = new System.Drawing.Point(707, 0);
            this.layoutControlItem13.MaxSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem13.MinSize = new System.Drawing.Size(90, 26);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(90, 26);
            this.layoutControlItem13.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // emptySpaceItem8
            // 
            this.emptySpaceItem8.AllowHotTrack = false;
            this.emptySpaceItem8.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem8.Name = "emptySpaceItem8";
            this.emptySpaceItem8.Size = new System.Drawing.Size(527, 26);
            this.emptySpaceItem8.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem9
            // 
            this.emptySpaceItem9.AllowHotTrack = false;
            this.emptySpaceItem9.Location = new System.Drawing.Point(797, 0);
            this.emptySpaceItem9.Name = "emptySpaceItem9";
            this.emptySpaceItem9.Size = new System.Drawing.Size(425, 326);
            this.emptySpaceItem9.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.txt_board_cd2;
            this.layoutControlItem14.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem14.MaxSize = new System.Drawing.Size(180, 24);
            this.layoutControlItem14.MinSize = new System.Drawing.Size(180, 24);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(180, 24);
            this.layoutControlItem14.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem14.Text = "게시판";
            this.layoutControlItem14.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem14.TextSize = new System.Drawing.Size(90, 20);
            this.layoutControlItem14.TextToControlDistance = 5;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.txt_board_name2;
            this.layoutControlItem15.Location = new System.Drawing.Point(180, 26);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(347, 24);
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextVisible = false;
            // 
            // emptySpaceItem10
            // 
            this.emptySpaceItem10.AllowHotTrack = false;
            this.emptySpaceItem10.Location = new System.Drawing.Point(581, 26);
            this.emptySpaceItem10.Name = "emptySpaceItem10";
            this.emptySpaceItem10.Size = new System.Drawing.Size(216, 24);
            this.emptySpaceItem10.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.txt_content;
            this.layoutControlItem16.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(797, 276);
            this.layoutControlItem16.Text = "내용";
            this.layoutControlItem16.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem16.TextSize = new System.Drawing.Size(90, 20);
            this.layoutControlItem16.TextToControlDistance = 5;
            // 
            // splitterControl1
            // 
            this.splitterControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitterControl1.Location = new System.Drawing.Point(5, 398);
            this.splitterControl1.Name = "splitterControl1";
            this.splitterControl1.Size = new System.Drawing.Size(1246, 5);
            this.splitterControl1.TabIndex = 35;
            this.splitterControl1.TabStop = false;
            // 
            // efwGroupControl3
            // 
            this.efwGroupControl3.CaptionImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("efwGroupControl3.CaptionImageOptions.Image")));
            this.efwGroupControl3.Controls.Add(this.efwGridControl2);
            this.efwGroupControl3.Controls.Add(this.panel4);
            this.efwGroupControl3.Dock = System.Windows.Forms.DockStyle.Top;
            this.efwGroupControl3.IsMultiLang = false;
            this.efwGroupControl3.Location = new System.Drawing.Point(5, 49);
            this.efwGroupControl3.Name = "efwGroupControl3";
            this.efwGroupControl3.Size = new System.Drawing.Size(1246, 349);
            this.efwGroupControl3.TabIndex = 2;
            this.efwGroupControl3.Text = "글 목록";
            // 
            // efwGridControl2
            // 
            this.efwGridControl2.BindSet = null;
            this.efwGridControl2.DBName = "";
            serviceInfo4.InstanceName = "";
            serviceInfo4.IsUserIDAdd = true;
            serviceInfo4.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo4.ParamsInfo")));
            serviceInfo4.ProcName = "";
            serviceInfo4.UserParams = null;
            this.efwGridControl2.DeleteServiceInfo = serviceInfo4;
            this.efwGridControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.efwGridControl2.EraserGroup = "CLR1";
            serviceInfo5.InstanceName = "";
            serviceInfo5.IsUserIDAdd = true;
            serviceInfo5.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo5.ParamsInfo")));
            serviceInfo5.ProcName = "";
            serviceInfo5.UserParams = null;
            this.efwGridControl2.InsertServiceInfo = serviceInfo5;
            this.efwGridControl2.IsAddExcelBtn = true;
            this.efwGridControl2.isAddPrintBtn = true;
            this.efwGridControl2.IsEditable = false;
            this.efwGridControl2.IsMultiLang = false;
            this.efwGridControl2.Location = new System.Drawing.Point(2, 62);
            this.efwGridControl2.MainView = this.gridView2;
            this.efwGridControl2.Name = "efwGridControl2";
            this.efwGridControl2.NowRowHandle = 0;
            this.efwGridControl2.PKColumns = ((System.Collections.ArrayList)(resources.GetObject("efwGridControl2.PKColumns")));
            this.efwGridControl2.PrevRowHandle = -2147483648;
            this.efwGridControl2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEdit2,
            this.repositoryItemMemoExEdit2,
            this.repositoryItemMemoEdit2});
            this.efwGridControl2.Size = new System.Drawing.Size(1242, 285);
            this.efwGridControl2.TabIndex = 8;
            this.efwGridControl2.TableName = "";
            serviceInfo6.InstanceName = "";
            serviceInfo6.IsUserIDAdd = true;
            serviceInfo6.ParamsInfo = ((System.Collections.Generic.Dictionary<int, object>)(resources.GetObject("serviceInfo6.ParamsInfo")));
            serviceInfo6.ProcName = "";
            serviceInfo6.UserParams = null;
            this.efwGridControl2.UpdateServiceInfo = serviceInfo6;
            this.efwGridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // gridView2
            // 
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn9,
            this.gridColumn10,
            this.gridColumn16,
            this.gridColumn18,
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn19,
            this.gridColumn17,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn15});
            this.gridView2.GridControl = this.efwGridControl2;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsView.ColumnAutoWidth = false;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "idx";
            this.gridColumn9.FieldName = "idx";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 0;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "게시판코드";
            this.gridColumn10.FieldName = "board_cd";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 1;
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "게시판명";
            this.gridColumn16.FieldName = "board_name";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 2;
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "날짜";
            this.gridColumn18.FieldName = "create_date";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 3;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "글제목";
            this.gridColumn11.FieldName = "subject";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 4;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "내용";
            this.gridColumn12.FieldName = "content";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 5;
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "작성자";
            this.gridColumn19.FieldName = "create_user";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 6;
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "공지여부";
            this.gridColumn17.FieldName = "is_notice";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 7;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "공개여부";
            this.gridColumn13.FieldName = "is_open";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 8;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "조회수";
            this.gridColumn14.FieldName = "read_cnt";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 9;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "비고";
            this.gridColumn15.FieldName = "remark";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 10;
            // 
            // repositoryItemLookUpEdit2
            // 
            this.repositoryItemLookUpEdit2.AutoHeight = false;
            this.repositoryItemLookUpEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit2.Name = "repositoryItemLookUpEdit2";
            // 
            // repositoryItemMemoExEdit2
            // 
            this.repositoryItemMemoExEdit2.AutoHeight = false;
            this.repositoryItemMemoExEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit2.Name = "repositoryItemMemoExEdit2";
            // 
            // repositoryItemMemoEdit2
            // 
            this.repositoryItemMemoEdit2.Name = "repositoryItemMemoEdit2";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txt_sch2);
            this.panel4.Controls.Add(this.btnSch2);
            this.panel4.Controls.Add(this.efwLabel2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(2, 23);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1242, 39);
            this.panel4.TabIndex = 7;
            // 
            // txt_sch2
            // 
            this.txt_sch2.EditValue2 = null;
            this.txt_sch2.Location = new System.Drawing.Point(94, 10);
            this.txt_sch2.Name = "txt_sch2";
            this.txt_sch2.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_sch2.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_sch2.RequireMessage = null;
            this.txt_sch2.Size = new System.Drawing.Size(268, 20);
            this.txt_sch2.TabIndex = 10;
            // 
            // btnSch2
            // 
            this.btnSch2.ButtonType = Easy.Framework.Util.BtnType.Search;
            this.btnSch2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSch2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSch2.ImageOptions.Image")));
            this.btnSch2.IsMultiLang = false;
            this.btnSch2.Location = new System.Drawing.Point(367, 8);
            this.btnSch2.Name = "btnSch2";
            this.btnSch2.Size = new System.Drawing.Size(75, 23);
            this.btnSch2.TabIndex = 9;
            this.btnSch2.Text = "조회";
            this.btnSch2.Click += new System.EventHandler(this.btnSch2_Click);
            // 
            // efwLabel2
            // 
            this.efwLabel2.EraserGroup = null;
            this.efwLabel2.IsMultiLang = false;
            this.efwLabel2.Location = new System.Drawing.Point(30, 13);
            this.efwLabel2.Name = "efwLabel2";
            this.efwLabel2.Size = new System.Drawing.Size(30, 14);
            this.efwLabel2.TabIndex = 8;
            this.efwLabel2.Text = "검색명";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.cmbBoard);
            this.panel3.Controls.Add(this.efwLabel1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(5, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1246, 44);
            this.panel3.TabIndex = 0;
            // 
            // cmbBoard
            // 
            childHierarchy1.CodeCtrl = null;
            childHierarchy1.DbName = null;
            childHierarchy1.SpName = null;
            this.cmbBoard.ChildHierarchyInfo = childHierarchy1;
            hierarchy1.DbName = null;
            hierarchy1.SpName = null;
            this.cmbBoard.HierarchyInfo = hierarchy1;
            this.cmbBoard.IsMultiLang = false;
            this.cmbBoard.Location = new System.Drawing.Point(96, 11);
            this.cmbBoard.Name = "cmbBoard";
            this.cmbBoard.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cmbBoard.Properties.Appearance.Options.UseBackColor = true;
            this.cmbBoard.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbBoard.Size = new System.Drawing.Size(264, 20);
            this.cmbBoard.TabIndex = 9;
            this.cmbBoard.EditValueChanged += new System.EventHandler(this.cmbBoard_EditValueChanged);
            // 
            // efwLabel1
            // 
            this.efwLabel1.EraserGroup = null;
            this.efwLabel1.IsMultiLang = false;
            this.efwLabel1.Location = new System.Drawing.Point(30, 13);
            this.efwLabel1.Name = "efwLabel1";
            this.efwLabel1.Size = new System.Drawing.Size(30, 14);
            this.efwLabel1.TabIndex = 8;
            this.efwLabel1.Text = "게시판";
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.Location = new System.Drawing.Point(397, 48);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(293, 181);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // txt_idx2
            // 
            this.txt_idx2.EditValue2 = null;
            this.txt_idx2.Location = new System.Drawing.Point(539, 38);
            this.txt_idx2.Name = "txt_idx2";
            this.txt_idx2.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Ivory;
            this.txt_idx2.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txt_idx2.Properties.ReadOnly = true;
            this.txt_idx2.RequireMessage = null;
            this.txt_idx2.Size = new System.Drawing.Size(50, 20);
            this.txt_idx2.StyleController = this.dataLayoutControl1;
            this.txt_idx2.TabIndex = 20;
            // 
            // txt_idx2222
            // 
            this.txt_idx2222.Control = this.txt_idx2;
            this.txt_idx2222.Location = new System.Drawing.Point(527, 26);
            this.txt_idx2222.Name = "txt_idx2222";
            this.txt_idx2222.Size = new System.Drawing.Size(54, 24);
            this.txt_idx2222.TextSize = new System.Drawing.Size(0, 0);
            this.txt_idx2222.TextVisible = false;
            // 
            // frmRM02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.efwXtraTabControl1);
            this.Name = "frmRM02";
            this.Size = new System.Drawing.Size(1268, 843);
            this.Load += new System.EventHandler(this.frmRM02_Load);
            this.Controls.SetChildIndex(this.efwXtraTabControl1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.efwXtraTabControl1)).EndInit();
            this.efwXtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl2)).EndInit();
            this.efwGroupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chk_is_use.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_idx.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_remark.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chk_is_comment.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chk_is_file.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chk_is_notice.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_board_name.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_board_cd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl1)).EndInit();
            this.efwGroupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_sch1.Properties)).EndInit();
            this.xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl4)).EndInit();
            this.efwGroupControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).EndInit();
            this.dataLayoutControl1.ResumeLayout(false);
            this.txt_content.Toolbar1.ResumeLayout(false);
            this.txt_content.Toolbar1.PerformLayout();
            this.txt_content.Toolbar2.ResumeLayout(false);
            this.txt_content.Toolbar2.PerformLayout();
            this.txt_content.ResumeLayout(false);
            this.txt_content.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_board_name2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_board_cd2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.efwGroupControl3)).EndInit();
            this.efwGroupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.efwGridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_sch2.Properties)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbBoard.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_idx2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_idx2222)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Easy.Framework.WinForm.Control.efwXtraTabControl efwXtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private Easy.Framework.WinForm.Control.efwGroupControl efwGroupControl1;
        private Easy.Framework.WinForm.Control.efwGridControl efwGridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private System.Windows.Forms.Panel panel2;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_sch1;
        private Easy.Framework.WinForm.Control.efwSimpleButton btnSch1;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel3;
        private Easy.Framework.WinForm.Control.efwGroupControl efwGroupControl2;
        private DevExpress.XtraEditors.SplitterControl splitterControl2;
        private Easy.Framework.WinForm.Control.efwGroupControl efwGroupControl3;
        private Easy.Framework.WinForm.Control.efwGridControl efwGridControl2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit2;
        private System.Windows.Forms.Panel panel4;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_sch2;
        private Easy.Framework.WinForm.Control.efwSimpleButton btnSch2;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel2;
        private System.Windows.Forms.Panel panel3;
        private Easy.Framework.WinForm.Control.efwLookUpEdit cmbBoard;
        private Easy.Framework.WinForm.Control.efwLabel efwLabel1;
        private Easy.Framework.WinForm.Control.efwGroupControl efwGroupControl4;
        private DevExpress.XtraEditors.SplitterControl splitterControl1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit3;
        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_idx;
        private Easy.Framework.WinForm.Control.efwMemoEdit txt_remark;
        private Easy.Framework.WinForm.Control.efwCheckEdit chk_is_comment;
        private Easy.Framework.WinForm.Control.efwCheckEdit chk_is_file;
        private Easy.Framework.WinForm.Control.efwCheckEdit chk_is_notice;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_board_name;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_board_cd;
        private DevExpress.XtraLayout.LayoutControlGroup Root;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private System.Windows.Forms.Panel panel5;
        private Easy.Framework.WinForm.Control.efwSimpleButton btn_new1;
        private Easy.Framework.WinForm.Control.efwSimpleButton btn_save1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem6;
        private Easy.Framework.WinForm.Control.efwCheckEdit chk_is_use;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraDataLayout.DataLayoutControl dataLayoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private Easy.Framework.WinForm.Control.efwSimpleButton btn_del2;
        private Easy.Framework.WinForm.Control.efwSimpleButton btn_save2;
        private Easy.Framework.WinForm.Control.efwSimpleButton btn_new2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem8;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem9;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_board_name2;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_board_cd2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem10;
        private SpiceLogic.WinHTMLEditor.WinForm.WinFormHtmlEditor txt_content;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private Easy.Framework.WinForm.Control.efwTextEdit txt_idx2;
        private DevExpress.XtraLayout.LayoutControlItem txt_idx2222;
    }
}